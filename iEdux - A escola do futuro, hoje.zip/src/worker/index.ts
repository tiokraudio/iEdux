import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { serveStatic } from 'hono/cloudflare-workers';
import {
  getOAuthRedirectUrl,
  exchangeCodeForSessionToken,
  getCurrentUser,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from '@getmocha/users-service/backend';
import { getCookie, setCookie } from 'hono/cookie';
import jwt from 'jsonwebtoken';

// Types
interface Env {
  DB: D1Database;
  MOCHA_USERS_SERVICE_API_KEY: string;
  MOCHA_USERS_SERVICE_API_URL: string;
  JWT_SECRET_KEY: string;
}

interface UserRecord {
  id: number;
  email: string;
  nome: string;
  perfil: string;
  instituicao_id: number | null;
  is_ativo: number;
}

import type { MochaUser } from '@getmocha/users-service/shared';

const app = new Hono<{ 
  Bindings: Env; 
  Variables: { 
    user: MochaUser; 
    userRecord: UserRecord; 
    instituicao_id: number;
    endUserRecord: any;
  } 
}>();

// CORS middleware
app.use('/api/*', cors({
  origin: ['http://localhost:5173', 'https://iEducational.com.br'],
  credentials: true,
}));

// REGRA 1: Middleware de Autenticação Rigoroso - implementa as 3 regras de segurança
const requireAuth = async (c: any, next: any) => {
  console.log("--- PROVA DE VIDA: Middleware 'requireAuth' FOI EXECUTADO ---");
  try {
    console.log('🔐 REGRA 1: requireAuth - Verificando se utilizador pode aceder...');
    
    // REGRA 1: Obter token do cookie (só utilizadores logados têm este cookie)
    const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
    
    console.log('🍪 REGRA 1: Session token present:', !!sessionToken);

    // REGRA 1: Se não há token, é utilizador anónimo - BLOQUEAR IMEDIATAMENTE
    if (!sessionToken) {
      console.log('❌ REGRA 1 VIOLADA: Utilizador anónimo tentou aceder - BLOQUEADO');
      return c.json({ 
        success: false, 
        message: 'Acesso negado: Sessão de login necessária' 
      }, 401);
    }

    // REGRA 1: Validar token com o serviço de usuários
    try {
      console.log('🔑 REGRA 1: Validando token de sessão...');
      const user = await getCurrentUser(sessionToken, {
        apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
        apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
      });

      // REGRA 1: Se token é inválido, BLOQUEAR IMEDIATAMENTE
      if (!user || !user.email) {
        console.log('❌ REGRA 1 VIOLADA: Token inválido ou utilizador sem email - BLOQUEADO');
        return c.json({ 
          success: false, 
          message: 'Acesso negado: Sessão inválida' 
        }, 401);
      }

      console.log('✅ REGRA 1 APROVADA: Utilizador com sessão válida:', user.email);
      
      // REGRA 2: Verificar se o e-mail está autorizado no nosso sistema
      console.log('🔍 REGRA 2: Verificando se e-mail está cadastrado...');
      
      if (!c.env.DB) {
        console.error('❌ Banco de dados não disponível');
        return c.json({ success: false, message: 'Erro interno: banco de dados não configurado' }, 500);
      }
      
      const userRecord = await c.env.DB.prepare(
        'SELECT * FROM usuarios WHERE email = ? AND is_ativo = 1'
      ).bind(user.email).first() as UserRecord | null;

      // REGRA 2: Se e-mail NÃO está cadastrado, BLOQUEAR IMEDIATAMENTE
      if (!userRecord) {
        console.log('❌ REGRA 2 VIOLADA: E-mail não cadastrado no sistema - BLOQUEADO:', user.email);
        return c.json({ 
          success: false, 
          message: 'Acesso negado: E-mail não autorizado no sistema' 
        }, 403);
      }

      console.log('✅ REGRA 2 APROVADA: E-mail autorizado com perfil:', userRecord.perfil);
      
      // Definir contexto para próximos middlewares (REGRA 3)
      c.set('user', user);
      c.set('userRecord', userRecord);
      
      await next();
    } catch (authError) {
      console.error('💥 REGRA 1 VIOLADA: Erro na validação do token - BLOQUEADO:', authError);
      return c.json({ 
        success: false, 
        message: 'Acesso negado: Erro na autenticação' 
      }, 401);
    }
  } catch (error) {
    console.error('💥 ERRO CRÍTICO na autenticação:', error);
    return c.json({ 
      success: false, 
      message: 'Acesso negado: Erro interno de segurança' 
    }, 500);
  }
};

// REGRA 3: Middleware para verificar se é Super Admin
const requireSuperAdmin = async (c: any, next: any) => {
  console.log("--- PROVA DE VIDA: Middleware 'requireSuperAdmin' FOI EXECUTADO ---");
  const userRecord = c.get('userRecord') as UserRecord;
  
  try {
    console.log('🔐 REGRA 3: Verificando se utilizador é Super Admin:', userRecord?.email);
    
    // O utilizador já passou pelas REGRAS 1+2 no requireAuth
    if (!userRecord) {
      console.error('❌ ERRO: userRecord não encontrado no contexto');
      return c.json({ success: false, message: 'Erro interno: contexto inválido' }, 500);
    }

    console.log('🔍 REGRA 3: Verificando perfil do utilizador:', userRecord.perfil);
    
    // REGRA 3: Verificar se o perfil é Super Admin
    if (userRecord.perfil !== 'Super Admin') {
      console.log('❌ REGRA 3 VIOLADA: Utilizador não é Super Admin - BLOQUEADO:', userRecord.email, 'Perfil:', userRecord.perfil);
      return c.json({ 
        success: false, 
        message: 'Acesso negado: Apenas Super Admins podem realizar esta operação.' 
      }, 403);
    }

    console.log('✅ REGRA 3 APROVADA: Super Admin autorizado:', userRecord.email);
    await next();
  } catch (error) {
    console.error('💥 Erro ao verificar perfil de Super Admin:', error);
    return c.json({ success: false, message: 'Erro interno' }, 500);
  }
};

// REGRA 3: Middleware para verificar se é Admin da Instituição
const requireInstituicaoAdmin = async (c: any, next: any) => {
  const userRecord = c.get('userRecord') as UserRecord;
  
  try {
    console.log('🔐 REGRA 3: Verificando se utilizador é Admin Instituição:', userRecord?.email);
    
    // O utilizador já passou pelas REGRAS 1+2 no requireAuth
    if (!userRecord) {
      console.error('❌ ERRO: userRecord não encontrado no contexto');
      return c.json({ success: false, message: 'Erro interno: contexto inválido' }, 500);
    }

    console.log('🔍 REGRA 3: Verificando perfil do utilizador:', userRecord.perfil);

    // REGRA 3: Verificar se o perfil é Admin Instituição
    if (userRecord.perfil !== 'Admin Instituição') {
      console.log('❌ REGRA 3 VIOLADA: Utilizador não é Admin Instituição - BLOQUEADO:', userRecord.email, 'Perfil:', userRecord.perfil);
      return c.json({ 
        success: false, 
        message: 'Acesso negado: Apenas Admins da Instituição podem realizar esta operação.' 
      }, 403);
    }

    console.log('✅ REGRA 3 APROVADA: Admin Instituição autorizado:', userRecord.email);
    await next();
  } catch (error) {
    console.error('💥 Erro ao verificar perfil de Admin Instituição:', error);
    return c.json({ success: false, message: 'Erro interno' }, 500);
  }
};

// REGRA 3: Middleware para verificar se é utilizador final (registado na escola)
const requireEndUser = async (c: any, next: any) => {
  const user = c.get('user') as MochaUser;
  const userRecord = c.get('userRecord') as UserRecord;
  
  try {
    console.log('🔐 REGRA 3: Verificando se utilizador é End User:', user?.email);
    
    // O utilizador já passou pelas REGRAS 1+2 no requireAuth
    if (!userRecord) {
      console.error('❌ ERRO: userRecord não encontrado no contexto');
      return c.json({ success: false, message: 'Erro interno: contexto inválido' }, 500);
    }

    // Verificar se o banco de dados está disponível
    if (!c.env.DB) {
      console.error('❌ Banco de dados não disponível');
      return c.json({ success: false, message: 'Erro interno: banco de dados não configurado' }, 500);
    }

    console.log('🔍 REGRA 3: Verificando tipo de utilizador:', userRecord.perfil);

    // REGRA 3: Se for admin, redirecionar para painel correto
    if (userRecord.perfil === 'Super Admin' || userRecord.perfil === 'Admin Instituição') {
      console.log('❌ REGRA 3: Admin tentou aceder área de utilizador final - redirecionando');
      return c.json({ 
        success: false, 
        message: 'Redirecionamento necessário',
        redirect: userRecord.perfil === 'Super Admin' ? '/painel' : '/painel-escola'
      }, 302);
    }

    // REGRA 3: Verificar se é utilizador da escola
    const usuarioEscola = await c.env.DB.prepare(
      'SELECT * FROM usuarios_escola WHERE email = ? AND is_ativo = 1'
    ).bind(user.email).first() as any;

    if (!usuarioEscola) {
      console.log('❌ REGRA 3 VIOLADA: Utilizador não cadastrado como utilizador da escola - BLOQUEADO:', user.email);
      return c.json({ 
        success: false, 
        message: 'Acesso negado: Utilizador não cadastrado na escola.' 
      }, 403);
    }

    console.log('✅ REGRA 3 APROVADA: End User autorizado:', user.email);
    c.set('endUserRecord', usuarioEscola);
    c.set('instituicao_id', usuarioEscola.instituicao_id);
    await next();
  } catch (error) {
    console.error('💥 Erro ao verificar utilizador final:', error);
    return c.json({ success: false, message: 'Erro interno' }, 500);
  }
};

// Routes de Contato/Leads (rota pública - formulário do site)
app.post('/api/contact', async (c) => {
  try {
    const { nome, email, instituicao, cargo, telefone, mensagem } = await c.req.json();

    await c.env.DB.prepare(`
      INSERT INTO leads (nome, email, instituicao, cargo, telefone, mensagem)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(nome, email, instituicao, cargo, telefone, mensagem).run();

    return c.json({ success: true, message: 'Mensagem enviada com sucesso!' });
  } catch (error) {
    console.error('Erro ao salvar contato:', error);
    return c.json({ success: false, message: 'Erro ao enviar mensagem' }, 500);
  }
});

// OAuth redirect URL endpoint (rota pública - processo de login)
app.get('/api/oauth/google/redirect_url', async (c) => {
  try {
    console.log('🔗 Gerando URL de redirecionamento OAuth...');
    
    const redirectUrl = await getOAuthRedirectUrl('google', {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    console.log('✅ URL gerada:', redirectUrl);
    return c.json({ redirectUrl }, 200);
  } catch (error) {
    console.error('💥 Erro ao gerar URL OAuth:', error);
    return c.json({ success: false, message: 'Erro ao gerar URL de login' }, 500);
  }
});

// Exchange code for session token (rota pública - processo de login)
app.post('/api/sessions', async (c) => {
  try {
    const body = await c.req.json();
    console.log('🔄 Trocando código por token...');

    if (!body.code) {
      console.log('❌ Código não fornecido');
      return c.json({ error: 'No authorization code provided' }, 400);
    }

    const sessionToken = await exchangeCodeForSessionToken(body.code, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    console.log('✅ Token obtido, salvando cookie...');

    setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      path: '/',
      sameSite: 'none',
      secure: true,
      maxAge: 60 * 24 * 60 * 60, // 60 days
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    console.error('💥 Erro na troca do código:', error);
    return c.json({ success: false, message: 'Erro no processo de login' }, 500);
  }
});

// REGRA DE SEGURANÇA 1 + 2: Endpoint protegido - bloqueia utilizadores anónimos e não autorizados
app.get('/api/users/me', async (c) => {
  try {
    console.log('🔐 REGRA 1+2: /api/users/me - Verificando autenticação rigorosa...');
    
    // BLOQUEIO CRÍTICO 1: Verificar se há token de sessão
    const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
    
    console.log('🍪 Session token present:', !!sessionToken);

    // BLOQUEIO CRÍTICO: Se não há token, NEGAR ACESSO IMEDIATAMENTE
    if (!sessionToken) {
      console.log('❌ REGRA 1 VIOLADA: Utilizador anónimo tentou aceder - BLOQUEADO');
      return c.json({ 
        success: false, 
        message: 'Acesso negado: Sessão não encontrada',
        authorized: false 
      }, 401);
    }

    // BLOQUEIO CRÍTICO 2: Validar token com o serviço de usuários
    let user;
    try {
      console.log('🔑 Validando token com Mocha Users Service...');
      user = await getCurrentUser(sessionToken, {
        apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
        apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
      });

      // BLOQUEIO CRÍTICO: Se token é inválido, NEGAR ACESSO IMEDIATAMENTE
      if (!user || !user.email) {
        console.log('❌ REGRA 1 VIOLADA: Token inválido ou utilizador sem email - BLOQUEADO');
        return c.json({ 
          success: false, 
          message: 'Acesso negado: Sessão inválida',
          authorized: false 
        }, 401);
      }

      console.log('✅ Token válido para utilizador:', user.email);
    } catch (authError) {
      console.error('💥 REGRA 1 VIOLADA: Erro na validação do token - BLOQUEADO:', authError);
      return c.json({ 
        success: false, 
        message: 'Acesso negado: Erro na autenticação',
        authorized: false 
      }, 401);
    }

    // BLOQUEIO CRÍTICO 3: REGRA 2 - Verificar se o e-mail está autorizado no nosso sistema
    console.log('👤 REGRA 2: Verificando se o e-mail está cadastrado no sistema:', user.email);
    
    // Verificar se o banco de dados está disponível
    if (!c.env.DB) {
      console.error('❌ Banco de dados não disponível');
      return c.json({ 
        success: false, 
        message: 'Erro interno: banco de dados não configurado',
        authorized: false 
      }, 500);
    }
    
    // REGRA 2: Buscar utilizador na nossa tabela de utilizadores autorizados
    const userRecord = await c.env.DB.prepare(
      'SELECT * FROM usuarios WHERE email = ? AND is_ativo = 1'
    ).bind(user.email).first() as UserRecord | null;

    // BLOQUEIO CRÍTICO: Se o e-mail NÃO está cadastrado, NEGAR ACESSO
    if (!userRecord) {
      console.log('❌ REGRA 2 VIOLADA: E-mail não cadastrado no sistema - BLOQUEADO:', user.email);
      return c.json({ 
        success: false, 
        message: 'Acesso negado: E-mail não cadastrado no sistema. Contacte o administrador.',
        authorized: false 
      }, 403);
    }

    console.log('✅ REGRA 2 APROVADA: E-mail encontrado com perfil:', userRecord.perfil);
    
    // SUCESSO: Utilizador autenticado e autorizado
    return c.json({
      ...user,
      authorized: true,
      perfil: userRecord.perfil,
      instituicao_id: userRecord.instituicao_id,
      nome: userRecord.nome
    });
  } catch (error) {
    console.error('💥 Erro crítico no endpoint /api/users/me:', error);
    return c.json({ 
      success: false, 
      message: 'Erro interno no servidor',
      authorized: false 
    }, 500);
  }
});

// Logout endpoint (pode ser chamado mesmo sem autenticação válida)
app.get('/api/logout', async (c) => {
  try {
    const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

    if (typeof sessionToken === 'string') {
      await deleteSession(sessionToken, {
        apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
        apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
      });
    }

    // Delete cookie
    setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
      httpOnly: true,
      path: '/',
      sameSite: 'none',
      secure: true,
      maxAge: 0,
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    console.error('💥 Erro no logout:', error);
    return c.json({ success: true }, 200); // Always return success for logout
  }
});

// REGRA 2: Endpoint de autorização - verifica se e-mail está cadastrado
app.post('/api/users/authorize', requireAuth, async (c) => {
  const user = c.get('user');
  
  try {
    console.log('👤 REGRA 2: Verificando se e-mail está autorizado:', user.email);
    
    // Verificar se o banco de dados está disponível
    if (!c.env.DB) {
      console.error('❌ Banco de dados não disponível');
      return c.json({ success: false, message: 'Erro interno: banco de dados não configurado' }, 500);
    }
    
    // REGRA 2: Procurar utilizador na nossa tabela de utilizadores autorizados
    const userRecord = await c.env.DB.prepare(
      'SELECT * FROM usuarios WHERE email = ? AND is_ativo = 1'
    ).bind(user.email).first() as UserRecord | null;

    console.log('🔍 REGRA 2: E-mail encontrado no sistema:', !!userRecord);

    // REGRA 2: Se e-mail NÃO está cadastrado, NEGAR ACESSO
    if (!userRecord) {
      console.log('❌ REGRA 2 VIOLADA: E-mail não cadastrado - BLOQUEADO:', user.email);
      return c.json({ 
        success: false, 
        message: 'Acesso negado: E-mail não está cadastrado no sistema. Contacte o administrador para solicitar acesso.' 
      }, 403);
    }

    console.log('✅ REGRA 2 APROVADA: E-mail autorizado com perfil:', userRecord.perfil);
    return c.json({ 
      success: true, 
      data: { 
        perfil: userRecord.perfil,
        instituicao_id: userRecord.instituicao_id 
      }
    });
  } catch (error) {
    console.error('💥 Erro na verificação de autorização:', error);
    return c.json({ success: false, message: 'Erro interno' }, 500);
  }
});

// ========================================
// ROUTES UTILIZADOR FINAL
// ========================================

// Buscar aplicações do utilizador final
app.get('/api/user/aplicacoes', requireAuth, requireEndUser, async (c) => {
  const endUserRecord = c.get('endUserRecord' as any) as any;
  const instituicaoId = c.get('instituicao_id' as any) as number;

  try {
    const { results } = await c.env.DB.prepare(`
      SELECT 
        s.id,
        s.nome,
        s.descricao_breve,
        s.url_icone,
        s.url_aplicacao,
        ps.nome_perfil as perfil_nome
      FROM atribuicoes_perfis ap
      INNER JOIN solucoes s ON ap.solucao_id = s.id
      INNER JOIN perfis_solucoes ps ON ap.perfil_solucao_id = ps.id
      INNER JOIN licencas_instituicoes li ON s.id = li.solucao_id AND li.instituicao_id = ap.instituicao_id
      WHERE ap.usuario_id = ? 
        AND ap.instituicao_id = ?
        AND s.status = 'ativa'
        AND li.is_ativa = 1
      ORDER BY s.nome
    `).bind(endUserRecord.id, instituicaoId).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar aplicações do utilizador:', error);
    return c.json({ success: false, message: 'Erro ao buscar aplicações' }, 500);
  }
});

// Gerar token SSO para aplicação
app.post('/api/user/sso-token', requireAuth, requireEndUser, async (c) => {
  const endUserRecord = c.get('endUserRecord' as any) as any;
  const instituicaoId = c.get('instituicao_id' as any) as number;
  const { solucao_id, perfil_nome } = await c.req.json();

  try {
    // Verificar se o utilizador tem acesso a esta solução
    const atribuicao = await c.env.DB.prepare(`
      SELECT ap.*, ps.nome_perfil
      FROM atribuicoes_perfis ap
      INNER JOIN perfis_solucoes ps ON ap.perfil_solucao_id = ps.id
      WHERE ap.usuario_id = ? 
        AND ap.solucao_id = ? 
        AND ap.instituicao_id = ?
    `).bind(endUserRecord.id, solucao_id, instituicaoId).first();

    if (!atribuicao) {
      return c.json({ success: false, message: 'Acesso negado a esta aplicação' }, 403);
    }

    // Criar payload do JWT
    const payload = {
      usuario_id: endUserRecord.id,
      usuario_nome: endUserRecord.nome,
      usuario_email: endUserRecord.email,
      usuario_tipo: endUserRecord.tipo_usuario,
      instituicao_id: instituicaoId,
      solucao_id: solucao_id,
      perfil_nome: perfil_nome,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + (60 * 15) // Expira em 15 minutos
    };

    // Gerar token JWT
    const token = jwt.sign(payload, c.env.JWT_SECRET_KEY, { algorithm: 'HS256' });

    return c.json({ success: true, token });
  } catch (error) {
    console.error('Erro ao gerar token SSO:', error);
    return c.json({ success: false, message: 'Erro ao gerar token de acesso' }, 500);
  }
});

// ========================================
// ROUTES SUPER ADMIN
// ========================================

// Leads - PROTEGIDO COM MIDDLEWARE
app.get('/api/admin/leads', requireAuth, requireSuperAdmin, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM leads ORDER BY created_at DESC'
    ).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar leads:', error);
    return c.json({ success: false, message: 'Erro ao buscar leads' }, 500);
  }
});

app.patch('/api/admin/leads/:id/status', requireAuth, requireSuperAdmin, async (c) => {
  const leadId = c.req.param('id');
  const { status } = await c.req.json();

  try {
    await c.env.DB.prepare(
      'UPDATE leads SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(status, leadId).run();

    return c.json({ success: true });
  } catch (error) {
    console.error('Erro ao atualizar status do lead:', error);
    return c.json({ success: false, message: 'Erro ao atualizar status' }, 500);
  }
});

// ========================================
// APLICAR MIDDLEWARE DE SEGURANÇA A TODOS OS ENDPOINTS
// ========================================

// Super Admins - TODOS COM MIDDLEWARE DE SEGURANÇA
app.get('/api/admin/super-admins', requireAuth, requireSuperAdmin, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM usuarios WHERE perfil = ? ORDER BY created_at ASC'
    ).bind('Super Admin').all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar super admins:', error);
    return c.json({ success: false, message: 'Erro ao buscar administradores' }, 500);
  }
});

app.post('/api/admin/super-admins', requireAuth, requireSuperAdmin, async (c) => {
  const { nome, email } = await c.req.json();

  try {
    // Verificar se o email já existe
    const existing = await c.env.DB.prepare(
      'SELECT id FROM usuarios WHERE email = ?'
    ).bind(email).first();

    if (existing) {
      return c.json({ success: false, message: 'Este e-mail já está cadastrado' }, 400);
    }

    await c.env.DB.prepare(`
      INSERT INTO usuarios (nome, email, perfil, is_ativo)
      VALUES (?, ?, 'Super Admin', 1)
    `).bind(nome, email).run();

    return c.json({ success: true, message: 'Super Admin adicionado com sucesso!' });
  } catch (error) {
    console.error('Erro ao adicionar super admin:', error);
    return c.json({ success: false, message: 'Erro ao adicionar Super Admin' }, 500);
  }
});

app.delete('/api/admin/super-admins/:id', requireAuth, requireSuperAdmin, async (c) => {
  const adminId = c.req.param('id');

  try {
    await c.env.DB.prepare(
      'DELETE FROM usuarios WHERE id = ? AND perfil = ?'
    ).bind(adminId, 'Super Admin').run();

    return c.json({ success: true, message: 'Super Admin removido com sucesso!' });
  } catch (error) {
    console.error('Erro ao remover super admin:', error);
    return c.json({ success: false, message: 'Erro ao remover Super Admin' }, 500);
  }
});

// Instituições - TODAS PROTEGIDAS COM MIDDLEWARE
app.get('/api/admin/instituicoes', requireAuth, requireSuperAdmin, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM instituicoes ORDER BY created_at DESC'
    ).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar instituições:', error);
    return c.json({ success: false, message: 'Erro ao buscar instituições' }, 500);
  }
});

app.post('/api/admin/instituicoes', requireAuth, requireSuperAdmin, async (c) => {
  const { nome, status, modo_dados, conector_erp_id } = await c.req.json();

  try {
    await c.env.DB.prepare(`
      INSERT INTO instituicoes (nome, status, modo_dados, conector_erp_id)
      VALUES (?, ?, ?, ?)
    `).bind(nome, status, modo_dados, conector_erp_id || null).run();

    return c.json({ success: true, message: 'Instituição criada com sucesso!' });
  } catch (error) {
    console.error('Erro ao criar instituição:', error);
    return c.json({ success: false, message: 'Erro ao criar instituição' }, 500);
  }
});

app.put('/api/admin/instituicoes/:id', requireAuth, requireSuperAdmin, async (c) => {
  const instituicaoId = c.req.param('id');
  const { nome, status, modo_dados, conector_erp_id } = await c.req.json();

  try {
    await c.env.DB.prepare(`
      UPDATE instituicoes 
      SET nome = ?, status = ?, modo_dados = ?, conector_erp_id = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(nome, status, modo_dados, conector_erp_id || null, instituicaoId).run();

    return c.json({ success: true, message: 'Instituição atualizada com sucesso!' });
  } catch (error) {
    console.error('Erro ao atualizar instituição:', error);
    return c.json({ success: false, message: 'Erro ao atualizar instituição' }, 500);
  }
});

app.patch('/api/admin/instituicoes/:id/status', requireAuth, requireSuperAdmin, async (c) => {
  const instituicaoId = c.req.param('id');

  try {
    const instituicao = await c.env.DB.prepare(
      'SELECT status FROM instituicoes WHERE id = ?'
    ).bind(instituicaoId).first() as { status: string } | null;

    if (!instituicao) {
      return c.json({ success: false, message: 'Instituição não encontrada' }, 404);
    }

    const newStatus = instituicao.status === 'ativa' ? 'inativa' : 'ativa';

    await c.env.DB.prepare(
      'UPDATE instituicoes SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(newStatus, instituicaoId).run();

    return c.json({ success: true });
  } catch (error) {
    console.error('Erro ao alterar status da instituição:', error);
    return c.json({ success: false, message: 'Erro ao alterar status' }, 500);
  }
});

// Licenças da Instituição
app.get('/api/admin/instituicoes/:id/licencas', requireAuth, requireSuperAdmin, async (c) => {
  const instituicaoId = c.req.param('id');

  try {
    const { results } = await c.env.DB.prepare(`
      SELECT 
        s.*,
        CASE WHEN li.id IS NOT NULL THEN 1 ELSE 0 END as tem_licenca
      FROM solucoes s
      LEFT JOIN licencas_instituicoes li ON s.id = li.solucao_id AND li.instituicao_id = ? AND li.is_ativa = 1
      WHERE s.status = 'ativa'
      ORDER BY s.nome
    `).bind(instituicaoId).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar licenças da instituição:', error);
    return c.json({ success: false, message: 'Erro ao buscar licenças' }, 500);
  }
});

app.post('/api/admin/instituicoes/:id/licencas', requireAuth, requireSuperAdmin, async (c) => {
  const instituicaoId = c.req.param('id');
  const { licencas } = await c.req.json();

  try {
    // Remover todas as licenças existentes
    await c.env.DB.prepare(
      'DELETE FROM licencas_instituicoes WHERE instituicao_id = ?'
    ).bind(instituicaoId).run();

    // Adicionar as novas licenças
    for (const solucaoId of licencas) {
      await c.env.DB.prepare(`
        INSERT INTO licencas_instituicoes (instituicao_id, solucao_id, is_ativa)
        VALUES (?, ?, 1)
      `).bind(instituicaoId, solucaoId).run();
    }

    return c.json({ success: true, message: 'Licenças atualizadas com sucesso!' });
  } catch (error) {
    console.error('Erro ao atualizar licenças:', error);
    return c.json({ success: false, message: 'Erro ao atualizar licenças' }, 500);
  }
});

// Administrador da Instituição
app.get('/api/admin/instituicoes/:id/administrador', requireAuth, requireSuperAdmin, async (c) => {
  const instituicaoId = c.req.param('id');

  try {
    const admin = await c.env.DB.prepare(
      'SELECT * FROM usuarios WHERE instituicao_id = ? AND perfil = ? AND is_ativo = 1'
    ).bind(instituicaoId, 'Admin Instituição').first();

    return c.json({ success: true, data: admin });
  } catch (error) {
    console.error('Erro ao buscar admin da instituição:', error);
    return c.json({ success: false, message: 'Erro ao buscar administrador' }, 500);
  }
});

app.post('/api/admin/instituicoes/:id/administrador', requireAuth, requireSuperAdmin, async (c) => {
  const instituicaoId = c.req.param('id');
  const { nome, email } = await c.req.json();

  try {
    // Verificar se já existe admin para esta instituição
    const existingAdmin = await c.env.DB.prepare(
      'SELECT id FROM usuarios WHERE instituicao_id = ? AND perfil = ?'
    ).bind(instituicaoId, 'Admin Instituição').first();

    if (existingAdmin) {
      return c.json({ success: false, message: 'Esta instituição já possui um administrador' }, 400);
    }

    // Verificar se o email já está sendo usado
    const existingUser = await c.env.DB.prepare(
      'SELECT id FROM usuarios WHERE email = ?'
    ).bind(email).first();

    if (existingUser) {
      return c.json({ success: false, message: 'Este e-mail já está cadastrado no sistema' }, 400);
    }

    await c.env.DB.prepare(`
      INSERT INTO usuarios (nome, email, perfil, instituicao_id, is_ativo)
      VALUES (?, ?, 'Admin Instituição', ?, 1)
    `).bind(nome, email, instituicaoId).run();

    return c.json({ success: true, message: 'Administrador criado com sucesso!' });
  } catch (error) {
    console.error('Erro ao criar admin da instituição:', error);
    return c.json({ success: false, message: 'Erro ao criar administrador' }, 500);
  }
});

app.delete('/api/admin/instituicoes/:instituicaoId/administrador/:adminId', requireAuth, requireSuperAdmin, async (c) => {
  const adminId = c.req.param('adminId');

  try {
    await c.env.DB.prepare(
      'DELETE FROM usuarios WHERE id = ? AND perfil = ?'
    ).bind(adminId, 'Admin Instituição').run();

    return c.json({ success: true, message: 'Administrador removido com sucesso!' });
  } catch (error) {
    console.error('Erro ao remover admin da instituição:', error);
    return c.json({ success: false, message: 'Erro ao remover administrador' }, 500);
  }
});

// Conectores ERP - TODOS PROTEGIDOS COM MIDDLEWARE
app.get('/api/admin/conectores-erp', requireAuth, requireSuperAdmin, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM conectores_erp ORDER BY created_at DESC'
    ).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar conectores:', error);
    return c.json({ success: false, message: 'Erro ao buscar conectores' }, 500);
  }
});

app.get('/api/admin/conectores-erp/ativos', requireAuth, requireSuperAdmin, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM conectores_erp WHERE status = ? ORDER BY nome'
    ).bind('ativo').all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar conectores ativos:', error);
    return c.json({ success: false, message: 'Erro ao buscar conectores' }, 500);
  }
});

app.post('/api/admin/conectores-erp', requireAuth, requireSuperAdmin, async (c) => {
  const { nome, status, descricao_breve, campos_credenciais } = await c.req.json();

  try {
    await c.env.DB.prepare(`
      INSERT INTO conectores_erp (nome, status, descricao_breve, campos_credenciais)
      VALUES (?, ?, ?, ?)
    `).bind(nome, status, descricao_breve, campos_credenciais).run();

    return c.json({ success: true, message: 'Conector criado com sucesso!' });
  } catch (error) {
    console.error('Erro ao criar conector:', error);
    return c.json({ success: false, message: 'Erro ao criar conector' }, 500);
  }
});

app.put('/api/admin/conectores-erp/:id', requireAuth, requireSuperAdmin, async (c) => {
  const conectorId = c.req.param('id');
  const { nome, status, descricao_breve, campos_credenciais } = await c.req.json();

  try {
    await c.env.DB.prepare(`
      UPDATE conectores_erp 
      SET nome = ?, status = ?, descricao_breve = ?, campos_credenciais = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(nome, status, descricao_breve, campos_credenciais, conectorId).run();

    return c.json({ success: true, message: 'Conector atualizado com sucesso!' });
  } catch (error) {
    console.error('Erro ao atualizar conector:', error);
    return c.json({ success: false, message: 'Erro ao atualizar conector' }, 500);
  }
});

app.patch('/api/admin/conectores-erp/:id/status', requireAuth, requireSuperAdmin, async (c) => {
  const conectorId = c.req.param('id');

  try {
    const conector = await c.env.DB.prepare(
      'SELECT status FROM conectores_erp WHERE id = ?'
    ).bind(conectorId).first() as { status: string } | null;

    if (!conector) {
      return c.json({ success: false, message: 'Conector não encontrado' }, 404);
    }

    const newStatus = conector.status === 'ativo' ? 'inativo' : 'ativo';

    await c.env.DB.prepare(
      'UPDATE conectores_erp SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(newStatus, conectorId).run();

    return c.json({ success: true });
  } catch (error) {
    console.error('Erro ao alterar status do conector:', error);
    return c.json({ success: false, message: 'Erro ao alterar status' }, 500);
  }
});

// Soluções - TODAS PROTEGIDAS COM MIDDLEWARE
app.get('/api/admin/solucoes', requireAuth, requireSuperAdmin, async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM solucoes ORDER BY created_at DESC'
    ).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar soluções:', error);
    return c.json({ success: false, message: 'Erro ao buscar soluções' }, 500);
  }
});

app.post('/api/admin/solucoes', requireAuth, requireSuperAdmin, async (c) => {
  const { nome, status, descricao_breve, url_aplicacao, url_icone } = await c.req.json();

  try {
    await c.env.DB.prepare(`
      INSERT INTO solucoes (nome, status, descricao_breve, url_aplicacao, url_icone)
      VALUES (?, ?, ?, ?, ?)
    `).bind(nome, status, descricao_breve, url_aplicacao, url_icone).run();

    return c.json({ success: true, message: 'Solução criada com sucesso!' });
  } catch (error) {
    console.error('Erro ao criar solução:', error);
    return c.json({ success: false, message: 'Erro ao criar solução' }, 500);
  }
});

app.put('/api/admin/solucoes/:id', requireAuth, requireSuperAdmin, async (c) => {
  const solucaoId = c.req.param('id');
  const { nome, status, descricao_breve, url_aplicacao, url_icone } = await c.req.json();

  try {
    await c.env.DB.prepare(`
      UPDATE solucoes 
      SET nome = ?, status = ?, descricao_breve = ?, url_aplicacao = ?, url_icone = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(nome, status, descricao_breve, url_aplicacao, url_icone, solucaoId).run();

    return c.json({ success: true, message: 'Solução atualizada com sucesso!' });
  } catch (error) {
    console.error('Erro ao atualizar solução:', error);
    return c.json({ success: false, message: 'Erro ao atualizar solução' }, 500);
  }
});

app.patch('/api/admin/solucoes/:id/status', requireAuth, requireSuperAdmin, async (c) => {
  const solucaoId = c.req.param('id');

  try {
    const solucao = await c.env.DB.prepare(
      'SELECT status FROM solucoes WHERE id = ?'
    ).bind(solucaoId).first() as { status: string } | null;

    if (!solucao) {
      return c.json({ success: false, message: 'Solução não encontrada' }, 404);
    }

    const newStatus = solucao.status === 'ativa' ? 'inativa' : 'ativa';

    await c.env.DB.prepare(
      'UPDATE solucoes SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(newStatus, solucaoId).run();

    return c.json({ success: true });
  } catch (error) {
    console.error('Erro ao alterar status da solução:', error);
    return c.json({ success: false, message: 'Erro ao alterar status' }, 500);
  }
});

// Perfis das Soluções
app.get('/api/admin/solucoes/:id/perfis', requireAuth, requireSuperAdmin, async (c) => {
  const solucaoId = c.req.param('id');

  try {
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM perfis_solucoes WHERE solucao_id = ? ORDER BY created_at DESC'
    ).bind(solucaoId).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar perfis da solução:', error);
    return c.json({ success: false, message: 'Erro ao buscar perfis' }, 500);
  }
});

app.post('/api/admin/solucoes/:id/perfis', requireAuth, requireSuperAdmin, async (c) => {
  const solucaoId = c.req.param('id');
  const { nome_perfil, descricao_perfil } = await c.req.json();

  try {
    await c.env.DB.prepare(`
      INSERT INTO perfis_solucoes (solucao_id, nome_perfil, descricao_perfil)
      VALUES (?, ?, ?)
    `).bind(solucaoId, nome_perfil, descricao_perfil).run();

    return c.json({ success: true, message: 'Perfil adicionado com sucesso!' });
  } catch (error) {
    console.error('Erro ao adicionar perfil:', error);
    return c.json({ success: false, message: 'Erro ao adicionar perfil' }, 500);
  }
});

app.delete('/api/admin/perfis-solucoes/:id', requireAuth, requireSuperAdmin, async (c) => {
  const perfilId = c.req.param('id');

  try {
    await c.env.DB.prepare(
      'DELETE FROM perfis_solucoes WHERE id = ?'
    ).bind(perfilId).run();

    return c.json({ success: true, message: 'Perfil excluído com sucesso!' });
  } catch (error) {
    console.error('Erro ao excluir perfil:', error);
    return c.json({ success: false, message: 'Erro ao excluir perfil' }, 500);
  }
});

// ========================================
// ROUTES ESCOLA (ADMIN DA INSTITUIÇÃO) - TODAS PROTEGIDAS
// ========================================

// Informações da Instituição - PROTEGIDO COM MIDDLEWARE
app.get('/api/escola/info', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;

  try {
    const instituicao = await c.env.DB.prepare(
      'SELECT * FROM instituicoes WHERE id = ?'
    ).bind(userRecord.instituicao_id).first();

    return c.json({ success: true, data: instituicao });
  } catch (error) {
    console.error('Erro ao buscar info da instituição:', error);
    return c.json({ success: false, message: 'Erro ao buscar informações' }, 500);
  }
});

// Estatísticas do Dashboard
app.get('/api/escola/stats', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;

  try {
    const [usuarios, alunos, responsaveis, turmas, disciplinas] = await Promise.all([
      c.env.DB.prepare('SELECT COUNT(*) as count FROM usuarios_escola WHERE instituicao_id = ? AND is_ativo = 1').bind(userRecord.instituicao_id).first(),
      c.env.DB.prepare('SELECT COUNT(*) as count FROM alunos WHERE instituicao_id = ? AND is_ativo = 1').bind(userRecord.instituicao_id).first(),
      c.env.DB.prepare('SELECT COUNT(*) as count FROM responsaveis WHERE instituicao_id = ? AND is_ativo = 1').bind(userRecord.instituicao_id).first(),
      c.env.DB.prepare('SELECT COUNT(*) as count FROM turmas WHERE instituicao_id = ? AND is_ativa = 1').bind(userRecord.instituicao_id).first(),
      c.env.DB.prepare('SELECT COUNT(*) as count FROM disciplinas WHERE instituicao_id = ? AND is_ativa = 1').bind(userRecord.instituicao_id).first()
    ]);

    const stats = {
      usuarios_escola: (usuarios as any)?.count || 0,
      alunos: (alunos as any)?.count || 0,
      responsaveis: (responsaveis as any)?.count || 0,
      turmas: (turmas as any)?.count || 0,
      disciplinas: (disciplinas as any)?.count || 0
    };

    return c.json({ success: true, data: stats });
  } catch (error) {
    console.error('Erro ao buscar estatísticas:', error);
    return c.json({ success: false, message: 'Erro ao buscar estatísticas' }, 500);
  }
});

// Importação de dados
app.post('/api/escola/importacao', requireAuth, requireInstituicaoAdmin, async (c) => {
  try {
    // Funcionalidade de importação será implementada em breve
    return c.json({ 
      success: true, 
      data: { processados: 0 },
      message: 'Funcionalidade de importação será implementada em breve' 
    });
  } catch (error) {
    console.error('Erro na importação:', error);
    return c.json({ success: false, message: 'Erro na importação' }, 500);
  }
});

// ERP - Conector Info
app.get('/api/escola/erp/conector', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;

  try {
    const instituicao = await c.env.DB.prepare(
      'SELECT * FROM instituicoes WHERE id = ?'
    ).bind(userRecord.instituicao_id).first() as any;

    if (!instituicao?.conector_erp_id) {
      return c.json({ success: true, data: null });
    }

    const conector = await c.env.DB.prepare(
      'SELECT * FROM conectores_erp WHERE id = ?'
    ).bind(instituicao.conector_erp_id).first();

    return c.json({ success: true, data: conector });
  } catch (error) {
    console.error('Erro ao buscar conector ERP:', error);
    return c.json({ success: false, message: 'Erro ao buscar conector' }, 500);
  }
});

// ERP - Credenciais
app.get('/api/escola/erp/credenciais', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;

  try {
    const credenciais = await c.env.DB.prepare(
      'SELECT * FROM credenciais_erp WHERE instituicao_id = ?'
    ).bind(userRecord.instituicao_id).first();

    return c.json({ success: true, data: credenciais });
  } catch (error) {
    console.error('Erro ao buscar credenciais ERP:', error);
    return c.json({ success: false, message: 'Erro ao buscar credenciais' }, 500);
  }
});

app.post('/api/escola/erp/credenciais', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;
  const { credenciais } = await c.req.json();

  try {
    const instituicao = await c.env.DB.prepare(
      'SELECT conector_erp_id FROM instituicoes WHERE id = ?'
    ).bind(userRecord.instituicao_id).first() as any;

    if (!instituicao?.conector_erp_id) {
      return c.json({ success: false, message: 'Conector ERP não configurado' }, 400);
    }

    // Upsert das credenciais
    await c.env.DB.prepare(`
      INSERT INTO credenciais_erp (instituicao_id, conector_erp_id, credenciais_json, status_conexao)
      VALUES (?, ?, ?, 'conectado')
      ON CONFLICT(instituicao_id) DO UPDATE SET
        credenciais_json = excluded.credenciais_json,
        status_conexao = excluded.status_conexao,
        updated_at = CURRENT_TIMESTAMP
    `).bind(userRecord.instituicao_id, instituicao.conector_erp_id, JSON.stringify(credenciais)).run();

    return c.json({ success: true, message: 'Credenciais salvas com sucesso!' });
  } catch (error) {
    console.error('Erro ao salvar credenciais ERP:', error);
    return c.json({ success: false, message: 'Erro ao salvar credenciais' }, 500);
  }
});

// ERP - Logs
app.get('/api/escola/erp/logs', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;

  try {
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM log_sincronizacoes WHERE instituicao_id = ? ORDER BY created_at DESC LIMIT 20'
    ).bind(userRecord.instituicao_id).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar logs de sincronização:', error);
    return c.json({ success: false, message: 'Erro ao buscar logs' }, 500);
  }
});

// ERP - Sincronizar
app.post('/api/escola/erp/sincronizar', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;

  try {
    // Aqui implementaríamos a lógica de sincronização
    await c.env.DB.prepare(`
      INSERT INTO log_sincronizacoes (instituicao_id, tipo_operacao, status, registros_processados)
      VALUES (?, 'sincronizacao_completa', 'sucesso', 0)
    `).bind(userRecord.instituicao_id).run();

    return c.json({ success: true, message: 'Sincronização iniciada!' });
  } catch (error) {
    console.error('Erro na sincronização:', error);
    return c.json({ success: false, message: 'Erro na sincronização' }, 500);
  }
});

// Status da Sincronização
app.get('/api/escola/sincronizacao/status', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;

  try {
    const credenciais = await c.env.DB.prepare(
      'SELECT status_conexao, ultima_sincronizacao FROM credenciais_erp WHERE instituicao_id = ?'
    ).bind(userRecord.instituicao_id).first() as any;

    const ultimoLog = await c.env.DB.prepare(
      'SELECT registros_processados FROM log_sincronizacoes WHERE instituicao_id = ? ORDER BY created_at DESC LIMIT 1'
    ).bind(userRecord.instituicao_id).first() as any;

    const status = {
      status_conexao: credenciais?.status_conexao || 'nao_configurado',
      ultima_sincronizacao: credenciais?.ultima_sincronizacao || null,
      registros_processados: ultimoLog?.registros_processados || 0
    };

    return c.json({ success: true, data: status });
  } catch (error) {
    console.error('Erro ao buscar status da sincronização:', error);
    return c.json({ success: false, message: 'Erro ao buscar status' }, 500);
  }
});

// ========================================
// ROUTES GESTÃO DE SOLUÇÕES (ESCOLA) - TODAS PROTEGIDAS
// ========================================

// Listar soluções licenciadas para a instituição - PROTEGIDO COM MIDDLEWARE
app.get('/api/escola/solucoes/licenciadas', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;

  try {
    const { results } = await c.env.DB.prepare(`
      SELECT s.id, s.nome, s.descricao_breve, s.url_icone, s.url_aplicacao
      FROM solucoes s
      INNER JOIN licencas_instituicoes li ON s.id = li.solucao_id
      WHERE li.instituicao_id = ? AND li.is_ativa = 1 AND s.status = 'ativa'
      ORDER BY s.nome
    `).bind(userRecord.instituicao_id).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar soluções licenciadas:', error);
    return c.json({ success: false, message: 'Erro ao buscar soluções' }, 500);
  }
});

// Buscar informações de uma solução específica
app.get('/api/escola/solucoes/:id', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;
  const solucaoId = c.req.param('id');

  try {
    // Verificar se a instituição tem licença para esta solução
    const licenca = await c.env.DB.prepare(`
      SELECT li.id FROM licencas_instituicoes li
      INNER JOIN solucoes s ON li.solucao_id = s.id
      WHERE li.instituicao_id = ? AND li.solucao_id = ? AND li.is_ativa = 1 AND s.status = 'ativa'
    `).bind(userRecord.instituicao_id, solucaoId).first();

    if (!licenca) {
      return c.json({ success: false, message: 'Solução não licenciada para esta instituição' }, 403);
    }

    // Buscar informações da solução
    const solucao = await c.env.DB.prepare(
      'SELECT id, nome, descricao_breve FROM solucoes WHERE id = ?'
    ).bind(solucaoId).first();

    if (!solucao) {
      return c.json({ success: false, message: 'Solução não encontrada' }, 404);
    }

    return c.json({ success: true, data: solucao });
  } catch (error) {
    console.error('Erro ao buscar solução:', error);
    return c.json({ success: false, message: 'Erro ao buscar solução' }, 500);
  }
});

// Buscar perfis de uma solução
app.get('/api/escola/solucoes/:id/perfis', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;
  const solucaoId = c.req.param('id');

  try {
    // Verificar se a instituição tem licença para esta solução
    const licenca = await c.env.DB.prepare(`
      SELECT li.id FROM licencas_instituicoes li
      INNER JOIN solucoes s ON li.solucao_id = s.id
      WHERE li.instituicao_id = ? AND li.solucao_id = ? AND li.is_ativa = 1 AND s.status = 'ativa'
    `).bind(userRecord.instituicao_id, solucaoId).first();

    if (!licenca) {
      return c.json({ success: false, message: 'Solução não licenciada para esta instituição' }, 403);
    }

    // Buscar perfis da solução
    const { results } = await c.env.DB.prepare(
      'SELECT id, nome_perfil, descricao_perfil FROM perfis_solucoes WHERE solucao_id = ? ORDER BY nome_perfil'
    ).bind(solucaoId).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar perfis da solução:', error);
    return c.json({ success: false, message: 'Erro ao buscar perfis' }, 500);
  }
});

// Buscar usuários da escola
app.get('/api/escola/usuarios', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;

  try {
    const { results } = await c.env.DB.prepare(
      'SELECT id, nome, email, tipo_usuario FROM usuarios_escola WHERE instituicao_id = ? AND is_ativo = 1 ORDER BY nome'
    ).bind(userRecord.instituicao_id).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar usuários da escola:', error);
    return c.json({ success: false, message: 'Erro ao buscar usuários' }, 500);
  }
});

// Buscar atribuições atuais de perfis para uma solução
app.get('/api/escola/solucoes/:id/atribuicoes', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;
  const solucaoId = c.req.param('id');

  try {
    // Verificar se a instituição tem licença para esta solução
    const licenca = await c.env.DB.prepare(`
      SELECT li.id FROM licencas_instituicoes li
      INNER JOIN solucoes s ON li.solucao_id = s.id
      WHERE li.instituicao_id = ? AND li.solucao_id = ? AND li.is_ativa = 1 AND s.status = 'ativa'
    `).bind(userRecord.instituicao_id, solucaoId).first();

    if (!licenca) {
      return c.json({ success: false, message: 'Solução não licenciada para esta instituição' }, 403);
    }

    // Buscar atribuições existentes
    const { results } = await c.env.DB.prepare(`
      SELECT ap.usuario_id, ap.perfil_solucao_id, ps.nome_perfil
      FROM atribuicoes_perfis ap
      LEFT JOIN perfis_solucoes ps ON ap.perfil_solucao_id = ps.id
      WHERE ap.instituicao_id = ? AND ap.solucao_id = ?
    `).bind(userRecord.instituicao_id, solucaoId).all();

    return c.json({ success: true, data: results });
  } catch (error) {
    console.error('Erro ao buscar atribuições:', error);
    return c.json({ success: false, message: 'Erro ao buscar atribuições' }, 500);
  }
});

// Atualizar atribuições de perfis para uma solução
app.put('/api/escola/solucoes/:id/atribuicoes', requireAuth, requireInstituicaoAdmin, async (c) => {
  const userRecord = c.get('userRecord') as UserRecord;
  const solucaoId = c.req.param('id');
  const { atribuicoes } = await c.req.json();

  try {
    // Verificar se a instituição tem licença para esta solução
    const licenca = await c.env.DB.prepare(`
      SELECT li.id FROM licencas_instituicoes li
      INNER JOIN solucoes s ON li.solucao_id = s.id
      WHERE li.instituicao_id = ? AND li.solucao_id = ? AND li.is_ativa = 1 AND s.status = 'ativa'
    `).bind(userRecord.instituicao_id, solucaoId).first();

    if (!licenca) {
      return c.json({ success: false, message: 'Solução não licenciada para esta instituição' }, 403);
    }

    // Processar cada atribuição
    for (const atribuicao of atribuicoes) {
      const { usuario_id, perfil_solucao_id } = atribuicao;

      if (perfil_solucao_id === null) {
        // Remover acesso - deletar atribuição
        await c.env.DB.prepare(
          'DELETE FROM atribuicoes_perfis WHERE usuario_id = ? AND solucao_id = ? AND instituicao_id = ?'
        ).bind(usuario_id, solucaoId, userRecord.instituicao_id).run();
      } else {
        // Atribuir perfil - upsert
        await c.env.DB.prepare(`
          INSERT INTO atribuicoes_perfis (usuario_id, solucao_id, perfil_solucao_id, instituicao_id)
          VALUES (?, ?, ?, ?)
          ON CONFLICT(usuario_id, solucao_id) DO UPDATE SET
            perfil_solucao_id = excluded.perfil_solucao_id,
            updated_at = CURRENT_TIMESTAMP
        `).bind(usuario_id, solucaoId, perfil_solucao_id, userRecord.instituicao_id).run();
      }
    }

    return c.json({ success: true, message: 'Atribuições atualizadas com sucesso!' });
  } catch (error) {
    console.error('Erro ao atualizar atribuições:', error);
    return c.json({ success: false, message: 'Erro ao atualizar atribuições' }, 500);
  }
});

// Static file serving
app.get('*', serveStatic({ 
  root: './dist',
  manifest: {}
}));

export default app;
