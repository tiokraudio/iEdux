import z from "zod";

/**
 * Types for Gestão da Escola (Admin da Instituição)
 */

// Usuários da Escola Types
export const UsuarioEscolaSchema = z.object({
  nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("E-mail inválido"),
  tipo_usuario: z.enum(["professor", "coordenador", "diretor", "secretario", "porteiro", "outro"]),
  is_ativo: z.boolean().default(true),
});

export type UsuarioEscolaType = z.infer<typeof UsuarioEscolaSchema>;

export interface UsuarioEscolaRecord extends UsuarioEscolaType {
  id: number;
  instituicao_id: number;
  created_at: string;
  updated_at: string;
}

// Alunos Types
export const AlunoSchema = z.object({
  nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  data_nascimento: z.string().optional(),
  cpf: z.string().optional(),
  email: z.string().email().optional(),
  telefone: z.string().optional(),
  endereco: z.string().optional(),
  turma_id: z.number().optional(),
  is_ativo: z.boolean().default(true),
});

export type AlunoType = z.infer<typeof AlunoSchema>;

export interface AlunoRecord extends AlunoType {
  id: number;
  instituicao_id: number;
  created_at: string;
  updated_at: string;
}

// Responsáveis Types
export const ResponsavelSchema = z.object({
  nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email().optional(),
  telefone: z.string().optional(),
  cpf: z.string().optional(),
  parentesco: z.enum(["pai", "mae", "avo", "ava", "tio", "tia", "irmao", "irma", "outro"]),
  is_ativo: z.boolean().default(true),
});

export type ResponsavelType = z.infer<typeof ResponsavelSchema>;

export interface ResponsavelRecord extends ResponsavelType {
  id: number;
  instituicao_id: number;
  created_at: string;
  updated_at: string;
}

// Turmas Types
export const TurmaSchema = z.object({
  nome: z.string().min(1, "Nome é obrigatório"),
  ano_letivo: z.string().min(4, "Ano letivo deve ter 4 dígitos"),
  serie: z.string().optional(),
  periodo: z.enum(["matutino", "vespertino", "noturno", "integral"]),
  capacidade_maxima: z.number().positive().optional(),
  is_ativa: z.boolean().default(true),
});

export type TurmaType = z.infer<typeof TurmaSchema>;

export interface TurmaRecord extends TurmaType {
  id: number;
  instituicao_id: number;
  created_at: string;
  updated_at: string;
}

// Disciplinas Types
export const DisciplinaSchema = z.object({
  nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  codigo: z.string().optional(),
  carga_horaria: z.number().positive().optional(),
  is_ativa: z.boolean().default(true),
});

export type DisciplinaType = z.infer<typeof DisciplinaSchema>;

export interface DisciplinaRecord extends DisciplinaType {
  id: number;
  instituicao_id: number;
  created_at: string;
  updated_at: string;
}

// Credenciais ERP Types
export const CredenciaisErpSchema = z.object({
  credenciais_json: z.string(), // JSON string com as credenciais
});

export type CredenciaisErpType = z.infer<typeof CredenciaisErpSchema>;

export interface CredenciaisErpRecord extends CredenciaisErpType {
  id: number;
  instituicao_id: number;
  conector_erp_id: number;
  status_conexao: string;
  ultima_sincronizacao: string | null;
  created_at: string;
  updated_at: string;
}

// Log de Sincronizações Types
export interface LogSincronizacaoRecord {
  id: number;
  instituicao_id: number;
  tipo_operacao: string;
  status: string;
  detalhes: string | null;
  registros_processados: number;
  created_at: string;
}

// Response Types
export const EscolaResponseSchema = z.object({
  success: z.boolean(),
  message: z.string().optional(),
  data: z.any().optional(),
});

export type EscolaResponseType = z.infer<typeof EscolaResponseSchema>;

// Vinculação Aluno-Responsável Types
export const AlunoResponsavelSchema = z.object({
  aluno_id: z.number(),
  responsavel_id: z.number(),
  is_principal: z.boolean().default(false),
});

export type AlunoResponsavelType = z.infer<typeof AlunoResponsavelSchema>;

export interface AlunoResponsavelRecord extends AlunoResponsavelType {
  id: number;
  created_at: string;
}
