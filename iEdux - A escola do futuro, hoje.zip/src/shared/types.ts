import z from "zod";

/**
 * Types shared between the client and server go here.
 */

export const ContatoSchema = z.object({
  nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("E-mail inválido"),
  instituicao: z.string().min(2, "Nome da instituição deve ter pelo menos 2 caracteres"),
  cargo: z.string().min(1, "Cargo é obrigatório"),
  telefone: z.string().min(10, "Telefone deve ter pelo menos 10 caracteres"),
  mensagem: z.string().optional(),
});

export type ContatoType = z.infer<typeof ContatoSchema>;

export const ContatoResponseSchema = z.object({
  success: z.boolean(),
  message: z.string(),
});

export type ContatoResponseType = z.infer<typeof ContatoResponseSchema>;
