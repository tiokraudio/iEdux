import z from "zod";

/**
 * Types for Super Admin panel
 */

export const InstituicaoSchema = z.object({
  nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  status: z.enum(["ativa", "inativa"]),
  modo_dados: z.enum(["manual", "erp"]),
  conector_erp_id: z.number().optional(),
});

export type InstituicaoType = z.infer<typeof InstituicaoSchema>;

export interface InstituicaoRecord extends InstituicaoType {
  id: number;
  created_at: string;
  updated_at: string;
}

export const InstituicaoResponseSchema = z.object({
  success: z.boolean(),
  message: z.string().optional(),
  data: z.any().optional(),
});

export type InstituicaoResponseType = z.infer<typeof InstituicaoResponseSchema>;

// Conectores ERP Types
export const ConectorErpSchema = z.object({
  nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  status: z.enum(["ativo", "inativo"]),
  descricao_breve: z.string().optional(),
  campos_credenciais: z.string().optional(),
});

export type ConectorErpType = z.infer<typeof ConectorErpSchema>;

export interface ConectorErpRecord extends ConectorErpType {
  id: number;
  created_at: string;
  updated_at: string;
}

export const ConectorErpResponseSchema = z.object({
  success: z.boolean(),
  message: z.string().optional(),
  data: z.any().optional(),
});

export type ConectorErpResponseType = z.infer<typeof ConectorErpResponseSchema>;

// Soluções Types
export const SolucaoSchema = z.object({
  nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  status: z.enum(["ativa", "inativa"]),
  descricao_breve: z.string().optional(),
  url_aplicacao: z.string().optional(),
  url_icone: z.string().optional(),
});

export type SolucaoType = z.infer<typeof SolucaoSchema>;

export interface SolucaoRecord extends SolucaoType {
  id: number;
  created_at: string;
  updated_at: string;
}

export const SolucaoResponseSchema = z.object({
  success: z.boolean(),
  message: z.string().optional(),
  data: z.any().optional(),
});

export type SolucaoResponseType = z.infer<typeof SolucaoResponseSchema>;

// Perfis de Soluções Types
export const PerfilSolucaoSchema = z.object({
  solucao_id: z.number(),
  nome_perfil: z.string().min(2, "Nome do perfil deve ter pelo menos 2 caracteres"),
  descricao_perfil: z.string().optional(),
});

export type PerfilSolucaoType = z.infer<typeof PerfilSolucaoSchema>;

export interface PerfilSolucaoRecord extends PerfilSolucaoType {
  id: number;
  created_at: string;
  updated_at: string;
}

// Licenças de Instituições Types
export const LicencaInstituicaoSchema = z.object({
  instituicao_id: z.number(),
  solucao_id: z.number(),
  is_ativa: z.boolean().default(true),
});

export type LicencaInstituicaoType = z.infer<typeof LicencaInstituicaoSchema>;

export interface LicencaInstituicaoRecord extends LicencaInstituicaoType {
  id: number;
  created_at: string;
  updated_at: string;
}

export interface SolucaoComLicencaRecord extends SolucaoRecord {
  tem_licenca: boolean;
}
