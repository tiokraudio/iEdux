import { useAuth as useMochaAuth } from '@getmocha/users-service/react';
import { useEffect, useState } from 'react';

interface UserProfile {
  email: string;
  nome: string;
  perfil: string;
  instituicao_id: number | null;
  authorized: boolean;
  google_user_data?: any;
}

export function useAuth() {
  const { user: mochaUser, isPending: isMochaLoading, redirectToLogin } = useMochaAuth();
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const fetchUserProfile = async () => {
      // CORREÇÃO 1: Se não está carregando e não tem utilizador Mocha, marcar como não autenticado IMEDIATAMENTE
      if (!isMochaLoading && !mochaUser) {
        console.log('❌ Nenhum token de sessão encontrado - utilizador anónimo');
        setIsLoading(false);
        setUserProfile(null);
        setError('');
        return;
      }

      // Se ainda está carregando o Mocha, aguardar
      if (isMochaLoading) {
        setIsLoading(true);
        return;
      }

      // Se chegou aqui, tem utilizador Mocha válido
      if (mochaUser) {
        try {
          setError('');
          console.log('🔐 Verificando perfil do utilizador autenticado...');
          
          const response = await fetch('/api/users/me', {
            credentials: 'include'
          });

          if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
          }

          const userData = await response.json();
          console.log('👤 Dados do utilizador recebidos:', userData);

          if (!userData.authorized) {
            console.log('❌ Utilizador não autorizado');
            setError('Acesso negado: E-mail não cadastrado no sistema');
            setUserProfile(null);
          } else {
            console.log('✅ Utilizador autorizado com perfil:', userData.perfil);
            setUserProfile(userData);
          }
        } catch (err) {
          console.error('💥 Erro ao verificar perfil:', err);
          setError('Erro ao verificar permissões do utilizador');
          setUserProfile(null);
        } finally {
          setIsLoading(false);
        }
      }
    };

    fetchUserProfile();
  }, [mochaUser, isMochaLoading]);

  const logout = async () => {
    try {
      await fetch('/api/logout', { credentials: 'include' });
      setUserProfile(null);
      window.location.href = '/login';
    } catch (error) {
      console.error('Erro no logout:', error);
      // Forçar redirecionamento mesmo com erro
      window.location.href = '/login';
    }
  };

  // CORREÇÃO 2: isAuthenticated deve ser verdadeiro APENAS se tem mochaUser E userProfile autorizado
  const isAuthenticated = !!(mochaUser && userProfile && userProfile.authorized);

  return {
    user: userProfile,
    isLoading,
    error,
    redirectToLogin,
    logout,
    isAuthenticated,
    isSuperAdmin: userProfile?.perfil === 'Super Admin',
    isInstituicaoAdmin: userProfile?.perfil === 'Admin Instituição',
    isEndUser: userProfile && !['Super Admin', 'Admin Instituição'].includes(userProfile.perfil)
  };
}
