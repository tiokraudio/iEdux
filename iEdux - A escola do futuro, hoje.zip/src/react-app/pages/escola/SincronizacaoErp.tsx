import { useState, useEffect } from 'react';
import InstituicaoLayout from '@/react-app/components/admin/InstituicaoLayout';
import {
  Settings,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Clock,
  Database,
  RotateCcw,
  Eye,
  EyeOff,
  Save,
  Play
} from 'lucide-react';

interface ConectorInfo {
  id: number;
  nome: string;
  campos_credenciais: string;
}

interface CredenciaisErp {
  status_conexao: string;
  ultima_sincronizacao: string | null;
  credenciais_json: string | null;
}

interface LogSincronizacao {
  id: number;
  tipo_operacao: string;
  status: string;
  detalhes: string | null;
  registros_processados: number;
  created_at: string;
}

export default function SincronizacaoErp() {
  const [activeTab, setActiveTab] = useState('configuracao');
  const [conectorInfo, setConectorInfo] = useState<ConectorInfo | null>(null);
  const [credenciais, setCredenciais] = useState<CredenciaisErp | null>(null);
  const [logs, setLogs] = useState<LogSincronizacao[]>([]);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [conectorResponse, credenciaisResponse, logsResponse] = await Promise.all([
        fetch('/api/escola/erp/conector', { credentials: 'include' }),
        fetch('/api/escola/erp/credenciais', { credentials: 'include' }),
        fetch('/api/escola/erp/logs', { credentials: 'include' })
      ]);

      const [conectorData, credenciaisData, logsData] = await Promise.all([
        conectorResponse.json(),
        credenciaisResponse.json(),
        logsResponse.json()
      ]);

      if (conectorData.success) {
        setConectorInfo(conectorData.data);
        
        // Parse dos campos de credenciais
        if (conectorData.data?.campos_credenciais) {
          try {
            const campos = JSON.parse(conectorData.data.campos_credenciais);
            const initialFormData: Record<string, string> = {};
            campos.forEach((campo: any) => {
              initialFormData[campo.name] = '';
            });
            setFormData(initialFormData);
          } catch (error) {
            console.error('Erro ao fazer parse dos campos de credenciais:', error);
          }
        }
      }

      if (credenciaisData.success) {
        setCredenciais(credenciaisData.data);
        
        // Se já existem credenciais, preencher o formulário
        if (credenciaisData.data?.credenciais_json) {
          try {
            const credenciaisExistentes = JSON.parse(credenciaisData.data.credenciais_json);
            setFormData(credenciaisExistentes);
          } catch (error) {
            console.error('Erro ao fazer parse das credenciais existentes:', error);
          }
        }
      }

      if (logsData.success) {
        setLogs(logsData.data);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveCredentials = async () => {
    setIsSaving(true);
    try {
      const response = await fetch('/api/escola/erp/credenciais', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ credenciais: formData })
      });

      const result = await response.json();
      if (result.success) {
        await fetchData(); // Recarregar dados
        alert('Credenciais salvas com sucesso!');
      } else {
        alert(result.message || 'Erro ao salvar credenciais');
      }
    } catch (error) {
      console.error('Erro ao salvar credenciais:', error);
      alert('Erro ao salvar credenciais');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSync = async () => {
    setIsSyncing(true);
    try {
      const response = await fetch('/api/escola/erp/sincronizar', {
        method: 'POST',
        credentials: 'include'
      });

      const result = await response.json();
      if (result.success) {
        await fetchData(); // Recarregar dados
        alert('Sincronização iniciada com sucesso!');
      } else {
        alert(result.message || 'Erro ao iniciar sincronização');
      }
    } catch (error) {
      console.error('Erro na sincronização:', error);
      alert('Erro na sincronização');
    } finally {
      setIsSyncing(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'conectado':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'erro':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Clock className="w-5 h-5 text-yellow-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'conectado':
        return 'Conectado';
      case 'erro':
        return 'Erro de Conexão';
      default:
        return 'Não Configurado';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'conectado':
        return 'text-green-600';
      case 'erro':
        return 'text-red-600';
      default:
        return 'text-yellow-600';
    }
  };

  const renderConfigurationTab = () => {
    if (!conectorInfo) {
      return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="text-center">
            <AlertCircle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Conector ERP não configurado
            </h3>
            <p className="text-gray-600">
              Entre em contato com o Super Admin para configurar o conector ERP desta instituição.
            </p>
          </div>
        </div>
      );
    }

    let campos: any[] = [];
    try {
      campos = JSON.parse(conectorInfo.campos_credenciais || '[]');
    } catch (error) {
      console.error('Erro ao fazer parse dos campos:', error);
    }

    return (
      <div className="space-y-6">
        {/* Status da Conexão */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Status da Conexão - {conectorInfo.nome}
          </h3>
          
          <div className="flex items-center space-x-3 mb-4">
            {getStatusIcon(credenciais?.status_conexao || 'nao_configurado')}
            <div>
              <p className="font-semibold text-gray-900">
                {getStatusText(credenciais?.status_conexao || 'nao_configurado')}
              </p>
              <p className={`text-sm ${getStatusColor(credenciais?.status_conexao || 'nao_configurado')}`}>
                {credenciais?.ultima_sincronizacao
                  ? `Última sincronização: ${new Date(credenciais.ultima_sincronizacao).toLocaleString('pt-BR')}`
                  : 'Nunca sincronizado'
                }
              </p>
            </div>
          </div>
        </div>

        {/* Formulário de Credenciais */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Configuração das Credenciais
          </h3>
          
          <div className="space-y-4">
            {campos.map((campo: any) => (
              <div key={campo.name}>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {campo.label}
                  {campo.required && <span className="text-red-500 ml-1">*</span>}
                </label>
                
                <div className="relative">
                  <input
                    type={campo.type === 'password' && !showPasswords[campo.name] ? 'password' : 'text'}
                    value={formData[campo.name] || ''}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      [campo.name]: e.target.value
                    }))}
                    placeholder={campo.placeholder}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                  />
                  
                  {campo.type === 'password' && (
                    <button
                      type="button"
                      onClick={() => setShowPasswords(prev => ({
                        ...prev,
                        [campo.name]: !prev[campo.name]
                      }))}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    >
                      {showPasswords[campo.name] ? (
                        <EyeOff className="w-5 h-5" />
                      ) : (
                        <Eye className="w-5 h-5" />
                      )}
                    </button>
                  )}
                </div>
                
                {campo.description && (
                  <p className="text-sm text-gray-600 mt-1">{campo.description}</p>
                )}
              </div>
            ))}
          </div>

          <div className="flex justify-end space-x-4 mt-6">
            <button
              onClick={handleSaveCredentials}
              disabled={isSaving}
              className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSaving ? (
                <RotateCcw className="w-5 h-5 animate-spin" />
              ) : (
                <Save className="w-5 h-5" />
              )}
              <span>{isSaving ? 'Salvando...' : 'Salvar Credenciais'}</span>
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderSyncTab = () => (
    <div className="space-y-6">
      {/* Controles de Sincronização */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Controles de Sincronização
        </h3>
        
        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium text-gray-900">Sincronização Manual</p>
            <p className="text-sm text-gray-600">
              Execute uma sincronização completa dos dados do ERP
            </p>
          </div>
          
          <button
            onClick={handleSync}
            disabled={isSyncing || credenciais?.status_conexao !== 'conectado'}
            className="flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSyncing ? (
              <RotateCcw className="w-5 h-5 animate-spin" />
            ) : (
              <Play className="w-5 h-5" />
            )}
            <span>{isSyncing ? 'Sincronizando...' : 'Sincronizar Agora'}</span>
          </button>
        </div>
      </div>

      {/* Histórico de Sincronizações */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Histórico de Sincronizações
        </h3>
        
        {logs.length === 0 ? (
          <div className="text-center py-8">
            <Database className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Nenhuma sincronização realizada ainda</p>
          </div>
        ) : (
          <div className="space-y-3">
            {logs.map((log) => (
              <div
                key={log.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center space-x-3">
                  {log.status === 'sucesso' ? (
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  ) : log.status === 'erro' ? (
                    <AlertCircle className="w-5 h-5 text-red-500" />
                  ) : (
                    <Clock className="w-5 h-5 text-yellow-500" />
                  )}
                  
                  <div>
                    <p className="font-medium text-gray-900">
                      {log.tipo_operacao === 'sincronizacao_completa' ? 'Sincronização Completa' : 'Sincronização Incremental'}
                    </p>
                    <p className="text-sm text-gray-600">
                      {new Date(log.created_at).toLocaleString('pt-BR')} • {log.registros_processados} registros
                    </p>
                  </div>
                </div>
                
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  log.status === 'sucesso' ? 'bg-green-100 text-green-700' :
                  log.status === 'erro' ? 'bg-red-100 text-red-700' :
                  'bg-yellow-100 text-yellow-700'
                }`}>
                  {log.status === 'sucesso' ? 'Sucesso' :
                   log.status === 'erro' ? 'Erro' : 'Em Andamento'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  if (isLoading) {
    return (
      <InstituicaoLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </InstituicaoLayout>
    );
  }

  return (
    <InstituicaoLayout>
      <div className="max-w-4xl mx-auto">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Sincronização ERP</h1>
          <p className="text-gray-600">
            Configure a conexão com seu sistema ERP e monitore as sincronizações
          </p>
        </div>

        {/* Tabs */}
        <div className="mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              <button
                onClick={() => setActiveTab('configuracao')}
                className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === 'configuracao'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Settings className="w-5 h-5" />
                <span>Configuração</span>
              </button>
              
              <button
                onClick={() => setActiveTab('sincronizacao')}
                className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === 'sincronizacao'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <RefreshCw className="w-5 h-5" />
                <span>Sincronização</span>
              </button>
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'configuracao' ? renderConfigurationTab() : renderSyncTab()}
      </div>
    </InstituicaoLayout>
  );
}
