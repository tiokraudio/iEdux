import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router';
import InstituicaoLayout from '@/react-app/components/admin/InstituicaoLayout';
import {
  ArrowLeft,
  Users,
  Save,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

interface UsuarioEscola {
  id: number;
  nome: string;
  email: string;
  tipo_usuario: string;
  perfil_atual_id?: number;
  perfil_atual_nome?: string;
}

interface PerfilSolucao {
  id: number;
  nome_perfil: string;
  descricao_perfil: string | null;
}

interface SolucaoInfo {
  id: number;
  nome: string;
  descricao_breve: string | null;
}

interface AtribuicaoAlterada {
  usuario_id: number;
  perfil_solucao_id: number | null; // null = sem acesso
}

export default function GerirAcessos() {
  const { id: solucaoId } = useParams();
  const [solucaoInfo, setSolucaoInfo] = useState<SolucaoInfo | null>(null);
  const [usuarios, setUsuarios] = useState<UsuarioEscola[]>([]);
  const [perfis, setPerfis] = useState<PerfilSolucao[]>([]);
  const [atribuicoes, setAtribuicoes] = useState<Record<number, number | null>>({});
  const [atribuicoesOriginais, setAtribuicoesOriginais] = useState<Record<number, number | null>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<{type: string, message: string} | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (solucaoId) {
      fetchData();
    }
  }, [solucaoId]);

  const fetchData = async () => {
    try {
      const [solucaoResponse, usuariosResponse, perfisResponse, atribuicoesResponse] = await Promise.all([
        fetch(`/api/escola/solucoes/${solucaoId}`, { credentials: 'include' }),
        fetch('/api/escola/usuarios', { credentials: 'include' }),
        fetch(`/api/escola/solucoes/${solucaoId}/perfis`, { credentials: 'include' }),
        fetch(`/api/escola/solucoes/${solucaoId}/atribuicoes`, { credentials: 'include' })
      ]);

      const [solucaoData, usuariosData, perfisData, atribuicoesData] = await Promise.all([
        solucaoResponse.json(),
        usuariosResponse.json(),
        perfisResponse.json(),
        atribuicoesResponse.json()
      ]);

      if (solucaoData.success) setSolucaoInfo(solucaoData.data);
      if (usuariosData.success) setUsuarios(usuariosData.data);
      if (perfisData.success) setPerfis(perfisData.data);
      
      if (atribuicoesData.success) {
        const atribuicoesMap: Record<number, number | null> = {};
        atribuicoesData.data.forEach((attr: any) => {
          atribuicoesMap[attr.usuario_id] = attr.perfil_solucao_id;
        });
        setAtribuicoes(atribuicoesMap);
        setAtribuicoesOriginais(atribuicoesMap);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePerfilChange = (usuarioId: number, perfilId: string) => {
    const newPerfilId = perfilId === 'sem_acesso' ? null : parseInt(perfilId);
    setAtribuicoes(prev => ({
      ...prev,
      [usuarioId]: newPerfilId
    }));
  };

  const hasChanges = () => {
    return JSON.stringify(atribuicoes) !== JSON.stringify(atribuicoesOriginais);
  };

  const handleSave = async () => {
    if (!hasChanges()) return;

    setIsSaving(true);
    setSaveMessage(null);

    try {
      // Preparar dados das alterações
      const alteracoes: AtribuicaoAlterada[] = [];
      
      Object.keys(atribuicoes).forEach(usuarioIdStr => {
        const usuarioId = parseInt(usuarioIdStr);
        const perfilAtual = atribuicoes[usuarioId];
        const perfilOriginal = atribuicoesOriginais[usuarioId];
        
        if (perfilAtual !== perfilOriginal) {
          alteracoes.push({
            usuario_id: usuarioId,
            perfil_solucao_id: perfilAtual
          });
        }
      });

      const response = await fetch(`/api/escola/solucoes/${solucaoId}/atribuicoes`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ atribuicoes: alteracoes })
      });

      const result = await response.json();
      
      if (result.success) {
        setAtribuicoesOriginais({ ...atribuicoes });
        setSaveMessage({
          type: 'success',
          message: 'Alterações salvas com sucesso!'
        });
        
        // Limpar mensagem após 3 segundos
        setTimeout(() => setSaveMessage(null), 3000);
      } else {
        setSaveMessage({
          type: 'error',
          message: result.message || 'Erro ao salvar alterações'
        });
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
      setSaveMessage({
        type: 'error',
        message: 'Erro ao salvar alterações'
      });
    } finally {
      setIsSaving(false);
    }
  };

  

  if (isLoading) {
    return (
      <InstituicaoLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </InstituicaoLayout>
    );
  }

  if (!solucaoInfo) {
    return (
      <InstituicaoLayout>
        <div className="max-w-4xl mx-auto text-center py-12">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">
            Solução não encontrada
          </h2>
          <p className="text-gray-600 mb-4">
            A solução solicitada não foi encontrada ou sua instituição não possui licença para ela.
          </p>
          <Link
            to="/painel-escola/solucoes"
            className="inline-flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar para Soluções</span>
          </Link>
        </div>
      </InstituicaoLayout>
    );
  }

  return (
    <InstituicaoLayout>
      <div className="max-w-6xl mx-auto">
        {/* Header with Back Button */}
        <div className="mb-6">
          <Link
            to="/painel-escola/solucoes"
            className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar para Soluções</span>
          </Link>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Gerir Acessos para: {solucaoInfo.nome}
          </h1>
          <p className="text-gray-600">
            {solucaoInfo.descricao_breve || 'Configure os perfis de acesso dos usuários para esta solução'}
          </p>
        </div>

        {/* Save Message */}
        {saveMessage && (
          <div className={`mb-6 p-4 rounded-lg flex items-center space-x-3 ${
            saveMessage.type === 'success' ? 'bg-green-50 border border-green-200' :
            'bg-red-50 border border-red-200'
          }`}>
            {saveMessage.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-green-600" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-600" />
            )}
            <span className={`font-medium ${
              saveMessage.type === 'success' ? 'text-green-700' : 'text-red-700'
            }`}>
              {saveMessage.message}
            </span>
          </div>
        )}

        {/* Save Button (when there are changes) */}
        {hasChanges() && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <AlertCircle className="w-5 h-5 text-blue-600" />
                <span className="text-blue-700 font-medium">
                  Você tem alterações não salvas
                </span>
              </div>
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSaving ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <Save className="w-4 h-4" />
                )}
                <span>{isSaving ? 'Salvando...' : 'Salvar Alterações'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Users Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
              <Users className="w-5 h-5" />
              <span>Usuários da Escola ({usuarios.length})</span>
            </h2>
          </div>

          {usuarios.length === 0 ? (
            <div className="p-8 text-center">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Nenhum usuário cadastrado
              </h3>
              <p className="text-gray-600">
                Cadastre usuários da escola na Secretaria Digital para atribuir acessos.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Usuário
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Tipo
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Perfil de Acesso
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {usuarios.map((usuario) => (
                    <tr key={usuario.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div>
                          <div className="text-sm font-medium text-gray-900">
                            {usuario.nome}
                          </div>
                          <div className="text-sm text-gray-500">
                            {usuario.email}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="px-2 py-1 text-xs font-semibold bg-gray-100 text-gray-700 rounded-full capitalize">
                          {usuario.tipo_usuario.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={atribuicoes[usuario.id] || 'sem_acesso'}
                          onChange={(e) => handlePerfilChange(usuario.id, e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        >
                          <option value="sem_acesso">Sem Acesso</option>
                          {perfis.map((perfil) => (
                            <option key={perfil.id} value={perfil.id}>
                              {perfil.nome_perfil}
                            </option>
                          ))}
                        </select>
                        
                        {perfis.length === 0 && (
                          <p className="text-xs text-gray-500 mt-1">
                            Nenhum perfil disponível para esta solução
                          </p>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Perfis Information */}
        {perfis.length > 0 && (
          <div className="mt-8 bg-gray-50 border border-gray-200 rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Perfis Disponíveis:</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {perfis.map((perfil) => (
                <div key={perfil.id} className="bg-white p-4 rounded-lg border">
                  <h4 className="font-semibold text-gray-900 mb-1">
                    {perfil.nome_perfil}
                  </h4>
                  <p className="text-sm text-gray-600">
                    {perfil.descricao_perfil || 'Sem descrição disponível'}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </InstituicaoLayout>
  );
}
