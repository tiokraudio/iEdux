import { useState, useEffect } from 'react';
import InstituicaoLayout from '@/react-app/components/admin/InstituicaoLayout';
import {
  Users,
  GraduationCap,
  UserCheck,
  Calendar,
  BookOpen,
  Database,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Clock,
  TrendingUp
} from 'lucide-react';

interface InstituicaoInfo {
  id: number;
  nome: string;
  modo_dados: 'manual' | 'erp';
}

interface DashboardStats {
  usuarios_escola: number;
  alunos: number;
  responsaveis: number;
  turmas: number;
  disciplinas: number;
}

interface SincronizacaoStatus {
  status_conexao: string;
  ultima_sincronizacao: string | null;
  registros_processados: number;
}

export default function EscolaDashboard() {
  const [instituicaoInfo, setInstituicaoInfo] = useState<InstituicaoInfo | null>(null);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [sincronizacaoStatus, setSincronizacaoStatus] = useState<SincronizacaoStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [infoResponse, statsResponse, syncResponse] = await Promise.all([
        fetch('/api/escola/info', { credentials: 'include' }),
        fetch('/api/escola/stats', { credentials: 'include' }),
        fetch('/api/escola/sincronizacao/status', { credentials: 'include' })
      ]);

      const [infoData, statsData, syncData] = await Promise.all([
        infoResponse.json(),
        statsResponse.json(),
        syncResponse.json()
      ]);

      if (infoData.success) setInstituicaoInfo(infoData.data);
      if (statsData.success) setStats(statsData.data);
      if (syncData.success) setSincronizacaoStatus(syncData.data);
    } catch (error) {
      console.error('Erro ao carregar dados do dashboard:', error);
      // Definir valores padrão em caso de erro
      setInstituicaoInfo({
        id: 1,
        nome: 'Instituição Demo',
        modo_dados: 'manual'
      });
      setStats({
        usuarios_escola: 0,
        alunos: 0,
        responsaveis: 0,
        turmas: 0,
        disciplinas: 0
      });
      setSincronizacaoStatus({
        status_conexao: 'nao_configurado',
        ultima_sincronizacao: null,
        registros_processados: 0
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderManualDashboard = () => (
    <div className="space-y-6">
      {/* Estatísticas Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Usuários da Escola</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">
                {stats?.usuarios_escola || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Alunos</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">
                {stats?.alunos || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Responsáveis</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">
                {stats?.responsaveis || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <UserCheck className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Turmas</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">
                {stats?.turmas || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Disciplinas</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">
                {stats?.disciplinas || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-pink-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Ações Rápidas */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Ações Rápidas</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <a
            href="/painel-escola/usuarios"
            className="flex items-center space-x-3 p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
          >
            <Users className="w-6 h-6 text-blue-600" />
            <div>
              <p className="font-semibold text-blue-900">Gerenciar Usuários</p>
              <p className="text-sm text-blue-600">Professores, funcionários</p>
            </div>
          </a>

          <a
            href="/painel-escola/alunos"
            className="flex items-center space-x-3 p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors"
          >
            <GraduationCap className="w-6 h-6 text-green-600" />
            <div>
              <p className="font-semibold text-green-900">Gerenciar Alunos</p>
              <p className="text-sm text-green-600">Cadastro e matrículas</p>
            </div>
          </a>

          <a
            href="/painel-escola/turmas"
            className="flex items-center space-x-3 p-4 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors"
          >
            <Calendar className="w-6 h-6 text-orange-600" />
            <div>
              <p className="font-semibold text-orange-900">Gerenciar Turmas</p>
              <p className="text-sm text-orange-600">Organizar classes</p>
            </div>
          </a>

          <a
            href="/painel-escola/secretaria"
            className="flex items-center space-x-3 p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors"
          >
            <Database className="w-6 h-6 text-purple-600" />
            <div>
              <p className="font-semibold text-purple-900">Secretaria Digital</p>
              <p className="text-sm text-purple-600">Importações em massa</p>
            </div>
          </a>
        </div>
      </div>
    </div>
  );

  const renderErpDashboard = () => (
    <div className="space-y-6">
      {/* Status da Conexão ERP */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Status da Sincronização ERP</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex items-center space-x-3">
            {sincronizacaoStatus?.status_conexao === 'conectado' ? (
              <CheckCircle className="w-8 h-8 text-green-500" />
            ) : sincronizacaoStatus?.status_conexao === 'erro' ? (
              <AlertCircle className="w-8 h-8 text-red-500" />
            ) : (
              <Clock className="w-8 h-8 text-yellow-500" />
            )}
            <div>
              <p className="font-semibold text-gray-900">Status da Conexão</p>
              <p className={`text-sm ${
                sincronizacaoStatus?.status_conexao === 'conectado' ? 'text-green-600' :
                sincronizacaoStatus?.status_conexao === 'erro' ? 'text-red-600' : 
                'text-yellow-600'
              }`}>
                {sincronizacaoStatus?.status_conexao === 'conectado' ? 'Conectado' :
                 sincronizacaoStatus?.status_conexao === 'erro' ? 'Erro de Conexão' :
                 'Não Configurado'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <RefreshCw className="w-8 h-8 text-blue-500" />
            <div>
              <p className="font-semibold text-gray-900">Última Sincronização</p>
              <p className="text-sm text-gray-600">
                {sincronizacaoStatus?.ultima_sincronizacao 
                  ? new Date(sincronizacaoStatus.ultima_sincronizacao).toLocaleString('pt-BR')
                  : 'Nunca sincronizado'
                }
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <TrendingUp className="w-8 h-8 text-purple-500" />
            <div>
              <p className="font-semibold text-gray-900">Registros Processados</p>
              <p className="text-sm text-gray-600">
                {sincronizacaoStatus?.registros_processados || 0} registros
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Estatísticas dos Dados ERP */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Usuários Sincronizados</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">
                {stats?.usuarios_escola || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Alunos Sincronizados</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">
                {stats?.alunos || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Turmas Sincronizadas</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">
                {stats?.turmas || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Disciplinas Sincronizadas</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">
                {stats?.disciplinas || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-pink-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Ações ERP */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Ações da Sincronização</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <a
            href="/painel-escola/sincronizacao"
            className="flex items-center space-x-3 p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
          >
            <RefreshCw className="w-6 h-6 text-blue-600" />
            <div>
              <p className="font-semibold text-blue-900">Configurar ERP</p>
              <p className="text-sm text-blue-600">Credenciais e conexão</p>
            </div>
          </a>

          <button
            onClick={() => {/* Implementar sincronização manual */}}
            className="flex items-center space-x-3 p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors"
          >
            <Database className="w-6 h-6 text-green-600" />
            <div>
              <p className="font-semibold text-green-900">Sincronizar Agora</p>
              <p className="text-sm text-green-600">Atualizar dados</p>
            </div>
          </button>

          <a
            href="/painel-escola/dados-erp"
            className="flex items-center space-x-3 p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors"
          >
            <Users className="w-6 h-6 text-purple-600" />
            <div>
              <p className="font-semibold text-purple-900">Visualizar Dados</p>
              <p className="text-sm text-purple-600">Ver dados sincronizados</p>
            </div>
          </a>
        </div>
      </div>
    </div>
  );

  if (isLoading) {
    return (
      <InstituicaoLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </InstituicaoLayout>
    );
  }

  return (
    <InstituicaoLayout>
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Dashboard - {instituicaoInfo?.nome}
          </h1>
          <p className="text-gray-600">
            {instituicaoInfo?.modo_dados === 'manual' 
              ? 'Gerencie os dados da sua instituição através da Secretaria Digital'
              : 'Monitore a sincronização automática dos dados do seu ERP'
            }
          </p>
        </div>

        {/* Dashboard Content */}
        {instituicaoInfo?.modo_dados === 'manual' ? renderManualDashboard() : renderErpDashboard()}
      </div>
    </InstituicaoLayout>
  );
}
