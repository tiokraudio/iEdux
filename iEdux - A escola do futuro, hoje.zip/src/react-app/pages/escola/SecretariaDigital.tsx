import { useState } from 'react';
import InstituicaoLayout from '@/react-app/components/admin/InstituicaoLayout';
import {
  Upload,
  Download,
  Users,
  GraduationCap,
  UserCheck,
  Calendar,
  BookOpen,
  FileSpreadsheet,
  Plus,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

export default function SecretariaDigital() {
  const [activeTab, setActiveTab] = useState('usuarios');
  const [uploadStatus, setUploadStatus] = useState<{type: string, message: string} | null>(null);

  const tabs = [
    { id: 'usuarios', label: 'Usuários da Escola', icon: Users },
    { id: 'alunos', label: 'Alunos', icon: GraduationCap },
    { id: 'responsaveis', label: 'Responsáveis', icon: UserCheck },
    { id: 'turmas', label: 'Turmas', icon: Calendar },
    { id: 'disciplinas', label: 'Disciplinas', icon: BookOpen },
  ];

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>, tipo: string) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Verificar se é um arquivo CSV ou Excel
    const allowedTypes = [
      'text/csv',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];

    if (!allowedTypes.includes(file.type)) {
      setUploadStatus({
        type: 'error',
        message: 'Formato de arquivo não suportado. Use CSV ou Excel (.xls/.xlsx)'
      });
      return;
    }

    setUploadStatus({
      type: 'loading',
      message: 'Processando arquivo...'
    });

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('tipo', tipo);

      const response = await fetch('/api/escola/importacao', {
        method: 'POST',
        credentials: 'include',
        body: formData
      });

      const result = await response.json();

      if (result.success) {
        setUploadStatus({
          type: 'success',
          message: `${result.data.processados} registros importados com sucesso!`
        });
      } else {
        setUploadStatus({
          type: 'error',
          message: result.message || 'Erro ao importar arquivo'
        });
      }
    } catch (error) {
      setUploadStatus({
        type: 'error',
        message: 'Erro ao processar arquivo'
      });
    }

    // Limpar o input file
    event.target.value = '';

    // Limpar status após 5 segundos
    setTimeout(() => setUploadStatus(null), 5000);
  };

  const downloadTemplate = (tipo: string) => {
    // Criar templates CSV para download
    const templates = {
      usuarios: `nome,email,tipo_usuario
João Silva,joao@escola.com,professor
Maria Santos,maria@escola.com,coordenador`,
      alunos: `nome,data_nascimento,cpf,email,telefone
Pedro Silva,2010-05-15,12345678901,pedro@email.com,(11)99999-9999`,
      responsaveis: `nome,email,telefone,cpf,parentesco
José Silva,jose@email.com,(11)98888-8888,98765432100,pai`,
      turmas: `nome,ano_letivo,serie,periodo,capacidade_maxima
1º Ano A,2024,1º Ano,matutino,30`,
      disciplinas: `nome,codigo,carga_horaria
Matemática,MAT001,80`
    };

    const content = templates[tipo as keyof typeof templates];
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `template_${tipo}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderImportSection = (tipo: string, titulo: string, icon: any) => {
    const Icon = icon;
    
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
            <Icon className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{titulo}</h3>
            <p className="text-sm text-gray-600">Importe dados em massa via planilha</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Botão de Download do Template */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <FileSpreadsheet className="w-5 h-5 text-gray-600" />
              <div>
                <p className="font-medium text-gray-900">Template de Importação</p>
                <p className="text-sm text-gray-600">Baixe o modelo para preencher seus dados</p>
              </div>
            </div>
            <button
              onClick={() => downloadTemplate(tipo)}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Baixar Template</span>
            </button>
          </div>

          {/* Upload de Arquivo */}
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600 mb-4">
              Arraste e solte seu arquivo aqui ou clique para selecionar
            </p>
            <input
              type="file"
              accept=".csv,.xls,.xlsx"
              onChange={(e) => handleFileUpload(e, tipo)}
              className="hidden"
              id={`upload-${tipo}`}
            />
            <label
              htmlFor={`upload-${tipo}`}
              className="inline-flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Selecionar Arquivo</span>
            </label>
            <p className="text-xs text-gray-500 mt-2">
              Formatos aceitos: CSV, Excel (.xls, .xlsx)
            </p>
          </div>

          {/* Botão de Cadastro Manual */}
          <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Plus className="w-5 h-5 text-purple-600" />
              <div>
                <p className="font-medium text-purple-900">Cadastro Individual</p>
                <p className="text-sm text-purple-600">Cadastre um registro por vez</p>
              </div>
            </div>
            <button className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
              <Plus className="w-4 h-4" />
              <span>Novo {titulo.slice(0, -1)}</span>
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <InstituicaoLayout>
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Secretaria Digital</h1>
          <p className="text-gray-600">
            Gerencie os dados da sua instituição através de importações em massa ou cadastro manual
          </p>
        </div>

        {/* Status Messages */}
        {uploadStatus && (
          <div className={`mb-6 p-4 rounded-lg flex items-center space-x-3 ${
            uploadStatus.type === 'success' ? 'bg-green-50 border border-green-200' :
            uploadStatus.type === 'error' ? 'bg-red-50 border border-red-200' :
            'bg-blue-50 border border-blue-200'
          }`}>
            {uploadStatus.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-green-600" />
            ) : uploadStatus.type === 'error' ? (
              <AlertCircle className="w-5 h-5 text-red-600" />
            ) : (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
            )}
            <span className={`font-medium ${
              uploadStatus.type === 'success' ? 'text-green-700' :
              uploadStatus.type === 'error' ? 'text-red-700' :
              'text-blue-700'
            }`}>
              {uploadStatus.message}
            </span>
          </div>
        )}

        {/* Tabs */}
        <div className="mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                      activeTab === tab.id
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div className="space-y-6">
          {activeTab === 'usuarios' && renderImportSection('usuarios', 'Usuários da Escola', Users)}
          {activeTab === 'alunos' && renderImportSection('alunos', 'Alunos', GraduationCap)}
          {activeTab === 'responsaveis' && renderImportSection('responsaveis', 'Responsáveis', UserCheck)}
          {activeTab === 'turmas' && renderImportSection('turmas', 'Turmas', Calendar)}
          {activeTab === 'disciplinas' && renderImportSection('disciplinas', 'Disciplinas', BookOpen)}
        </div>

        {/* Informações Importantes */}
        <div className="mt-8 bg-amber-50 border border-amber-200 rounded-lg p-6">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
            <div>
              <h3 className="font-semibold text-amber-900 mb-2">Instruções Importantes</h3>
              <ul className="text-sm text-amber-800 space-y-1">
                <li>• Sempre baixe o template antes de importar seus dados</li>
                <li>• Certifique-se de que os dados estejam no formato correto</li>
                <li>• E-mails duplicados serão ignorados durante a importação</li>
                <li>• Para usuários da escola, o e-mail deve ser válido para acesso ao Google</li>
                <li>• Os dados importados podem ser editados individualmente após a importação</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </InstituicaoLayout>
  );
}
