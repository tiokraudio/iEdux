import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import InstituicaoLayout from '@/react-app/components/admin/InstituicaoLayout';
import {
  Grid3x3,
  Settings,
  ExternalLink,
  Users
} from 'lucide-react';

interface SolucaoLicenciada {
  id: number;
  nome: string;
  descricao_breve: string | null;
  url_icone: string | null;
  url_aplicacao: string | null;
}

export default function GestaoSolucoes() {
  const [solucoes, setSolucoes] = useState<SolucaoLicenciada[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchSolucoesLicenciadas();
  }, []);

  const fetchSolucoesLicenciadas = async () => {
    try {
      const response = await fetch('/api/escola/solucoes/licenciadas', {
        credentials: 'include'
      });

      const result = await response.json();
      if (result.success) {
        setSolucoes(result.data);
      } else {
        console.error('Erro ao buscar soluções:', result.message);
      }
    } catch (error) {
      console.error('Erro ao buscar soluções licenciadas:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const renderSolucaoCard = (solucao: SolucaoLicenciada) => (
    <div
      key={solucao.id}
      className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
    >
      {/* Header do Card com Ícone */}
      <div className="flex items-center space-x-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-md">
          {solucao.url_icone ? (
            <img
              src={solucao.url_icone}
              alt={solucao.nome}
              className="w-full h-full object-cover rounded-lg"
            />
          ) : (
            <Grid3x3 className="w-8 h-8" />
          )}
        </div>
        
        <div className="flex-1">
          <h3 className="text-xl font-bold text-gray-900 mb-1">
            {solucao.nome}
          </h3>
          <p className="text-sm text-gray-600">
            {solucao.descricao_breve || 'Solução educacional'}
          </p>
        </div>
      </div>

      {/* Ações do Card */}
      <div className="space-y-3">
        <Link
          to={`/painel-escola/solucoes/${solucao.id}/acessos`}
          className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          <Users className="w-5 h-5" />
          <span>Gerir Acessos</span>
        </Link>

        {solucao.url_aplicacao && (
          <a
            href={solucao.url_aplicacao}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
          >
            <ExternalLink className="w-5 h-5" />
            <span>Acessar Solução</span>
          </a>
        )}
      </div>
    </div>
  );

  if (isLoading) {
    return (
      <InstituicaoLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </InstituicaoLayout>
    );
  }

  return (
    <InstituicaoLayout>
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Gestão de Soluções</h1>
          <p className="text-gray-600">
            Gerencie os acessos dos usuários às soluções licenciadas para sua instituição
          </p>
        </div>

        {/* Soluções Licenciadas */}
        {solucoes.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <div className="text-center">
              <Grid3x3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Nenhuma solução licenciada
              </h3>
              <p className="text-gray-600 mb-4">
                Sua instituição ainda não possui licenças para soluções educacionais.
              </p>
              <p className="text-sm text-gray-500">
                Entre em contato com o administrador do sistema para solicitar licenças.
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {solucoes.map(renderSolucaoCard)}
          </div>
        )}

        {/* Informações Adicionais */}
        {solucoes.length > 0 && (
          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <div className="flex items-start space-x-3">
              <Settings className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="font-semibold text-blue-900 mb-2">Sobre a Gestão de Acessos</h3>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Cada solução possui diferentes perfis de acesso com permissões específicas</li>
                  <li>• Você pode atribuir perfis diferentes para cada usuário da escola</li>
                  <li>• As alterações são aplicadas imediatamente após salvar</li>
                  <li>• Para remover acesso, selecione "Sem Acesso" no perfil do usuário</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </InstituicaoLayout>
  );
}
