import Header from '@/react-app/components/Header';
import Footer from '@/react-app/components/Footer';
import { Users, Target, Heart, Award } from 'lucide-react';

export default function AboutUsPage() {
  const values = [
    {
      icon: Target,
      title: 'Inovação',
      description: 'Sempre buscamos novas formas de melhorar a experiência educacional através da tecnologia.'
    },
    {
      icon: Heart,
      title: 'Dedicação',
      description: 'Nosso compromisso é com a transformação positiva da educação brasileira.'
    },
    {
      icon: Users,
      title: 'Colaboração',
      description: 'Acreditamos que a educação é um esforço coletivo entre escola, família e sociedade.'
    },
    {
      icon: Award,
      title: 'Excelência',
      description: 'Buscamos sempre a mais alta qualidade em nossas soluções e atendimento.'
    }
  ];

  const team = [
    {
      name: 'João Silva',
      role: 'CEO & Fundador',
      description: 'Especialista em educação com mais de 15 anos de experiência.',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face'
    },
    {
      name: 'Maria Santos',
      role: 'CTO',
      description: 'Engenheira de software apaixonada por tecnologia educacional.',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b524?w=400&h=400&fit=crop&crop=face'
    },
    {
      name: 'Pedro Costa',
      role: 'Head de Produto',
      description: 'Designer UX/UI focado em criar experiências intuitivas.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Sobre a{' '}
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  iEdux
                </span>
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-4xl mx-auto">
                Transformando a educação brasileira através da tecnologia e inovação
              </p>
            </div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                  Nossa Missão
                </h2>
                <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                  A iEdux nasceu da necessidade de modernizar a gestão educacional no Brasil. 
                  Percebemos que as escolas enfrentavam desafios enormes para integrar suas 
                  operações e melhorar a comunicação entre todos os envolvidos no processo educativo.
                </p>
                <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                  Nossa plataforma foi desenvolvida para ser a ponte entre a educação tradicional 
                  e as possibilidades infinitas que a tecnologia oferece, sempre priorizando a 
                  simplicidade e a eficiência.
                </p>
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                    <Target className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">Impacto Real</h3>
                    <p className="text-gray-600">Mais de 50 escolas transformadas</p>
                  </div>
                </div>
              </div>
              
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600&h=400&fit=crop"
                  alt="Equipe trabalhando"
                  className="rounded-2xl shadow-xl"
                />
                <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg border border-gray-200">
                  <div className="text-3xl font-bold text-blue-600">2019</div>
                  <div className="text-gray-600">Fundação da iEdux</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Nossos Valores
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Os princípios que guiam cada decisão e desenvolvimento na iEdux
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => {
                const Icon = value.icon;
                return (
                  <div
                    key={index}
                    className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200 hover:shadow-lg transition-all duration-300"
                  >
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mb-6">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4">
                      {value.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {value.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Nossa Equipe
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Profissionais apaixonados por educação e tecnologia
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {team.map((member, index) => (
                <div
                  key={index}
                  className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200 hover:shadow-lg transition-all duration-300 text-center"
                >
                  <div className="relative mb-6">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-32 h-32 rounded-full mx-auto object-cover shadow-lg"
                    />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {member.name}
                  </h3>
                  <p className="text-blue-600 font-semibold mb-4">
                    {member.role}
                  </p>
                  <p className="text-gray-600 leading-relaxed">
                    {member.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Timeline Section */}
        <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Nossa Jornada
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Marcos importantes da evolução da iEdux
              </p>
            </div>

            <div className="relative">
              <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-blue-600 to-purple-600 rounded-full"></div>
              
              <div className="space-y-12">
                <div className="flex items-center justify-between">
                  <div className="w-5/12 text-right">
                    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">2019</h3>
                      <p className="text-gray-600">Fundação da iEdux com foco em soluções educacionais</p>
                    </div>
                  </div>
                  <div className="w-2/12 flex justify-center">
                    <div className="w-6 h-6 bg-blue-600 rounded-full border-4 border-white shadow-lg"></div>
                  </div>
                  <div className="w-5/12"></div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="w-5/12"></div>
                  <div className="w-2/12 flex justify-center">
                    <div className="w-6 h-6 bg-purple-600 rounded-full border-4 border-white shadow-lg"></div>
                  </div>
                  <div className="w-5/12">
                    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">2020</h3>
                      <p className="text-gray-600">Lançamento da primeira versão da plataforma Quest</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="w-5/12 text-right">
                    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">2022</h3>
                      <p className="text-gray-600">Expansão para 50+ escolas e lançamento do SOE</p>
                    </div>
                  </div>
                  <div className="w-2/12 flex justify-center">
                    <div className="w-6 h-6 bg-green-600 rounded-full border-4 border-white shadow-lg"></div>
                  </div>
                  <div className="w-5/12"></div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="w-5/12"></div>
                  <div className="w-2/12 flex justify-center">
                    <div className="w-6 h-6 bg-yellow-600 rounded-full border-4 border-white shadow-lg"></div>
                  </div>
                  <div className="w-5/12">
                    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">2024</h3>
                      <p className="text-gray-600">Hub integrado e 10.000+ usuários ativos na plataforma</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-blue-600 to-purple-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Junte-se à Revolução Educacional
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Faça parte das escolas que já descobriram como a tecnologia pode transformar a educação
            </p>
            <a
              href="/contato"
              className="inline-flex items-center bg-white text-purple-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-colors duration-200 shadow-lg"
            >
              Converse com Nossa Equipe
            </a>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
