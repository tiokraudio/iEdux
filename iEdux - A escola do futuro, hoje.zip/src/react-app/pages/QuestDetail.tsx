import { Link } from 'react-router';
import Header from '@/react-app/components/Header';
import Footer from '@/react-app/components/Footer';
import { 
  BookOpen, 
  Users, 
  BarChart3, 
  Clock, 
  CheckCircle, 
  ArrowRight,
  Zap,
  Shield,
  Target,
  Download,
  Play
} from 'lucide-react';

export default function QuestDetailPage() {
  const features = [
    {
      icon: BookOpen,
      title: 'Banco de Questões Colaborativo',
      description: 'Acesse milhares de questões organizadas por disciplina, ano e nível de dificuldade.',
      details: [
        'Questões categorizadas por BNCC',
        'Filtros avançados de busca',
        'Sistema de tags inteligente',
        'Compartilhamento entre professores'
      ]
    },
    {
      icon: Zap,
      title: 'Criação Intuitiva de Provas',
      description: 'Monte avaliações profissionais em minutos com nossa interface drag-and-drop.',
      details: [
        'Editor visual intuitivo',
        'Templates pré-definidos',
        'Configuração automática de layout',
        'Preview em tempo real'
      ]
    },
    {
      icon: Users,
      title: 'Aplicação Flexível',
      description: 'Aplique provas online, offline ou em formato híbrido conforme sua necessidade.',
      details: [
        'Modo online com timer',
        'Versão offline para impressão',
        'Aplicação em tablets',
        'Sincronização automática'
      ]
    },
    {
      icon: BarChart3,
      title: 'Análise de Desempenho',
      description: 'Relatórios detalhados para acompanhar o progresso dos alunos e identificar dificuldades.',
      details: [
        'Gráficos de performance por aluno',
        'Análise por questão e conteúdo',
        'Comparativos entre turmas',
        'Indicadores pedagógicos'
      ]
    }
  ];

  const benefits = [
    {
      metric: '70%',
      description: 'Redução no tempo de criação de provas'
    },
    {
      metric: '85%',
      description: 'Melhoria na qualidade das avaliações'
    },
    {
      metric: '60%',
      description: 'Economia no tempo de correção'
    },
    {
      metric: '95%',
      description: 'Satisfação dos professores'
    }
  ];

  const workflow = [
    {
      step: '1',
      title: 'Selecione Questões',
      description: 'Explore o banco de questões e escolha as mais adequadas para sua avaliação'
    },
    {
      step: '2',
      title: 'Monte a Prova',
      description: 'Use o editor visual para organizar questões e personalizar o layout'
    },
    {
      step: '3',
      title: 'Configure Aplicação',
      description: 'Defina parâmetros como tempo, data e modo de aplicação'
    },
    {
      step: '4',
      title: 'Aplique e Analise',
      description: 'Execute a prova e acesse relatórios detalhados de desempenho'
    }
  ];

  const testimonials = [
    {
      name: 'Maria Silva',
      role: 'Professora de Matemática',
      school: 'Colégio São Paulo',
      quote: 'O Quest revolucionou minha forma de criar provas. O que antes levava horas, agora faço em minutos.',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b524?w=100&h=100&fit=crop&crop=face'
    },
    {
      name: 'João Santos',
      role: 'Coordenador Pedagógico',
      school: 'Escola Moderna',
      quote: 'Os relatórios do Quest nos ajudam a identificar dificuldades específicas e ajustar nosso planejamento.',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-16 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="mb-6">
                  <span className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold mb-4">
                    Solução iEdux
                  </span>
                  <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">
                    Quest
                  </h1>
                  <p className="text-2xl text-blue-600 font-semibold mb-6">
                    Plataforma Colaborativa de Provas
                  </p>
                  <p className="text-xl text-gray-600 leading-relaxed">
                    Revolucione a criação, aplicação e correção de avaliações com nossa 
                    plataforma inteligente que economiza tempo e melhora a qualidade 
                    do processo pedagógico.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 mb-8">
                  <Link
                    to="/contato"
                    className="inline-flex items-center justify-center bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl"
                  >
                    <Play className="w-5 h-5 mr-2" />
                    Ver Demonstração
                  </Link>
                  <button className="inline-flex items-center justify-center border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-xl font-semibold hover:border-blue-600 hover:text-blue-600 transition-all duration-200">
                    <Download className="w-5 h-5 mr-2" />
                    Baixar Catálogo
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">10k+</div>
                    <div className="text-sm text-gray-600">Questões</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">500+</div>
                    <div className="text-sm text-gray-600">Professores</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">2M+</div>
                    <div className="text-sm text-gray-600">Provas Criadas</div>
                  </div>
                </div>
              </div>

              <div className="relative">
                <img
                  src="https://mocha-cdn.com/019a593b-ef35-795c-9777-c39c5e44a28a/quest-interface.png"
                  alt="Interface do Quest"
                  className="rounded-2xl shadow-2xl border border-gray-200"
                />
                <div className="absolute top-4 right-4 bg-white p-3 rounded-xl shadow-lg">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm font-semibold text-gray-900">Online</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Funcionalidades Completas
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Tudo que você precisa para criar avaliações profissionais e análises detalhadas
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={index}
                    className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-8 hover:shadow-lg transition-all duration-300"
                  >
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-gray-900 mb-2">
                          {feature.title}
                        </h3>
                        <p className="text-gray-600 mb-4">
                          {feature.description}
                        </p>
                        <ul className="space-y-2">
                          {feature.details.map((detail, detailIndex) => (
                            <li key={detailIndex} className="flex items-center space-x-2">
                              <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                              <span className="text-sm text-gray-700">{detail}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Workflow Section */}
        <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Como Funciona o Quest
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Processo simples e intuitivo para criar avaliações profissionais
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {workflow.map((step, index) => (
                <div key={index} className="text-center">
                  <div className="relative mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl font-bold text-white">{step.step}</span>
                    </div>
                    {index < workflow.length - 1 && (
                      <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-blue-600 to-purple-600 transform -translate-y-1/2"></div>
                    )}
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    {step.title}
                  </h3>
                  <p className="text-gray-600">
                    {step.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Resultados Comprovados
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Escolas que utilizam o Quest experimentam melhorias significativas
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {benefits.map((benefit, index) => (
                <div
                  key={index}
                  className="text-center bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8"
                >
                  <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
                    {benefit.metric}
                  </div>
                  <p className="text-gray-700 font-medium">
                    {benefit.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Case Study */}
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 md:p-12">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">
                    Caso de Sucesso: Colégio Futuro
                  </h3>
                  <p className="text-gray-600 mb-6">
                    Com 1.200 alunos, o Colégio Futuro implementou o Quest e observou 
                    melhorias significativas na qualidade das avaliações e economia 
                    de tempo dos professores.
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <Target className="w-5 h-5 text-green-500" />
                      <span className="text-gray-700">5 horas economizadas por semana por professor</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Target className="w-5 h-5 text-green-500" />
                      <span className="text-gray-700">Melhoria de 30% na padronização das provas</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Target className="w-5 h-5 text-green-500" />
                      <span className="text-gray-700">Análises pedagógicas mais precisas</span>
                    </div>
                  </div>
                </div>
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600&h=400&fit=crop"
                    alt="Sala de aula moderna"
                    className="rounded-xl shadow-lg"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                O que Dizem os Educadores
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Depoimentos reais de professores e coordenadores que usam o Quest
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200"
                >
                  <div className="flex items-start space-x-4 mb-6">
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                      <p className="text-blue-600 text-sm">{testimonial.role}</p>
                      <p className="text-gray-500 text-sm">{testimonial.school}</p>
                    </div>
                  </div>
                  <blockquote className="text-gray-700 italic">
                    "{testimonial.quote}"
                  </blockquote>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Security & Integration */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-6">
                  Segurança e Integração
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  O Quest foi desenvolvido com os mais altos padrões de segurança 
                  e integração, garantindo proteção total dos dados e compatibilidade 
                  com os principais sistemas educacionais.
                </p>
                
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <Shield className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Segurança Avançada</h3>
                      <p className="text-gray-600">Criptografia end-to-end, autenticação multifator e compliance com LGPD</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <Zap className="w-6 h-6 text-blue-500 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Integração Nativa</h3>
                      <p className="text-gray-600">Conecta automaticamente com TOTVS, Sistema Positivo e outros ERPs</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <Clock className="w-6 h-6 text-purple-500 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Backup Automático</h3>
                      <p className="text-gray-600">Seus dados protegidos com backup em tempo real e recuperação instantânea</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="relative">
                <div className="bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl p-8">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                      <Shield className="w-8 h-8 text-green-500 mx-auto mb-2" />
                      <div className="text-sm font-semibold">Segurança</div>
                      <div className="text-xs text-gray-600">ISO 27001</div>
                    </div>
                    <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                      <Clock className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                      <div className="text-sm font-semibold">Uptime</div>
                      <div className="text-xs text-gray-600">99.9%</div>
                    </div>
                    <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                      <Zap className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                      <div className="text-sm font-semibold">Performance</div>
                      <div className="text-xs text-gray-600">&lt; 100ms</div>
                    </div>
                    <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                      <Target className="w-8 h-8 text-orange-500 mx-auto mb-2" />
                      <div className="text-sm font-semibold">Precisão</div>
                      <div className="text-xs text-gray-600">99.8%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-blue-600 to-purple-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Pronto para Revolucionar suas Avaliações?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Junte-se a centenas de escolas que já descobriram o poder do Quest. 
              Solicite uma demonstração gratuita e veja a diferença na prática.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/contato"
                className="inline-flex items-center justify-center bg-white text-purple-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-colors duration-200 shadow-lg"
              >
                <Play className="w-5 h-5 mr-2" />
                Agendar Demonstração
              </Link>
              <Link
                to="/solucoes"
                className="inline-flex items-center justify-center border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white hover:text-purple-600 transition-all duration-200"
              >
                Ver Outras Soluções
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
