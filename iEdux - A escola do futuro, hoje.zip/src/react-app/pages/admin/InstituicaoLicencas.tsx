import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import AdminLayout from '@/react-app/components/admin/AdminLayout';
import { ArrowLeft, Package, Check, Loader } from 'lucide-react';
import type { SolucaoComLicencaRecord, InstituicaoRecord } from '@/shared/admin-types';

export default function InstituicaoLicencas() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [instituicao, setInstituicao] = useState<InstituicaoRecord | null>(null);
  const [solucoes, setSolucoes] = useState<SolucaoComLicencaRecord[]>([]);
  const [licencasAtivas, setLicencasAtivas] = useState<Set<number>>(new Set());
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (id) {
      fetchInstituicao();
      fetchLicencas();
    }
  }, [id]);

  const fetchInstituicao = async () => {
    try {
      const response = await fetch('/api/admin/instituicoes', {
        credentials: 'include'
      });
      const data = await response.json();
      if (data.success) {
        const inst = data.data.find((i: InstituicaoRecord) => i.id === Number(id));
        setInstituicao(inst || null);
      }
    } catch (error) {
      console.error('Erro ao carregar instituição:', error);
    }
  };

  const fetchLicencas = async () => {
    try {
      const response = await fetch(`/api/admin/instituicoes/${id}/licencas`, {
        credentials: 'include'
      });
      const data = await response.json();
      if (data.success) {
        setSolucoes(data.data);
        
        // Criar set com as soluções que já têm licença
        const ativas = new Set<number>();
        data.data.forEach((solucao: SolucaoComLicencaRecord) => {
          if (solucao.tem_licenca) {
            ativas.add(solucao.id);
          }
        });
        setLicencasAtivas(ativas);
      }
    } catch (error) {
      console.error('Erro ao carregar licenças:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleLicenca = (solucaoId: number) => {
    const novasLicencas = new Set(licencasAtivas);
    if (novasLicencas.has(solucaoId)) {
      novasLicencas.delete(solucaoId);
    } else {
      novasLicencas.add(solucaoId);
    }
    setLicencasAtivas(novasLicencas);
  };

  const handleSave = async () => {
    setIsSaving(true);
    setError('');
    setSuccessMessage('');

    try {
      const response = await fetch(`/api/admin/instituicoes/${id}/licencas`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          licencas: Array.from(licencasAtivas)
        })
      });

      const result = await response.json();

      if (result.success) {
        setSuccessMessage('Licenças atualizadas com sucesso!');
        // Recarregar os dados para refletir as mudanças
        await fetchLicencas();
      } else {
        setError(result.message || 'Erro ao salvar licenças');
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
      setError('Erro ao salvar licenças');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mr-4"></div>
            <p className="text-gray-600">Carregando licenças...</p>
          </div>
        </div>
      </AdminLayout>
    );
  }

  if (!instituicao) {
    return (
      <AdminLayout>
        <div className="max-w-4xl mx-auto">
          <div className="text-center py-12">
            <p className="text-red-600 mb-4">Instituição não encontrada</p>
            <button
              onClick={() => navigate('/painel/instituicoes')}
              className="text-purple-600 hover:text-purple-700 font-semibold"
            >
              Voltar para Instituições
            </button>
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/painel/instituicoes')}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Gerenciando Licenças</h1>
              <p className="text-gray-600 mt-1">
                <span className="font-semibold">{instituicao.nome}</span>
              </p>
            </div>
          </div>
          
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSaving ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                <span>Salvando...</span>
              </>
            ) : (
              <>
                <Check className="w-5 h-5" />
                <span>Salvar Licenças</span>
              </>
            )}
          </button>
        </div>

        {/* Messages */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        {successMessage && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-green-600 text-sm">{successMessage}</p>
          </div>
        )}

        {/* Solutions List */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
            <h3 className="text-lg font-semibold text-gray-900">Soluções Disponíveis</h3>
            <p className="text-sm text-gray-600 mt-1">
              Ative ou desative o acesso às soluções para esta instituição
            </p>
          </div>

          {solucoes.length === 0 ? (
            <div className="p-12 text-center">
              <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Nenhuma solução ativa encontrada</p>
              <p className="text-sm text-gray-500 mt-1">
                Configure soluções no módulo de Soluções primeiro
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {solucoes.map((solucao) => {
                const isActive = licencasAtivas.has(solucao.id);
                
                return (
                  <div
                    key={solucao.id}
                    className="p-6 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      {/* Solution Info */}
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                          {solucao.url_icone ? (
                            <img
                              src={solucao.url_icone}
                              alt={solucao.nome}
                              className="w-8 h-8 object-contain"
                            />
                          ) : (
                            <Package className="w-6 h-6 text-white" />
                          )}
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold text-gray-900">
                            {solucao.nome}
                          </h4>
                          {solucao.descricao_breve && (
                            <p className="text-sm text-gray-600 mt-1">
                              {solucao.descricao_breve}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Toggle Switch */}
                      <div className="flex items-center space-x-3">
                        <span className={`text-sm font-medium ${isActive ? 'text-green-700' : 'text-gray-500'}`}>
                          {isActive ? 'Licenciada' : 'Sem Licença'}
                        </span>
                        <button
                          onClick={() => handleToggleLicenca(solucao.id)}
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 ${
                            isActive ? 'bg-green-500' : 'bg-gray-200'
                          }`}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                              isActive ? 'translate-x-6' : 'translate-x-1'
                            }`}
                          />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Summary */}
        {solucoes.length > 0 && (
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <p className="text-sm text-blue-700">
                <span className="font-semibold">{licencasAtivas.size}</span> de{' '}
                <span className="font-semibold">{solucoes.length}</span> soluções licenciadas
              </p>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
