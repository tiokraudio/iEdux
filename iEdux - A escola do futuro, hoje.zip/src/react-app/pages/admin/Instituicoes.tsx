import { useState, useEffect } from 'react';
import AdminLayout from '@/react-app/components/admin/AdminLayout';
import { Plus, Edit2, Power, CheckCircle, XCircle, Settings, UserCheck } from 'lucide-react';
import type { InstituicaoRecord, InstituicaoType, ConectorErpRecord } from '@/shared/admin-types';

export default function Instituicoes() {
  const [instituicoes, setInstituicoes] = useState<InstituicaoRecord[]>([]);
  const [conectoresAtivos, setConectoresAtivos] = useState<ConectorErpRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<InstituicaoType>({
    nome: '',
    status: 'ativa',
    modo_dados: 'manual',
    conector_erp_id: undefined
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchInstituicoes();
    fetchConectoresAtivos();
  }, []);

  const fetchInstituicoes = async () => {
    try {
      const response = await fetch('/api/admin/instituicoes', {
        credentials: 'include'
      });
      const data = await response.json();
      if (data.success) {
        setInstituicoes(data.data);
      }
    } catch (error) {
      console.error('Erro ao carregar instituições:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchConectoresAtivos = async () => {
    try {
      const response = await fetch('/api/admin/conectores-erp/ativos', {
        credentials: 'include'
      });
      const data = await response.json();
      if (data.success) {
        setConectoresAtivos(data.data);
      }
    } catch (error) {
      console.error('Erro ao carregar conectores:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      const url = editingId
        ? `/api/admin/instituicoes/${editingId}`
        : '/api/admin/instituicoes';
      
      const method = editingId ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      const result = await response.json();

      if (result.success) {
        await fetchInstituicoes();
        setShowModal(false);
        setEditingId(null);
        setFormData({ nome: '', status: 'ativa', modo_dados: 'manual', conector_erp_id: undefined });
      } else {
        setError(result.message || 'Erro ao salvar instituição');
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
      setError('Erro ao salvar instituição');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (instituicao: InstituicaoRecord) => {
    setEditingId(instituicao.id);
    setFormData({
      nome: instituicao.nome,
      status: instituicao.status,
      modo_dados: instituicao.modo_dados,
      conector_erp_id: instituicao.conector_erp_id
    });
    setShowModal(true);
  };

  const handleToggleStatus = async (id: number) => {
    try {
      const response = await fetch(`/api/admin/instituicoes/${id}/status`, {
        method: 'PATCH',
        credentials: 'include'
      });

      if (response.ok) {
        await fetchInstituicoes();
      }
    } catch (error) {
      console.error('Erro ao alterar status:', error);
    }
  };

  const openNewModal = () => {
    setEditingId(null);
    setFormData({ nome: '', status: 'ativa', modo_dados: 'manual', conector_erp_id: undefined });
    setError('');
    setShowModal(true);
  };

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Instituições</h1>
            <p className="text-gray-600">
              Gerencie as escolas cadastradas na plataforma
            </p>
          </div>
          <button
            onClick={openNewModal}
            className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <Plus className="w-5 h-5" />
            <span>Adicionar Nova Instituição</span>
          </button>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          {isLoading ? (
            <div className="p-12 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Carregando instituições...</p>
            </div>
          ) : instituicoes.length === 0 ? (
            <div className="p-12 text-center">
              <p className="text-gray-600 mb-4">Nenhuma instituição cadastrada</p>
              <button
                onClick={openNewModal}
                className="text-blue-600 hover:text-blue-700 font-semibold"
              >
                Adicionar a primeira instituição
              </button>
            </div>
          ) : (
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Nome da Instituição
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Modo de Dados
                  </th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {instituicoes.map((instituicao) => (
                  <tr key={instituicao.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-gray-900">{instituicao.nome}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-semibold ${
                          instituicao.status === 'ativa'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-red-100 text-red-700'
                        }`}
                      >
                        {instituicao.status === 'ativa' ? (
                          <CheckCircle className="w-3 h-3" />
                        ) : (
                          <XCircle className="w-3 h-3" />
                        )}
                        <span>{instituicao.status === 'ativa' ? 'Ativa' : 'Inativa'}</span>
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-gray-700">
                        {instituicao.modo_dados === 'manual' ? 'Cadastro Manual' : 'Sincronização via ERP'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <a
                          href={`/painel/instituicoes/${instituicao.id}/administrador`}
                          className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                          title="Gerenciar Administrador"
                        >
                          <UserCheck className="w-4 h-4" />
                        </a>
                        <a
                          href={`/painel/instituicoes/${instituicao.id}/licencas`}
                          className="p-2 text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                          title="Gerenciar Licenças"
                        >
                          <Settings className="w-4 h-4" />
                        </a>
                        <button
                          onClick={() => handleEdit(instituicao)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Editar"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleToggleStatus(instituicao.id)}
                          className={`p-2 rounded-lg transition-colors ${
                            instituicao.status === 'ativa'
                              ? 'text-red-600 hover:bg-red-50'
                              : 'text-green-600 hover:bg-green-50'
                          }`}
                          title={instituicao.status === 'ativa' ? 'Desativar' : 'Ativar'}
                        >
                          <Power className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                {editingId ? 'Editar Instituição' : 'Adicionar Nova Instituição'}
              </h2>

              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="nome" className="block text-sm font-semibold text-gray-700 mb-2">
                    Nome da Instituição *
                  </label>
                  <input
                    type="text"
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    placeholder="Ex: Escola Palmas"
                  />
                </div>

                <div>
                  <label htmlFor="status" className="block text-sm font-semibold text-gray-700 mb-2">
                    Status *
                  </label>
                  <select
                    id="status"
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as 'ativa' | 'inativa' })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-900"
                  >
                    <option value="ativa">Ativa</option>
                    <option value="inativa">Inativa</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Modo de Dados *
                  </label>
                  <div className="space-y-3">
                    <label className="flex items-start p-4 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-blue-500 transition-colors">
                      <input
                        type="radio"
                        name="modo_dados"
                        value="manual"
                        checked={formData.modo_dados === 'manual'}
                        onChange={(e) => setFormData({ ...formData, modo_dados: e.target.value as 'manual' | 'erp' })}
                        className="mt-1 mr-3"
                      />
                      <div>
                        <div className="font-semibold text-gray-900">Cadastro Manual</div>
                        <div className="text-sm text-gray-600">
                          A escola irá cadastrar alunos e professores diretamente no Hub
                        </div>
                      </div>
                    </label>
                    <label className="flex items-start p-4 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-blue-500 transition-colors">
                      <input
                        type="radio"
                        name="modo_dados"
                        value="erp"
                        checked={formData.modo_dados === 'erp'}
                        onChange={(e) => {
                          setFormData({ 
                            ...formData, 
                            modo_dados: e.target.value as 'manual' | 'erp',
                            conector_erp_id: undefined 
                          });
                        }}
                        className="mt-1 mr-3"
                      />
                      <div>
                        <div className="font-semibold text-gray-900">Sincronização via ERP</div>
                        <div className="text-sm text-gray-600">
                          Os dados serão importados automaticamente de um sistema externo (ex: Totvs)
                        </div>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Seleção de Conector ERP - só aparece quando modo_dados é 'erp' */}
                {formData.modo_dados === 'erp' && (
                  <div>
                    <label htmlFor="conector_erp_id" className="block text-sm font-semibold text-gray-700 mb-2">
                      Selecione o Conector *
                    </label>
                    <select
                      id="conector_erp_id"
                      value={formData.conector_erp_id || ''}
                      onChange={(e) => setFormData({ 
                        ...formData, 
                        conector_erp_id: e.target.value ? Number(e.target.value) : undefined 
                      })}
                      required={formData.modo_dados === 'erp'}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    >
                      <option value="">Selecione um conector...</option>
                      {conectoresAtivos.map((conector) => (
                        <option key={conector.id} value={conector.id}>
                          {conector.nome}
                        </option>
                      ))}
                    </select>
                    {conectoresAtivos.length === 0 && (
                      <p className="mt-2 text-sm text-amber-600">
                        Nenhum conector ativo encontrado. 
                        <a href="/painel/conectores" className="text-blue-600 hover:text-blue-700 ml-1">
                          Configure conectores aqui
                        </a>
                      </p>
                    )}
                  </div>
                )}

                <div className="flex justify-end space-x-4 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setEditingId(null);
                      setError('');
                      setFormData({ nome: '', status: 'ativa', modo_dados: 'manual', conector_erp_id: undefined });
                    }}
                    className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? 'Salvando...' : editingId ? 'Atualizar' : 'Criar Instituição'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
