import { useState, useEffect } from 'react';
import AdminLayout from '@/react-app/components/admin/AdminLayout';
import { Building2, Package, Link2, Inbox } from 'lucide-react';

export default function AdminDashboard() {
  const [stats, setStats] = useState([
    {
      icon: Building2,
      label: 'Instituições Ativas',
      value: '0',
      color: 'from-blue-600 to-cyan-500'
    },
    {
      icon: Package,
      label: 'Soluções Disponíveis',
      value: '0',
      color: 'from-green-600 to-emerald-500'
    },
    {
      icon: Link2,
      label: 'Conectores Configurados',
      value: '0',
      color: 'from-purple-600 to-violet-500'
    },
    {
      icon: Inbox,
      label: 'Novos Leads',
      value: '0',
      color: 'from-orange-600 to-red-500'
    }
  ]);

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      // Buscar instituições ativas
      const instituicoesResponse = await fetch('/api/admin/instituicoes', {
        credentials: 'include'
      });
      const instituicoesData = await instituicoesResponse.json();
      const instituicoesAtivas = instituicoesData.success 
        ? instituicoesData.data.filter((inst: any) => inst.status === 'ativa').length 
        : 0;

      // Buscar soluções ativas
      const solucoesResponse = await fetch('/api/admin/solucoes', {
        credentials: 'include'
      });
      const solucoesData = await solucoesResponse.json();
      const solucoesAtivas = solucoesData.success 
        ? solucoesData.data.filter((sol: any) => sol.status === 'ativa').length 
        : 0;

      // Buscar conectores ativos
      const conectoresResponse = await fetch('/api/admin/conectores-erp', {
        credentials: 'include'
      });
      const conectoresData = await conectoresResponse.json();
      const conectoresAtivos = conectoresData.success 
        ? conectoresData.data.filter((con: any) => con.status === 'ativo').length 
        : 0;

      // Buscar leads novos
      const leadsResponse = await fetch('/api/admin/leads', {
        credentials: 'include'
      });
      const leadsData = await leadsResponse.json();
      const novosLeads = leadsData.success 
        ? leadsData.data.filter((lead: any) => lead.status === 'novo').length 
        : 0;

      // Atualizar estado
      setStats([
        {
          icon: Building2,
          label: 'Instituições Ativas',
          value: instituicoesAtivas.toString(),
          color: 'from-blue-600 to-cyan-500'
        },
        {
          icon: Package,
          label: 'Soluções Disponíveis',
          value: solucoesAtivas.toString(),
          color: 'from-green-600 to-emerald-500'
        },
        {
          icon: Link2,
          label: 'Conectores Configurados',
          value: conectoresAtivos.toString(),
          color: 'from-purple-600 to-violet-500'
        },
        {
          icon: Inbox,
          label: 'Novos Leads',
          value: novosLeads.toString(),
          color: 'from-orange-600 to-red-500'
        }
      ]);
    } catch (error) {
      console.error('Erro ao carregar estatísticas do dashboard:', error);
      // Em caso de erro, definir valores padrão
      setStats([
        {
          icon: Building2,
          label: 'Instituições Ativas',
          value: '0',
          color: 'from-blue-600 to-cyan-500'
        },
        {
          icon: Package,
          label: 'Soluções Disponíveis',
          value: '0',
          color: 'from-green-600 to-emerald-500'
        },
        {
          icon: Link2,
          label: 'Conectores Configurados',
          value: '0',
          color: 'from-purple-600 to-violet-500'
        },
        {
          icon: Inbox,
          label: 'Novos Leads',
          value: '0',
          color: 'from-orange-600 to-red-500'
        }
      ]);
    }
  };

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
          <p className="text-gray-600">
            Visão geral da plataforma iEdux
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-lg flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <p className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
            );
          })}
        </div>

        {/* Welcome Message */}
        <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl shadow-lg p-8 text-white">
          <h2 className="text-2xl font-bold mb-2">
            Bem-vindo ao Painel Super Admin
          </h2>
          <p className="text-blue-100 mb-6">
            Gerencie instituições, configure soluções e acompanhe leads da plataforma iEdux
          </p>
          <div className="flex flex-wrap gap-4">
            <a
              href="/painel/instituicoes"
              className="bg-white text-blue-700 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors duration-200"
            >
              Gerenciar Instituições
            </a>
            <a
              href="/painel/leads"
              className="bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-800 transition-colors duration-200"
            >
              Ver Leads
            </a>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
