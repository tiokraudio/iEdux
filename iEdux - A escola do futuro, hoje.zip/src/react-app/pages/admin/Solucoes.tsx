import { useState, useEffect } from 'react';
import AdminLayout from '@/react-app/components/admin/AdminLayout';
import { Plus, Edit2, Power, CheckCircle, XCircle, Package, Users, Trash2 } from 'lucide-react';
import type { SolucaoRecord, SolucaoType, PerfilSolucaoRecord, PerfilSolucaoType } from '@/shared/admin-types';

export default function Solucoes() {
  const [solucoes, setSolucoes] = useState<SolucaoRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showPerfisModal, setShowPerfisModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [selectedSolucaoId, setSelectedSolucaoId] = useState<number | null>(null);
  const [perfis, setPerfis] = useState<PerfilSolucaoRecord[]>([]);
  const [formData, setFormData] = useState<SolucaoType>({
    nome: '',
    status: 'ativa',
    descricao_breve: '',
    url_aplicacao: '',
    url_icone: ''
  });
  const [perfilFormData, setPerfilFormData] = useState<Omit<PerfilSolucaoType, 'solucao_id'>>({
    nome_perfil: '',
    descricao_perfil: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchSolucoes();
  }, []);

  const fetchSolucoes = async () => {
    try {
      const response = await fetch('/api/admin/solucoes', {
        credentials: 'include'
      });
      const data = await response.json();
      if (data.success) {
        setSolucoes(data.data);
      }
    } catch (error) {
      console.error('Erro ao carregar soluções:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchPerfis = async (solucaoId: number) => {
    try {
      const response = await fetch(`/api/admin/solucoes/${solucaoId}/perfis`, {
        credentials: 'include'
      });
      const data = await response.json();
      if (data.success) {
        setPerfis(data.data);
      }
    } catch (error) {
      console.error('Erro ao carregar perfis:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      const url = editingId
        ? `/api/admin/solucoes/${editingId}`
        : '/api/admin/solucoes';
      
      const method = editingId ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      const result = await response.json();

      if (result.success) {
        await fetchSolucoes();
        setShowModal(false);
        setEditingId(null);
        setFormData({ nome: '', status: 'ativa', descricao_breve: '', url_aplicacao: '', url_icone: '' });
      } else {
        setError(result.message || 'Erro ao salvar solução');
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
      setError('Erro ao salvar solução');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePerfilSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSolucaoId) return;

    setIsSubmitting(true);
    setError('');

    try {
      const response = await fetch(`/api/admin/solucoes/${selectedSolucaoId}/perfis`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          ...perfilFormData,
          solucao_id: selectedSolucaoId
        })
      });

      const result = await response.json();

      if (result.success) {
        await fetchPerfis(selectedSolucaoId);
        setPerfilFormData({ nome_perfil: '', descricao_perfil: '' });
      } else {
        setError(result.message || 'Erro ao adicionar perfil');
      }
    } catch (error) {
      console.error('Erro ao adicionar perfil:', error);
      setError('Erro ao adicionar perfil');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeletePerfil = async (perfilId: number) => {
    if (!confirm('Tem certeza que deseja excluir este perfil?')) return;

    try {
      const response = await fetch(`/api/admin/perfis-solucoes/${perfilId}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (response.ok && selectedSolucaoId) {
        await fetchPerfis(selectedSolucaoId);
      }
    } catch (error) {
      console.error('Erro ao excluir perfil:', error);
    }
  };

  const handleEdit = (solucao: SolucaoRecord) => {
    setEditingId(solucao.id);
    setFormData({
      nome: solucao.nome,
      status: solucao.status,
      descricao_breve: solucao.descricao_breve || '',
      url_aplicacao: solucao.url_aplicacao || '',
      url_icone: solucao.url_icone || ''
    });
    setShowModal(true);
  };

  const handleToggleStatus = async (id: number) => {
    try {
      const response = await fetch(`/api/admin/solucoes/${id}/status`, {
        method: 'PATCH',
        credentials: 'include'
      });

      if (response.ok) {
        await fetchSolucoes();
      }
    } catch (error) {
      console.error('Erro ao alterar status:', error);
    }
  };

  const openNewModal = () => {
    setEditingId(null);
    setFormData({ nome: '', status: 'ativa', descricao_breve: '', url_aplicacao: '', url_icone: '' });
    setError('');
    setShowModal(true);
  };

  const openPerfisModal = async (solucao: SolucaoRecord) => {
    setSelectedSolucaoId(solucao.id);
    setError('');
    setPerfilFormData({ nome_perfil: '', descricao_perfil: '' });
    await fetchPerfis(solucao.id);
    setShowPerfisModal(true);
  };

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Soluções</h1>
            <p className="text-gray-600">
              Gerencie o catálogo de aplicações disponíveis na plataforma iEdux
            </p>
          </div>
          <button
            onClick={openNewModal}
            className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <Plus className="w-5 h-5" />
            <span>Adicionar Nova Solução</span>
          </button>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          {isLoading ? (
            <div className="p-12 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Carregando soluções...</p>
            </div>
          ) : solucoes.length === 0 ? (
            <div className="p-12 text-center">
              <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">Nenhuma solução cadastrada</p>
              <button
                onClick={openNewModal}
                className="text-purple-600 hover:text-purple-700 font-semibold"
              >
                Adicionar a primeira solução
              </button>
            </div>
          ) : (
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Solução
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Descrição
                  </th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {solucoes.map((solucao) => (
                  <tr key={solucao.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                          {solucao.url_icone ? (
                            <img
                              src={solucao.url_icone}
                              alt={solucao.nome}
                              className="w-6 h-6 object-contain"
                            />
                          ) : (
                            <Package className="w-5 h-5 text-white" />
                          )}
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900">{solucao.nome}</div>
                          {solucao.url_aplicacao && (
                            <div className="text-xs text-gray-500 truncate max-w-xs">
                              {solucao.url_aplicacao}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-semibold ${
                          solucao.status === 'ativa'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-red-100 text-red-700'
                        }`}
                      >
                        {solucao.status === 'ativa' ? (
                          <CheckCircle className="w-3 h-3" />
                        ) : (
                          <XCircle className="w-3 h-3" />
                        )}
                        <span>{solucao.status === 'ativa' ? 'Ativa' : 'Inativa'}</span>
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-gray-700">
                        {solucao.descricao_breve || 'Sem descrição'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          onClick={() => openPerfisModal(solucao)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Gerir Perfis"
                        >
                          <Users className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleEdit(solucao)}
                          className="p-2 text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                          title="Editar"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleToggleStatus(solucao.id)}
                          className={`p-2 rounded-lg transition-colors ${
                            solucao.status === 'ativa'
                              ? 'text-red-600 hover:bg-red-50'
                              : 'text-green-600 hover:bg-green-50'
                          }`}
                          title={solucao.status === 'ativa' ? 'Desativar' : 'Ativar'}
                        >
                          <Power className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Modal Solução */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                {editingId ? 'Editar Solução' : 'Adicionar Nova Solução'}
              </h2>

              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="nome" className="block text-sm font-semibold text-gray-700 mb-2">
                    Nome da Solução *
                  </label>
                  <input
                    type="text"
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    placeholder="Ex: iEDUX - Quest"
                  />
                </div>

                <div>
                  <label htmlFor="status" className="block text-sm font-semibold text-gray-700 mb-2">
                    Status *
                  </label>
                  <select
                    id="status"
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as 'ativa' | 'inativa' })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                  >
                    <option value="ativa">Ativa</option>
                    <option value="inativa">Inativa</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="descricao_breve" className="block text-sm font-semibold text-gray-700 mb-2">
                    Descrição Breve
                  </label>
                  <textarea
                    id="descricao_breve"
                    value={formData.descricao_breve}
                    onChange={(e) => setFormData({ ...formData, descricao_breve: e.target.value })}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    placeholder="Ex: Plataforma colaborativa para gestão de provas"
                  />
                </div>

                <div>
                  <label htmlFor="url_aplicacao" className="block text-sm font-semibold text-gray-700 mb-2">
                    URL da Aplicação (Endpoint)
                  </label>
                  <input
                    type="url"
                    id="url_aplicacao"
                    value={formData.url_aplicacao}
                    onChange={(e) => setFormData({ ...formData, url_aplicacao: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    placeholder="Ex: https://quest.sua-vps.com"
                  />
                </div>

                <div>
                  <label htmlFor="url_icone" className="block text-sm font-semibold text-gray-700 mb-2">
                    URL do Ícone
                  </label>
                  <input
                    type="url"
                    id="url_icone"
                    value={formData.url_icone}
                    onChange={(e) => setFormData({ ...formData, url_icone: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    placeholder="Ex: https://exemplo.com/icone-quest.png"
                  />
                </div>

                <div className="flex justify-end space-x-4 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setEditingId(null);
                      setError('');
                    }}
                    className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? 'Salvando...' : editingId ? 'Atualizar' : 'Criar Solução'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal Perfis */}
      {showPerfisModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">Gerir Perfis da Solução</h2>
                  <p className="text-gray-600">
                    {solucoes.find(s => s.id === selectedSolucaoId)?.nome}
                  </p>
                </div>
                <button
                  onClick={() => setShowPerfisModal(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <XCircle className="w-6 h-6" />
                </button>
              </div>

              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              )}

              {/* Form para adicionar novo perfil */}
              <div className="bg-gray-50 rounded-lg p-6 mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Adicionar Novo Perfil</h3>
                <form onSubmit={handlePerfilSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Nome do Perfil *
                      </label>
                      <input
                        type="text"
                        value={perfilFormData.nome_perfil}
                        onChange={(e) => setPerfilFormData({ ...perfilFormData, nome_perfil: e.target.value })}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                        placeholder="Ex: Quest_Criador"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Descrição do Perfil
                      </label>
                      <input
                        type="text"
                        value={perfilFormData.descricao_perfil}
                        onChange={(e) => setPerfilFormData({ ...perfilFormData, descricao_perfil: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                        placeholder="Ex: Pode criar e editar provas"
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-purple-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-purple-700 transition-colors disabled:opacity-50"
                  >
                    {isSubmitting ? 'Adicionando...' : 'Adicionar Perfil'}
                  </button>
                </form>
              </div>

              {/* Lista de perfis existentes */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Perfis Cadastrados</h3>
                {perfis.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Users className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                    <p>Nenhum perfil cadastrado para esta solução</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {perfis.map((perfil) => (
                      <div
                        key={perfil.id}
                        className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg"
                      >
                        <div>
                          <h4 className="font-semibold text-gray-900">{perfil.nome_perfil}</h4>
                          {perfil.descricao_perfil && (
                            <p className="text-sm text-gray-600">{perfil.descricao_perfil}</p>
                          )}
                        </div>
                        <button
                          onClick={() => handleDeletePerfil(perfil.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Excluir perfil"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
