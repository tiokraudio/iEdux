import { useState, useEffect } from 'react';
import AdminLayout from '@/react-app/components/admin/AdminLayout';
import { Plus, Edit2, Power, CheckCircle, XCircle, Link2 } from 'lucide-react';
import type { ConectorErpRecord, ConectorErpType } from '@/shared/admin-types';

export default function ConectoresErp() {
  const [conectores, setConectores] = useState<ConectorErpRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState<ConectorErpType>({
    nome: '',
    status: 'ativo',
    descricao_breve: '',
    campos_credenciais: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchConectores();
  }, []);

  const fetchConectores = async () => {
    try {
      const response = await fetch('/api/admin/conectores-erp', {
        credentials: 'include'
      });
      const data = await response.json();
      if (data.success) {
        setConectores(data.data);
      }
    } catch (error) {
      console.error('Erro ao carregar conectores:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      const url = editingId
        ? `/api/admin/conectores-erp/${editingId}`
        : '/api/admin/conectores-erp';
      
      const method = editingId ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      const result = await response.json();

      if (result.success) {
        await fetchConectores();
        setShowModal(false);
        setEditingId(null);
        setFormData({ nome: '', status: 'ativo', descricao_breve: '', campos_credenciais: '' });
      } else {
        setError(result.message || 'Erro ao salvar conector');
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
      setError('Erro ao salvar conector');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (conector: ConectorErpRecord) => {
    setEditingId(conector.id);
    setFormData({
      nome: conector.nome,
      status: conector.status,
      descricao_breve: conector.descricao_breve || '',
      campos_credenciais: conector.campos_credenciais || ''
    });
    setShowModal(true);
  };

  const handleToggleStatus = async (id: number) => {
    try {
      const response = await fetch(`/api/admin/conectores-erp/${id}/status`, {
        method: 'PATCH',
        credentials: 'include'
      });

      if (response.ok) {
        await fetchConectores();
      }
    } catch (error) {
      console.error('Erro ao alterar status:', error);
    }
  };

  const openNewModal = () => {
    setEditingId(null);
    setFormData({ nome: '', status: 'ativo', descricao_breve: '', campos_credenciais: '' });
    setError('');
    setShowModal(true);
  };

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto">
        {/* Page Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Conectores de ERP</h1>
            <p className="text-gray-600">
              Gerencie os sistemas de gestão externa que a plataforma suporta
            </p>
          </div>
          <button
            onClick={openNewModal}
            className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <Plus className="w-5 h-5" />
            <span>Adicionar Novo Conector</span>
          </button>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          {isLoading ? (
            <div className="p-12 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Carregando conectores...</p>
            </div>
          ) : conectores.length === 0 ? (
            <div className="p-12 text-center">
              <Link2 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">Nenhum conector de ERP cadastrado</p>
              <button
                onClick={openNewModal}
                className="text-purple-600 hover:text-purple-700 font-semibold"
              >
                Adicionar o primeiro conector
              </button>
            </div>
          ) : (
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Nome do Conector
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Descrição
                  </th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {conectores.map((conector) => (
                  <tr key={conector.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                          <Link2 className="w-5 h-5 text-white" />
                        </div>
                        <div className="font-semibold text-gray-900">{conector.nome}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-semibold ${
                          conector.status === 'ativo'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-red-100 text-red-700'
                        }`}
                      >
                        {conector.status === 'ativo' ? (
                          <CheckCircle className="w-3 h-3" />
                        ) : (
                          <XCircle className="w-3 h-3" />
                        )}
                        <span>{conector.status === 'ativo' ? 'Ativo' : 'Inativo'}</span>
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-gray-700">
                        {conector.descricao_breve || 'Sem descrição'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          onClick={() => handleEdit(conector)}
                          className="p-2 text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                          title="Editar"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleToggleStatus(conector.id)}
                          className={`p-2 rounded-lg transition-colors ${
                            conector.status === 'ativo'
                              ? 'text-red-600 hover:bg-red-50'
                              : 'text-green-600 hover:bg-green-50'
                          }`}
                          title={conector.status === 'ativo' ? 'Desativar' : 'Ativar'}
                        >
                          <Power className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                {editingId ? 'Editar Conector' : 'Adicionar Novo Conector'}
              </h2>

              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="nome" className="block text-sm font-semibold text-gray-700 mb-2">
                    Nome do Conector *
                  </label>
                  <input
                    type="text"
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    placeholder="Ex: Totvs Educacional"
                  />
                </div>

                <div>
                  <label htmlFor="status" className="block text-sm font-semibold text-gray-700 mb-2">
                    Status *
                  </label>
                  <select
                    id="status"
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as 'ativo' | 'inativo' })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                  >
                    <option value="ativo">Ativo</option>
                    <option value="inativo">Inativo</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="descricao_breve" className="block text-sm font-semibold text-gray-700 mb-2">
                    Descrição Breve
                  </label>
                  <textarea
                    id="descricao_breve"
                    value={formData.descricao_breve}
                    onChange={(e) => setFormData({ ...formData, descricao_breve: e.target.value })}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    placeholder="Ex: Sincronização com o ERP Totvs via API padrão REST"
                  />
                </div>

                <div>
                  <label htmlFor="campos_credenciais" className="block text-sm font-semibold text-gray-700 mb-2">
                    Campos de Credenciais
                  </label>
                  <textarea
                    id="campos_credenciais"
                    value={formData.campos_credenciais}
                    onChange={(e) => setFormData({ ...formData, campos_credenciais: e.target.value })}
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    placeholder="Liste os campos necessários separados por vírgula. Ex: API_KEY, URL_DA_INSTANCIA, USUARIO_API"
                  />
                  <p className="mt-2 text-sm text-gray-500">
                    Defina quais informações o Admin da Instituição precisará fornecer para se conectar
                  </p>
                </div>

                <div className="flex justify-end space-x-4 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setEditingId(null);
                      setError('');
                    }}
                    className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? 'Salvando...' : editingId ? 'Atualizar' : 'Criar Conector'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
