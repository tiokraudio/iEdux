import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import AdminLayout from '@/react-app/components/admin/AdminLayout';
import { ArrowLeft, UserCheck, Plus, Trash2, AlertTriangle } from 'lucide-react';
import type { InstituicaoRecord } from '@/shared/admin-types';

interface AdminInstituicao {
  id: number;
  nome: string;
  email: string;
  created_at: string;
  updated_at: string;
}

export default function InstituicaoAdministrador() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [instituicao, setInstituicao] = useState<InstituicaoRecord | null>(null);
  const [admin, setAdmin] = useState<AdminInstituicao | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    nome: '',
    email: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (id) {
      fetchInstituicao();
      fetchAdmin();
    }
  }, [id]);

  const fetchInstituicao = async () => {
    try {
      const response = await fetch('/api/admin/instituicoes', {
        credentials: 'include'
      });
      const data = await response.json();
      if (data.success) {
        const inst = data.data.find((i: InstituicaoRecord) => i.id === Number(id));
        setInstituicao(inst || null);
      }
    } catch (error) {
      console.error('Erro ao carregar instituição:', error);
    }
  };

  const fetchAdmin = async () => {
    try {
      const response = await fetch(`/api/admin/instituicoes/${id}/administrador`, {
        credentials: 'include'
      });
      const data = await response.json();
      if (data.success) {
        setAdmin(data.data || null);
      }
    } catch (error) {
      console.error('Erro ao carregar admin:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');
    setSuccessMessage('');

    try {
      const response = await fetch(`/api/admin/instituicoes/${id}/administrador`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      const result = await response.json();

      if (result.success) {
        await fetchAdmin();
        setShowModal(false);
        setFormData({ nome: '', email: '' });
        setSuccessMessage(result.message);
        // Limpar mensagem após 3 segundos
        setTimeout(() => setSuccessMessage(''), 3000);
      } else {
        setError(result.message || 'Erro ao criar administrador');
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
      setError('Erro ao criar administrador');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRemoveAdmin = async () => {
    if (!admin) return;

    if (!confirm(`Tem certeza que deseja remover o acesso de administrador para ${admin.email}?`)) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/instituicoes/${id}/administrador/${admin.id}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      const result = await response.json();

      if (result.success) {
        await fetchAdmin();
        setSuccessMessage('Administrador removido com sucesso!');
        setTimeout(() => setSuccessMessage(''), 3000);
      } else {
        setError(result.message || 'Erro ao remover administrador');
      }
    } catch (error) {
      console.error('Erro ao remover:', error);
      setError('Erro ao remover administrador');
    }
  };

  const openNewModal = () => {
    setFormData({ nome: '', email: '' });
    setError('');
    setShowModal(true);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mr-4"></div>
            <p className="text-gray-600">Carregando informações...</p>
          </div>
        </div>
      </AdminLayout>
    );
  }

  if (!instituicao) {
    return (
      <AdminLayout>
        <div className="max-w-4xl mx-auto">
          <div className="text-center py-12">
            <p className="text-red-600 mb-4">Instituição não encontrada</p>
            <button
              onClick={() => navigate('/painel/instituicoes')}
              className="text-purple-600 hover:text-purple-700 font-semibold"
            >
              Voltar para Instituições
            </button>
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/painel/instituicoes')}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Administrador da Instituição</h1>
              <p className="text-gray-600 mt-1">
                <span className="font-semibold">{instituicao.nome}</span>
              </p>
            </div>
          </div>
          
          {!admin && (
            <button
              onClick={openNewModal}
              className="flex items-center space-x-2 bg-gradient-to-r from-green-600 to-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-green-700 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Plus className="w-5 h-5" />
              <span>Criar Administrador</span>
            </button>
          )}
        </div>

        {/* Messages */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        {successMessage && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-green-600 text-sm">{successMessage}</p>
          </div>
        )}

        {/* Current Admin or Empty State */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          {admin ? (
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-600 to-blue-600 rounded-full flex items-center justify-center">
                    <UserCheck className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">Administrador Ativo</h3>
                    <p className="text-sm text-gray-600">
                      Usuário com acesso total à plataforma para esta instituição
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleRemoveAdmin}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  title="Remover Administrador"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Nome Completo
                  </label>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-gray-900">{admin.nome}</p>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    E-mail (Google)
                  </label>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-gray-900">{admin.email}</p>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Data de Criação
                  </label>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-gray-900">{formatDate(admin.created_at)}</p>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Status
                  </label>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                      <UserCheck className="w-3 h-3 mr-1" />
                      Ativo
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-blue-900 mb-1">Informação Importante</h4>
                    <p className="text-sm text-blue-700">
                      Este usuário poderá fazer login na plataforma usando sua conta Google e terá acesso completo 
                      aos recursos licenciados para esta instituição.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center">
              <UserCheck className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Nenhum Administrador Cadastrado
              </h3>
              <p className="text-gray-600 mb-6">
                Esta instituição ainda não possui um administrador. Sem um admin, 
                a escola não consegue acessar a plataforma.
              </p>
              <button
                onClick={openNewModal}
                className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-green-700 hover:to-blue-700 transition-all duration-200"
              >
                Criar Primeiro Administrador
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full">
            <div className="p-8">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-blue-600 rounded-lg flex items-center justify-center">
                  <Plus className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Criar Administrador</h2>
                  <p className="text-sm text-gray-600">Para {instituicao.nome}</p>
                </div>
              </div>

              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-600 text-sm">{error}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="nome" className="block text-sm font-semibold text-gray-700 mb-2">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    placeholder="Ex: Maria Gestora"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                    E-mail (Gmail) *
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 text-gray-900"
                    placeholder="Ex: maria.gestora@escolapalmas.com"
                  />
                  <p className="mt-2 text-xs text-gray-500">
                    Deve ser o e-mail Google que será usado para login
                  </p>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <div className="flex items-start space-x-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5" />
                    <p className="text-xs text-amber-700">
                      Este usuário terá acesso total às funcionalidades licenciadas para esta instituição.
                    </p>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setError('');
                      setFormData({ nome: '', email: '' });
                    }}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-4 py-2 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-lg font-semibold hover:from-green-700 hover:to-blue-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? 'Criando...' : 'Criar Administrador'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
