import HeroSection from '@/react-app/components/HeroSection';
import PilarsSection from '@/react-app/components/PilarsSection';
import IntegrationSection from '@/react-app/components/IntegrationSection';
import CTASection from '@/react-app/components/CTASection';
import Header from '@/react-app/components/Header';
import Footer from '@/react-app/components/Footer';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main>
        <HeroSection />
        <PilarsSection />
        <IntegrationSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
