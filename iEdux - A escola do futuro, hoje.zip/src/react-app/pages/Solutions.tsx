import { Link } from 'react-router';
import Header from '@/react-app/components/Header';
import Footer from '@/react-app/components/Footer';
import { 
  BookOpen, 
  ChevronRight, 
  CheckCircle, 
  Zap, 
  Shield, 
  BarChart3,
  ArrowRight
} from 'lucide-react';

export default function SolutionsPage() {
  const solutions = [
    {
      id: 'quest',
      name: 'Quest',
      tagline: 'Plataforma Colaborativa de Provas',
      description: 'Sistema inteligente para criação, aplicação e correção de avaliações, com banco de questões e análise de desempenho.',
      image: 'https://mocha-cdn.com/019a593b-ef35-795c-9777-c39c5e44a28a/quest-interface.png',
      features: [
        'Banco de questões colaborativo',
        'Criação intuitiva de provas',
        'Aplicação online e offline',
        'Correção automática',
        'Análise estatística de desempenho',
        'Relatórios detalhados'
      ],
      benefits: [
        'Reduz tempo de criação de provas em 70%',
        'Melhora qualidade das avaliações',
        'Facilita reutilização de questões',
        'Análise pedagógica avançada'
      ],
      link: '/solucoes/quest'
    },
    {
      id: 'soe',
      name: 'SOE',
      tagline: 'Sistema de Orientação Educacional',
      description: 'Plataforma para acompanhamento pedagógico individualizado, registro de ocorrências e comunicação escola-família.',
      image: 'https://mocha-cdn.com/019a593b-ef35-795c-9777-c39c5e44a28a/soe-interface.png',
      features: [
        'Ficha individual do aluno',
        'Registro de ocorrências',
        'Acompanhamento pedagógico',
        'Comunicação com responsáveis',
        'Relatórios de desenvolvimento',
        'Planos de intervenção'
      ],
      benefits: [
        'Melhora comunicação escola-família',
        'Acompanhamento mais efetivo',
        'Decisões baseadas em dados',
        'Redução de problemas comportamentais'
      ],
      link: '/solucoes/soe'
    }
  ];

  const features = [
    {
      icon: Zap,
      title: 'Integração Rápida',
      description: 'Conecta com seu sistema atual em poucos cliques'
    },
    {
      icon: Shield,
      title: 'Segurança Total',
      description: 'Dados protegidos com criptografia de ponta'
    },
    {
      icon: BarChart3,
      title: 'Analytics Avançado',
      description: 'Relatórios e insights para tomada de decisão'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Nossas{' '}
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Soluções
                </span>
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-4xl mx-auto">
                Ferramentas especializadas que transformam a gestão educacional 
                e potencializam o aprendizado
              </p>
              <div className="flex flex-wrap justify-center gap-4 mb-8">
                <span className="px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold">
                  Pedagogia Digital
                </span>
                <span className="px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-semibold">
                  Gestão Inteligente
                </span>
                <span className="px-4 py-2 bg-green-100 text-green-700 rounded-full text-sm font-semibold">
                  Comunicação Eficaz
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* Solutions Grid */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="space-y-20">
              {solutions.map((solution, index) => (
                <div
                  key={solution.id}
                  className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                    index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                  }`}
                >
                  {/* Content */}
                  <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                    <div className="mb-6">
                      <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                        {solution.name}
                      </h2>
                      <p className="text-xl text-blue-600 font-semibold mb-4">
                        {solution.tagline}
                      </p>
                      <p className="text-lg text-gray-600 leading-relaxed">
                        {solution.description}
                      </p>
                    </div>

                    {/* Features */}
                    <div className="mb-8">
                      <h3 className="text-xl font-bold text-gray-900 mb-4">
                        Principais Funcionalidades
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {solution.features.map((feature, featureIndex) => (
                          <div key={featureIndex} className="flex items-center space-x-2">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span className="text-gray-700">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Benefits */}
                    <div className="mb-8">
                      <h3 className="text-xl font-bold text-gray-900 mb-4">
                        Benefícios Comprovados
                      </h3>
                      <div className="space-y-2">
                        {solution.benefits.map((benefit, benefitIndex) => (
                          <div key={benefitIndex} className="flex items-start space-x-2">
                            <ArrowRight className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                            <span className="text-gray-700">{benefit}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* CTA */}
                    <div className="flex flex-col sm:flex-row gap-4">
                      <Link
                        to={solution.link}
                        className="inline-flex items-center justify-center bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl"
                      >
                        <span>Conhecer {solution.name}</span>
                        <ChevronRight className="w-5 h-5 ml-2" />
                      </Link>
                      <Link
                        to="/contato"
                        className="inline-flex items-center justify-center border-2 border-gray-300 text-gray-700 px-6 py-3 rounded-lg font-semibold hover:border-blue-600 hover:text-blue-600 transition-all duration-200"
                      >
                        Solicitar Demo
                      </Link>
                    </div>
                  </div>

                  {/* Image */}
                  <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                    <div className="relative">
                      <img
                        src={solution.image}
                        alt={`Interface do ${solution.name}`}
                        className="rounded-2xl shadow-2xl border border-gray-200"
                      />
                      <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-lg border border-gray-200">
                        <div className="flex items-center space-x-2">
                          <BookOpen className="w-6 h-6 text-blue-600" />
                          <span className="font-semibold text-gray-900">{solution.name}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Por que Escolher a iEdux?
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Tecnologia de ponta aliada ao conhecimento pedagógico para 
                resultados excepcionais
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={index}
                    className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200 hover:shadow-lg transition-all duration-300 text-center"
                  >
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-6">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600">
                      {feature.description}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Stats */}
            <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
                <div>
                  <div className="text-4xl font-bold text-blue-600 mb-2">50+</div>
                  <div className="text-gray-600">Escolas Conectadas</div>
                </div>
                <div>
                  <div className="text-4xl font-bold text-green-600 mb-2">10k+</div>
                  <div className="text-gray-600">Usuários Ativos</div>
                </div>
                <div>
                  <div className="text-4xl font-bold text-purple-600 mb-2">95%</div>
                  <div className="text-gray-600">Satisfação</div>
                </div>
                <div>
                  <div className="text-4xl font-bold text-orange-600 mb-2">24/7</div>
                  <div className="text-gray-600">Suporte Disponível</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Integration Section */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Integração Completa
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Nossa plataforma se conecta com os principais sistemas educacionais 
                do mercado brasileiro
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center opacity-60">
              {['TOTVS', 'Sistema Positivo', 'Colégio Web', 'Google', 'Microsoft', 'Canvas'].map((system, index) => (
                <div key={index} className="text-center">
                  <div className="bg-gray-100 rounded-lg p-4 h-16 flex items-center justify-center">
                    <span className="font-semibold text-gray-600 text-sm">{system}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-blue-600 to-purple-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Pronto para Transformar sua Escola?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Agende uma demonstração gratuita e descubra como nossas soluções 
              podem revolucionar sua gestão educacional
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/contato"
                className="inline-flex items-center justify-center bg-white text-purple-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-colors duration-200 shadow-lg"
              >
                Solicitar Demonstração
              </Link>
              <Link
                to="/login"
                className="inline-flex items-center justify-center border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white hover:text-purple-600 transition-all duration-200"
              >
                Acessar Plataforma
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
