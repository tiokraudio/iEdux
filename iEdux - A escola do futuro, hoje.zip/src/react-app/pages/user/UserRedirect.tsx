import { useEffect } from 'react';
import { useAuth } from '@/react-app/hooks/useAuth';

export default function UserRedirect() {
  const { user, isLoading, error } = useAuth();

  useEffect(() => {
    console.log('🔄 REGRA 3: UserRedirect - Determinando destino baseado no perfil...');
    
    // Aguardar verificação de autenticação
    if (isLoading) return;

    // REGRA 1+2: Se há erro ou utilizador não autorizado, voltar ao login
    if (error || !user || !user.authorized) {
      const errorMsg = error || 'Acesso não autorizado';
      console.log('❌ REGRA 1+2 VIOLADA: Utilizador não autorizado - enviando para login');
      window.location.href = '/login?error=' + encodeURIComponent(errorMsg);
      return;
    }

    // REGRA 3: Redirecionar baseado no PERFIL do utilizador
    console.log('🔄 REGRA 3: Redirecionando utilizador com perfil:', user.perfil);
    
    if (user.perfil === 'Super Admin') {
      console.log('✅ REGRA 3: Super Admin -> /painel');
      window.location.href = '/painel';
    } else if (user.perfil === 'Admin Instituição') {
      console.log('✅ REGRA 3: Admin Instituição -> /painel-escola');
      window.location.href = '/painel-escola';
    } else {
      console.log('✅ REGRA 3: Utilizador Final -> /aplicacoes');
      // Qualquer outro perfil vai para o launcher de aplicações
      window.location.href = '/aplicacoes';
    }
  }, [user, isLoading, error]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">A verificar permissões...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p className="text-gray-600">A redireccionar...</p>
      </div>
    </div>
  );
}
