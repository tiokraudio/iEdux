import { useState, useEffect } from 'react';
import { ExternalLink, Loader2, Grid3x3, AlertCircle } from 'lucide-react';

interface AplicacaoUsuario {
  id: number;
  nome: string;
  descricao_breve: string | null;
  url_icone: string | null;
  url_aplicacao: string | null;
  perfil_nome: string;
}

interface UsuarioInfo {
  nome: string;
  perfil: string;
  instituicao_id: number;
}

export default function AppLauncher() {
  const [aplicacoes, setAplicacoes] = useState<AplicacaoUsuario[]>([]);
  const [usuarioInfo, setUsuarioInfo] = useState<UsuarioInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLaunching, setIsLaunching] = useState<number | null>(null);

  useEffect(() => {
    fetchUserApplications();
  }, []);

  const fetchUserApplications = async () => {
    try {
      const [aplicacoesResponse, usuarioResponse] = await Promise.all([
        fetch('/api/user/aplicacoes', { credentials: 'include' }),
        fetch('/api/users/me', { credentials: 'include' })
      ]);

      const [aplicacoesData, usuarioData] = await Promise.all([
        aplicacoesResponse.json(),
        usuarioResponse.json()
      ]);

      if (aplicacoesData.success) {
        setAplicacoes(aplicacoesData.data);
      }

      if (usuarioData.authorized) {
        setUsuarioInfo({
          nome: usuarioData.nome || usuarioData.google_user_data?.name || 'Utilizador',
          perfil: usuarioData.perfil,
          instituicao_id: usuarioData.instituicao_id
        });
      }
    } catch (error) {
      console.error('Erro ao carregar aplicações do utilizador:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLaunchApp = async (aplicacao: AplicacaoUsuario) => {
    if (!aplicacao.url_aplicacao) {
      alert('URL da aplicação não configurada');
      return;
    }

    setIsLaunching(aplicacao.id);

    try {
      // Gerar token SSO
      const response = await fetch('/api/user/sso-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ 
          solucao_id: aplicacao.id,
          perfil_nome: aplicacao.perfil_nome 
        })
      });

      const result = await response.json();

      if (result.success) {
        // Construir URL com token SSO
        const ssoUrl = `${aplicacao.url_aplicacao}/sso-login?token=${result.token}`;
        
        // Abrir em nova aba
        window.open(ssoUrl, '_blank', 'noopener,noreferrer');
      } else {
        alert(result.message || 'Erro ao gerar token de acesso');
      }
    } catch (error) {
      console.error('Erro ao lançar aplicação:', error);
      alert('Erro ao lançar aplicação');
    } finally {
      setIsLaunching(null);
    }
  };

  const renderAplicacaoCard = (aplicacao: AplicacaoUsuario) => (
    <div
      key={aplicacao.id}
      className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 group"
    >
      {/* Ícone da Aplicação */}
      <div className="flex justify-center mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg group-hover:shadow-xl transition-shadow">
          {aplicacao.url_icone ? (
            <img
              src={aplicacao.url_icone}
              alt={aplicacao.nome}
              className="w-full h-full object-cover rounded-xl"
              onError={(e) => {
                // Fallback se imagem não carregar
                e.currentTarget.style.display = 'none';
                e.currentTarget.nextElementSibling?.classList.remove('hidden');
              }}
            />
          ) : null}
          <Grid3x3 className={`w-8 h-8 ${aplicacao.url_icone ? 'hidden' : ''}`} />
        </div>
      </div>

      {/* Nome da Aplicação */}
      <div className="text-center mb-4">
        <h3 className="text-lg font-bold text-gray-900 mb-1">
          {aplicacao.nome}
        </h3>
        {aplicacao.descricao_breve && (
          <p className="text-sm text-gray-600">
            {aplicacao.descricao_breve}
          </p>
        )}
        <div className="mt-2">
          <span className="inline-block px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
            {aplicacao.perfil_nome}
          </span>
        </div>
      </div>

      {/* Botão de Acesso */}
      <button
        onClick={() => handleLaunchApp(aplicacao)}
        disabled={isLaunching === aplicacao.id || !aplicacao.url_aplicacao}
        className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 font-medium shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLaunching === aplicacao.id ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>A abrir...</span>
          </>
        ) : (
          <>
            <ExternalLink className="w-5 h-5" />
            <span>Aceder</span>
          </>
        )}
      </button>

      {!aplicacao.url_aplicacao && (
        <p className="text-xs text-red-500 text-center mt-2">
          URL não configurada
        </p>
      )}
    </div>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">A carregar as suas aplicações...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="mb-6">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <span className="text-white font-bold text-2xl">iE</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              Bem-vindo, {usuarioInfo?.nome}!
            </h1>
            <p className="text-xl text-gray-600">
              As suas aplicações educacionais
            </p>
          </div>
        </div>

        {/* Grid de Aplicações */}
        {aplicacoes.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <AlertCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Nenhuma aplicação disponível
            </h3>
            <p className="text-gray-600 mb-4">
              Ainda não tem acesso a nenhuma aplicação educacional.
            </p>
            <p className="text-sm text-gray-500">
              Entre em contacto com o administrador da sua instituição para solicitar acesso.
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
              {aplicacoes.map(renderAplicacaoCard)}
            </div>

            {/* Footer informativo */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 text-center">
              <p className="text-blue-800 text-sm">
                <strong>Dica:</strong> Clique em "Aceder" para abrir a aplicação numa nova aba. 
                O acesso é automático através do sistema de autenticação única (SSO).
              </p>
            </div>
          </>
        )}

        {/* Logout */}
        <div className="text-center mt-8">
          <a
            href="/api/logout"
            className="text-gray-500 hover:text-gray-700 text-sm underline"
          >
            Terminar sessão
          </a>
        </div>
      </div>
    </div>
  );
}
