import { Link } from 'react-router';
import Header from '@/react-app/components/Header';
import Footer from '@/react-app/components/Footer';
import { 
  Users, 
  Heart, 
  MessageSquare, 
  BarChart3, 
  CheckCircle, 
  ArrowRight,
  Shield,
  Clock,
  Target,
  Download,
  Play,
  UserCheck,
  BookOpen,
  TrendingUp
} from 'lucide-react';

export default function SoeDetailPage() {
  const features = [
    {
      icon: UserCheck,
      title: 'Ficha Individual do Aluno',
      description: 'Registro completo do desenvolvimento acadêmico, comportamental e socioemocional de cada estudante.',
      details: [
        'Histórico acadêmico detalhado',
        'Registros comportamentais',
        'Acompanhamento socioemocional',
        'Fotos e documentos anexos'
      ]
    },
    {
      icon: MessageSquare,
      title: 'Comunicação Escola-Família',
      description: 'Canal direto e eficiente para manter pais e responsáveis sempre informados sobre o desenvolvimento dos alunos.',
      details: [
        'Notificações automáticas',
        'Mensagens personalizadas',
        'Agendamento de reuniões',
        'Relatórios para responsáveis'
      ]
    },
    {
      icon: BarChart3,
      title: 'Relatórios de Desenvolvimento',
      description: 'Análises completas do progresso acadêmico e comportamental com gráficos e indicadores visuais.',
      details: [
        'Gráficos de evolução',
        'Comparativos de turma',
        'Indicadores de alerta',
        'Relatórios personalizáveis'
      ]
    },
    {
      icon: Target,
      title: 'Planos de Intervenção',
      description: 'Ferramentas para criar e acompanhar planos de ação personalizados para cada aluno.',
      details: [
        'Diagnóstico de necessidades',
        'Planos de ação estruturados',
        'Acompanhamento de progresso',
        'Avaliação de resultados'
      ]
    }
  ];

  const benefits = [
    {
      metric: '80%',
      description: 'Melhoria na comunicação escola-família'
    },
    {
      metric: '65%',
      description: 'Redução em problemas comportamentais'
    },
    {
      metric: '90%',
      description: 'Satisfação dos responsáveis'
    },
    {
      metric: '75%',
      description: 'Aumento no engajamento dos alunos'
    }
  ];

  const workflow = [
    {
      step: '1',
      title: 'Registro de Ocorrências',
      description: 'Professores registram facilmente eventos acadêmicos e comportamentais'
    },
    {
      step: '2',
      title: 'Análise Automática',
      description: 'Sistema identifica padrões e gera alertas para situações que requerem atenção'
    },
    {
      step: '3',
      title: 'Comunicação Imediata',
      description: 'Responsáveis são notificados automaticamente sobre eventos importantes'
    },
    {
      step: '4',
      title: 'Plano de Ação',
      description: 'Equipe pedagógica desenvolve estratégias personalizadas quando necessário'
    }
  ];

  const useCases = [
    {
      icon: Heart,
      title: 'Desenvolvimento Socioemocional',
      description: 'Acompanhe o desenvolvimento das competências socioemocionais dos alunos.',
      features: ['Registro de comportamentos', 'Competências BNCC', 'Planos de desenvolvimento', 'Relatórios para famílias']
    },
    {
      icon: BookOpen,
      title: 'Acompanhamento Pedagógico',
      description: 'Monitore o progresso acadêmico e identifique necessidades de apoio.',
      features: ['Notas e conceitos', 'Dificuldades de aprendizagem', 'Estratégias pedagógicas', 'Recuperação paralela']
    },
    {
      icon: Users,
      title: 'Gestão de Conflitos',
      description: 'Registre e acompanhe a resolução de conflitos entre alunos.',
      features: ['Mediação de conflitos', 'Registro de ocorrências', 'Planos de convivência', 'Acompanhamento familiar']
    },
    {
      icon: TrendingUp,
      title: 'Indicadores de Performance',
      description: 'Analise dados para tomada de decisões pedagógicas mais assertivas.',
      features: ['Dashboards visuais', 'Relatórios gerenciais', 'Comparativos de turma', 'Tendências de comportamento']
    }
  ];

  const testimonials = [
    {
      name: 'Ana Paula Costa',
      role: 'Orientadora Educacional',
      school: 'Escola Crescer',
      quote: 'O SOE transformou nossa forma de acompanhar os alunos. Agora temos uma visão 360° de cada estudante.',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b524?w=100&h=100&fit=crop&crop=face'
    },
    {
      name: 'Carlos Mendes',
      role: 'Diretor Pedagógico',
      school: 'Colégio Horizonte',
      quote: 'A comunicação com as famílias melhorou drasticamente. Os pais se sentem mais conectados com a escola.',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-purple-50 via-white to-blue-50 pt-20 pb-16 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="mb-6">
                  <span className="inline-block px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-semibold mb-4">
                    Solução iEdux
                  </span>
                  <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">
                    SOE
                  </h1>
                  <p className="text-2xl text-purple-600 font-semibold mb-6">
                    Sistema de Orientação Educacional
                  </p>
                  <p className="text-xl text-gray-600 leading-relaxed">
                    Plataforma completa para acompanhamento pedagógico individualizado, 
                    fortalecendo a comunicação entre escola e família para o desenvolvimento 
                    integral dos estudantes.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 mb-8">
                  <Link
                    to="/contato"
                    className="inline-flex items-center justify-center bg-gradient-to-r from-purple-600 to-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:from-purple-700 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl"
                  >
                    <Play className="w-5 h-5 mr-2" />
                    Ver Demonstração
                  </Link>
                  <button className="inline-flex items-center justify-center border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-xl font-semibold hover:border-purple-600 hover:text-purple-600 transition-all duration-200">
                    <Download className="w-5 h-5 mr-2" />
                    Baixar Catálogo
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">15k+</div>
                    <div className="text-sm text-gray-600">Alunos</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">300+</div>
                    <div className="text-sm text-gray-600">Educadores</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">8k+</div>
                    <div className="text-sm text-gray-600">Famílias</div>
                  </div>
                </div>
              </div>

              <div className="relative">
                <img
                  src="https://mocha-cdn.com/019a593b-ef35-795c-9777-c39c5e44a28a/soe-interface.png"
                  alt="Interface do SOE"
                  className="rounded-2xl shadow-2xl border border-gray-200"
                />
                <div className="absolute top-4 right-4 bg-white p-3 rounded-xl shadow-lg">
                  <div className="flex items-center space-x-2">
                    <Heart className="w-4 h-4 text-red-500" />
                    <span className="text-sm font-semibold text-gray-900">Cuidado Integral</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Funcionalidades Especializadas
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Ferramentas desenvolvidas especificamente para orientação educacional e acompanhamento integral
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={index}
                    className="bg-gradient-to-br from-gray-50 to-purple-50 rounded-2xl p-8 hover:shadow-lg transition-all duration-300"
                  >
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-gray-900 mb-2">
                          {feature.title}
                        </h3>
                        <p className="text-gray-600 mb-4">
                          {feature.description}
                        </p>
                        <ul className="space-y-2">
                          {feature.details.map((detail, detailIndex) => (
                            <li key={detailIndex} className="flex items-center space-x-2">
                              <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                              <span className="text-sm text-gray-700">{detail}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Use Cases Section */}
        <section className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Casos de Uso do SOE
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Veja como o SOE pode ser aplicado em diferentes contextos educacionais
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {useCases.map((useCase, index) => {
                const Icon = useCase.icon;
                return (
                  <div
                    key={index}
                    className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200 hover:shadow-lg transition-all duration-300"
                  >
                    <div className="flex items-start space-x-4 mb-6">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2">
                          {useCase.title}
                        </h3>
                        <p className="text-gray-600">
                          {useCase.description}
                        </p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {useCase.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                          <span className="text-sm text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Workflow Section */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Como o SOE Funciona
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Fluxo intuitivo para acompanhamento contínuo do desenvolvimento dos alunos
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {workflow.map((step, index) => (
                <div key={index} className="text-center">
                  <div className="relative mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl font-bold text-white">{step.step}</span>
                    </div>
                    {index < workflow.length - 1 && (
                      <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-purple-600 to-blue-600 transform -translate-y-1/2"></div>
                    )}
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    {step.title}
                  </h3>
                  <p className="text-gray-600">
                    {step.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 bg-gradient-to-br from-purple-50 to-blue-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Impacto Comprovado
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Escolas que utilizam o SOE observam melhorias significativas no desenvolvimento dos alunos
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {benefits.map((benefit, index) => (
                <div
                  key={index}
                  className="text-center bg-white rounded-2xl p-8 shadow-sm border border-gray-200"
                >
                  <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-4">
                    {benefit.metric}
                  </div>
                  <p className="text-gray-700 font-medium">
                    {benefit.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Case Study */}
            <div className="bg-white rounded-2xl p-8 md:p-12 shadow-lg border border-gray-200">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">
                    Caso de Sucesso: Escola Harmonia
                  </h3>
                  <p className="text-gray-600 mb-6">
                    A Escola Harmonia, com 800 alunos, implementou o SOE para melhorar 
                    o acompanhamento pedagógico e a comunicação com as famílias. 
                    Os resultados superaram todas as expectativas.
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <Heart className="w-5 h-5 text-red-500" />
                      <span className="text-gray-700">Redução de 60% em conflitos entre alunos</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Users className="w-5 h-5 text-blue-500" />
                      <span className="text-gray-700">90% dos pais participam ativamente das reuniões</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <TrendingUp className="w-5 h-5 text-green-500" />
                      <span className="text-gray-700">Melhoria de 35% no desempenho acadêmico</span>
                    </div>
                  </div>
                </div>
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1509062522246-3755977927d7?w=600&h=400&fit=crop"
                    alt="Professora conversando com alunos"
                    className="rounded-xl shadow-lg"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Depoimentos de Educadores
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Veja o que orientadores e gestores educacionais falam sobre o SOE
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-8 border border-gray-200"
                >
                  <div className="flex items-start space-x-4 mb-6">
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                      <p className="text-purple-600 text-sm">{testimonial.role}</p>
                      <p className="text-gray-500 text-sm">{testimonial.school}</p>
                    </div>
                  </div>
                  <blockquote className="text-gray-700 italic">
                    "{testimonial.quote}"
                  </blockquote>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Integration Section */}
        <section className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-6">
                  Integração e Privacidade
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  O SOE foi desenvolvido com foco na proteção da privacidade dos alunos 
                  e integração perfeita com os sistemas da escola, garantindo segurança 
                  e conformidade com todas as regulamentações.
                </p>
                
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <Shield className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Privacidade Garantida</h3>
                      <p className="text-gray-600">Compliance total com LGPD e proteção máxima dos dados dos estudantes</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <UserCheck className="w-6 h-6 text-blue-500 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Controle de Acesso</h3>
                      <p className="text-gray-600">Permissões granulares para diferentes perfis de usuários</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <Clock className="w-6 h-6 text-purple-500 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Histórico Preservado</h3>
                      <p className="text-gray-600">Registro completo e seguro do desenvolvimento de cada aluno</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="relative">
                <div className="bg-gradient-to-br from-purple-100 to-blue-100 rounded-2xl p-8">
                  <div className="text-center mb-6">
                    <Shield className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Segurança Máxima</h3>
                    <p className="text-gray-600">Proteção completa dos dados educacionais</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-green-600 mb-1">100%</div>
                      <div className="text-xs text-gray-600">LGPD Compliant</div>
                    </div>
                    <div className="bg-white rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-blue-600 mb-1">256bit</div>
                      <div className="text-xs text-gray-600">Criptografia</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-purple-600 to-blue-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Transforme o Acompanhamento dos seus Alunos
            </h2>
            <p className="text-xl text-purple-100 mb-8 max-w-3xl mx-auto">
              Descubra como o SOE pode fortalecer a relação escola-família e 
              promover o desenvolvimento integral dos estudantes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/contato"
                className="inline-flex items-center justify-center bg-white text-purple-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-colors duration-200 shadow-lg"
              >
                <Heart className="w-5 h-5 mr-2" />
                Conhecer o SOE
              </Link>
              <Link
                to="/solucoes"
                className="inline-flex items-center justify-center border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white hover:text-purple-600 transition-all duration-200"
              >
                Ver Outras Soluções
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
