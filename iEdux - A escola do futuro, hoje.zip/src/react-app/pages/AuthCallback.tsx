import { useEffect, useState } from 'react';
import { useAuth } from '@getmocha/users-service/react';

export default function AuthCallback() {
  const { exchangeCodeForSessionToken, user } = useAuth();
  const [isProcessing, setIsProcessing] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const processCallback = async () => {
      try {
        console.log('🔄 Iniciando processamento do callback...');
        
        // Verificar se temos parâmetros de callback na URL
        const urlParams = new URLSearchParams(window.location.search);
        const code = urlParams.get('code');
        const state = urlParams.get('state');
        console.log('📋 Parâmetros do callback:', { code: !!code, state: !!state });
        
        if (!code) {
          throw new Error('Código de autorização não encontrado na URL');
        }

        // Trocar o código pelo token de sessão usando o hook do Mocha
        console.log('🔑 Trocando código por token...');
        await exchangeCodeForSessionToken();
        console.log('✅ Token obtido com sucesso');
        
        // Aguardar um pouco para garantir que o token foi salvo
        console.log('⏳ Aguardando token ser salvo...');
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Verificar se o usuário está autorizado no nosso sistema
        console.log('🔐 Verificando autorização no sistema...');
        const response = await fetch('/api/users/authorize', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
          }
        });

        console.log('📤 Resposta da autorização:', response.status, response.statusText);

        if (!response.ok) {
          const data = await response.json().catch(() => ({ message: 'Erro na resposta da API' }));
          const errorMessage = data.message || `Erro interno (${response.status})`;
          throw new Error(errorMessage);
        }

        const result = await response.json();
        console.log('✅ Autorização bem-sucedida:', result);
        
        if (!result.success) {
          throw new Error(result.message || 'Falha na autorização');
        }

        setIsProcessing(false);
      } catch (err) {
        console.error('💥 Erro no callback de autenticação:', err);
        const errorMessage = err instanceof Error ? err.message : 'Erro no processo de autenticação';
        setError(errorMessage);
        setIsProcessing(false);
        
        // Redirecionar para login com erro após 3 segundos
        setTimeout(() => {
          window.location.href = `/login?error=${encodeURIComponent(errorMessage)}`;
        }, 3000);
      }
    };

    processCallback();
  }, [exchangeCodeForSessionToken]);

  // Se processamento concluído com sucesso e usuário logado, redirecionar
  if (!isProcessing && user && !error) {
    console.log('✅ Login completo, redirecionando...');
    // Redirecionar para a página que irá determinar o destino baseado no perfil
    window.location.href = '/redirect';
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Logo */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">iEdux</h1>
            <div className="w-12 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto rounded-full"></div>
          </div>

          {isProcessing && !error && (
            <>
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                Processando login...
              </h2>
              <p className="text-gray-600">
                Verificando suas credenciais e permissões
              </p>
            </>
          )}

          {error && (
            <>
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </div>
              <h2 className="text-xl font-semibold text-red-600 mb-2">
                Acesso Negado
              </h2>
              <p className="text-gray-600 mb-4">
                {error}
              </p>
              <p className="text-sm text-gray-500">
                Redirecionando para a página de login...
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
