import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from '@getmocha/users-service/react';
import ProtectedRoute from "@/react-app/components/ProtectedRoute";
import HomePage from "@/react-app/pages/Home";
import AboutUsPage from "@/react-app/pages/AboutUs";
import SolutionsPage from "@/react-app/pages/Solutions";
import ContactPage from "@/react-app/pages/Contact";
import QuestPage from "@/react-app/pages/QuestDetail";
import SoePage from "@/react-app/pages/SoeDetail";
import LoginPage from "@/react-app/pages/Login";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import AdminDashboard from "@/react-app/pages/admin/Dashboard";
import Instituicoes from "@/react-app/pages/admin/Instituicoes";
import ConectoresErp from "@/react-app/pages/admin/ConectoresErp";
import Solucoes from "@/react-app/pages/admin/Solucoes";
import InstituicaoLicencas from "@/react-app/pages/admin/InstituicaoLicencas";
import InstituicaoAdministrador from "@/react-app/pages/admin/InstituicaoAdministrador";
import Leads from "@/react-app/pages/admin/Leads";
import Administradores from "@/react-app/pages/admin/Administradores";
import EscolaDashboard from "@/react-app/pages/escola/Dashboard";
import SecretariaDigital from "@/react-app/pages/escola/SecretariaDigital";
import SincronizacaoErp from "@/react-app/pages/escola/SincronizacaoErp";
import GestaoSolucoes from "@/react-app/pages/escola/GestaoSolucoes";
import GerirAcessos from "@/react-app/pages/escola/GerirAcessos";
import AppLauncher from "@/react-app/pages/user/AppLauncher";
import UserRedirect from "@/react-app/pages/user/UserRedirect";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Rotas Públicas */}
          <Route path="/" element={<HomePage />} />
          <Route path="/sobre" element={<AboutUsPage />} />
          <Route path="/solucoes" element={<SolutionsPage />} />
          <Route path="/solucoes/quest" element={<QuestPage />} />
          <Route path="/solucoes/soe" element={<SoePage />} />
          <Route path="/contato" element={<ContactPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/redirect" element={<UserRedirect />} />
          
          {/* Rotas do Super Admin - PROTEGIDAS */}
          <Route path="/painel" element={
            <ProtectedRoute requiredRole="Super Admin">
              <AdminDashboard />
            </ProtectedRoute>
          } />
          <Route path="/painel/instituicoes" element={
            <ProtectedRoute requiredRole="Super Admin">
              <Instituicoes />
            </ProtectedRoute>
          } />
          <Route path="/painel/instituicoes/:id/licencas" element={
            <ProtectedRoute requiredRole="Super Admin">
              <InstituicaoLicencas />
            </ProtectedRoute>
          } />
          <Route path="/painel/instituicoes/:id/administrador" element={
            <ProtectedRoute requiredRole="Super Admin">
              <InstituicaoAdministrador />
            </ProtectedRoute>
          } />
          <Route path="/painel/conectores" element={
            <ProtectedRoute requiredRole="Super Admin">
              <ConectoresErp />
            </ProtectedRoute>
          } />
          <Route path="/painel/solucoes" element={
            <ProtectedRoute requiredRole="Super Admin">
              <Solucoes />
            </ProtectedRoute>
          } />
          <Route path="/painel/leads" element={
            <ProtectedRoute requiredRole="Super Admin">
              <Leads />
            </ProtectedRoute>
          } />
          <Route path="/painel/administradores" element={
            <ProtectedRoute requiredRole="Super Admin">
              <Administradores />
            </ProtectedRoute>
          } />
          
          {/* Rotas do Admin da Instituição - PROTEGIDAS */}
          <Route path="/painel-escola" element={
            <ProtectedRoute requiredRole="Admin Instituição">
              <EscolaDashboard />
            </ProtectedRoute>
          } />
          <Route path="/painel-escola/secretaria" element={
            <ProtectedRoute requiredRole="Admin Instituição">
              <SecretariaDigital />
            </ProtectedRoute>
          } />
          <Route path="/painel-escola/sincronizacao" element={
            <ProtectedRoute requiredRole="Admin Instituição">
              <SincronizacaoErp />
            </ProtectedRoute>
          } />
          <Route path="/painel-escola/solucoes" element={
            <ProtectedRoute requiredRole="Admin Instituição">
              <GestaoSolucoes />
            </ProtectedRoute>
          } />
          <Route path="/painel-escola/solucoes/:id/acessos" element={
            <ProtectedRoute requiredRole="Admin Instituição">
              <GerirAcessos />
            </ProtectedRoute>
          } />
          
          {/* Rotas do Utilizador Final - PROTEGIDAS */}
          <Route path="/aplicacoes" element={
            <ProtectedRoute>
              <AppLauncher />
            </ProtectedRoute>
          } />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
