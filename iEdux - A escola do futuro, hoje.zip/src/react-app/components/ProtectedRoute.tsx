import { ReactNode, useEffect, useState } from 'react';

interface ProtectedRouteProps {
  children: ReactNode;
  requiredRole?: 'Super Admin' | 'Admin Instituição' | 'End User';
  fallbackPath?: string;
}

export default function ProtectedRoute({ 
  children, 
  requiredRole,
  fallbackPath = '/login' 
}: ProtectedRouteProps) {
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [authError, setAuthError] = useState<string>('');

  useEffect(() => {
    const checkAuthentication = async () => {
      console.log('🔐 REGRA 1: ProtectedRoute - Verificando se utilizador pode entrar...');
      
      try {
        console.log('🔑 Consultando API de segurança...');
        
        const response = await fetch('/api/users/me', {
          credentials: 'include',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          }
        });

        console.log('📡 Resposta da API de segurança:', response.status);

        // REGRA 1 + 2: Se a API retornar 401 ou 403, utilizador não pode entrar
        if (response.status === 401 || response.status === 403) {
          console.log('❌ REGRA 1+2 VIOLADA: API bloqueou acesso - redirecionando para login');
          window.location.href = fallbackPath;
          return;
        }

        // Se qualquer outro erro, também bloquear
        if (!response.ok) {
          console.log('❌ REGRA 1 VIOLADA: Erro na API - bloqueando acesso');
          window.location.href = fallbackPath;
          return;
        }

        // Ler resposta da API
        let userData;
        try {
          userData = await response.json();
        } catch (e) {
          console.log('❌ REGRA 1 VIOLADA: Resposta inválida da API - bloqueando acesso');
          window.location.href = fallbackPath;
          return;
        }
        
        console.log('👤 Utilizador verificado:', userData.email, 'Perfil:', userData.perfil);

        // REGRA 2: Verificar se está autorizado
        if (!userData.authorized) {
          console.log('❌ REGRA 2 VIOLADA: E-mail não cadastrado - bloqueando acesso');
          setAuthError('Acesso negado: E-mail não cadastrado no sistema');
          setIsCheckingAuth(false);
          return;
        }

        // REGRA 3: Verificar perfil se necessário
        if (requiredRole && userData.perfil !== requiredRole) {
          console.log('❌ REGRA 3 VIOLADA: Perfil incorreto. Necessário:', requiredRole, 'Actual:', userData.perfil);
          
          // REGRA 3: Redirecionar para o painel correto baseado no perfil
          if (userData.perfil === 'Super Admin') {
            window.location.href = '/painel';
          } else if (userData.perfil === 'Admin Instituição') {
            window.location.href = '/painel-escola';
          } else {
            window.location.href = '/aplicacoes';
          }
          return;
        }

        // SUCESSO: Todas as regras de segurança passaram
        console.log('✅ TODAS AS REGRAS APROVADAS: Utilizador autorizado com perfil:', userData.perfil);
        setUserProfile(userData);
        setIsCheckingAuth(false);

      } catch (error) {
        console.error('💥 ERRO CRÍTICO na verificação de segurança:', error);
        console.log('❌ REGRA 1 VIOLADA: Erro na verificação - bloqueando acesso');
        window.location.href = fallbackPath;
        return;
      }
    };

    checkAuthentication();
  }, [requiredRole, fallbackPath]);

  // Mostrar loading enquanto verifica
  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">A verificar permissões...</p>
        </div>
      </div>
    );
  }

  // Mostrar erro se houver
  if (authError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center px-4">
        <div className="max-w-md w-full text-center">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
            <h2 className="text-xl font-semibold text-red-600 mb-2">
              Acesso Negado
            </h2>
            <p className="text-gray-600 mb-4">{authError}</p>
            <a
              href="/login"
              className="inline-block px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Voltar ao Login
            </a>
          </div>
        </div>
      </div>
    );
  }

  // SUCESSO: Renderizar conteúdo protegido
  console.log('✅ ProtectedRoute: Renderizando conteúdo protegido para:', userProfile?.email);
  return <>{children}</>;
}
