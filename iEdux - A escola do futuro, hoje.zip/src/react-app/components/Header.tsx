import { useState } from 'react';
import { Link } from 'react-router';
import { Menu, X, ChevronDown } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSolutionsOpen, setIsSolutionsOpen] = useState(false);

  const solutionItems = [
    { name: 'Quest', href: '/solucoes/quest', description: 'Plataforma colaborativa para criação de provas' },
    { name: 'SOE', href: '/solucoes/soe', description: 'Sistema de Orientação Educacional' },
  ];

  return (
    <header className="bg-white/95 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" aria-label="Top">
        <div className="w-full py-6 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">iE</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">iEdux</h1>
                <p className="text-xs text-gray-600 -mt-1">A escola do futuro, hoje</p>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link
              to="/"
              className="text-gray-700 hover:text-blue-600 font-medium transition-colors duration-200"
            >
              Início
            </Link>
            
            <div className="relative group">
              <button
                className="flex items-center space-x-1 text-gray-700 hover:text-blue-600 font-medium transition-colors duration-200"
                onMouseEnter={() => setIsSolutionsOpen(true)}
                onMouseLeave={() => setIsSolutionsOpen(false)}
              >
                <span>Soluções</span>
                <ChevronDown className="w-4 h-4" />
              </button>

              {/* Dropdown Menu */}
              <div
                className={`absolute top-full left-0 mt-2 w-72 bg-white rounded-xl shadow-lg border border-gray-200 py-4 transition-all duration-200 ${
                  isSolutionsOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
                }`}
                onMouseEnter={() => setIsSolutionsOpen(true)}
                onMouseLeave={() => setIsSolutionsOpen(false)}
              >
                {solutionItems.map((item) => (
                  <Link
                    key={item.name}
                    to={item.href}
                    className="block px-6 py-3 hover:bg-blue-50 transition-colors duration-200"
                  >
                    <div className="font-semibold text-gray-900">{item.name}</div>
                    <div className="text-sm text-gray-600 mt-1">{item.description}</div>
                  </Link>
                ))}
                <div className="border-t border-gray-200 mt-2 pt-2">
                  <Link
                    to="/solucoes"
                    className="block px-6 py-2 text-blue-600 hover:text-blue-700 font-medium text-sm"
                  >
                    Ver todas as soluções →
                  </Link>
                </div>
              </div>
            </div>

            <Link
              to="/sobre"
              className="text-gray-700 hover:text-blue-600 font-medium transition-colors duration-200"
            >
              Sobre
            </Link>

            <Link
              to="/contato"
              className="text-gray-700 hover:text-blue-600 font-medium transition-colors duration-200"
            >
              Contato
            </Link>

            <Link
              to="/login"
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-2 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-md hover:shadow-lg"
            >
              Acessar Plataforma
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-blue-600 transition-colors duration-200"
            >
              {isMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t border-gray-200">
              <Link
                to="/"
                className="block px-3 py-2 text-gray-700 hover:text-blue-600 font-medium transition-colors duration-200"
                onClick={() => setIsMenuOpen(false)}
              >
                Início
              </Link>
              
              <div className="space-y-1">
                <div className="px-3 py-2 text-gray-700 font-medium">Soluções</div>
                {solutionItems.map((item) => (
                  <Link
                    key={item.name}
                    to={item.href}
                    className="block px-6 py-2 text-gray-600 hover:text-blue-600 transition-colors duration-200"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                ))}
                <Link
                  to="/solucoes"
                  className="block px-6 py-2 text-blue-600 hover:text-blue-700 font-medium"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Ver todas →
                </Link>
              </div>

              <Link
                to="/sobre"
                className="block px-3 py-2 text-gray-700 hover:text-blue-600 font-medium transition-colors duration-200"
                onClick={() => setIsMenuOpen(false)}
              >
                Sobre
              </Link>

              <Link
                to="/contato"
                className="block px-3 py-2 text-gray-700 hover:text-blue-600 font-medium transition-colors duration-200"
                onClick={() => setIsMenuOpen(false)}
              >
                Contato
              </Link>

              <Link
                to="/login"
                className="block mx-3 mt-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-2 rounded-lg font-semibold text-center transition-all duration-200"
                onClick={() => setIsMenuOpen(false)}
              >
                Acessar Plataforma
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
