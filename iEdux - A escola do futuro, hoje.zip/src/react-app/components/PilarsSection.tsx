import { Users, RefreshCw, MessageSquare, Shield } from 'lucide-react';

export default function PilarsSection() {
  const pilars = [
    {
      icon: Users,
      title: 'Gestão Acadêmica',
      description: 'Hub central que unifica todos os aspectos da gestão escolar em uma única plataforma intuitiva.',
      color: 'from-blue-600 to-cyan-500',
      bgColor: 'bg-blue-50'
    },
    {
      icon: RefreshCw,
      title: 'Integração ERP',
      description: 'Sincronização automática com sistemas de gestão existentes, eliminando retrabalho.',
      color: 'from-green-600 to-emerald-500',
      bgColor: 'bg-green-50'
    },
    {
      icon: MessageSquare,
      title: 'Comunicação',
      description: 'Canais eficientes de comunicação entre escola, alunos e responsáveis.',
      color: 'from-purple-600 to-violet-500',
      bgColor: 'bg-purple-50'
    },
    {
      icon: Shield,
      title: 'Segurança',
      description: 'Proteção de dados com padrões internacionais e compliance com LGPD.',
      color: 'from-orange-600 to-red-500',
      bgColor: 'bg-orange-50'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Os Pilares da{' '}
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              iEdux
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Nossa plataforma se baseia em quatro pilares fundamentais que garantem 
            uma experiência educacional completa e moderna.
          </p>
        </div>

        {/* Pilars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {pilars.map((pilar, index) => {
            const Icon = pilar.icon;
            
            return (
              <div
                key={index}
                className={`${pilar.bgColor} rounded-2xl p-8 hover:scale-105 transition-all duration-300 group cursor-pointer border border-gray-100 hover:shadow-xl`}
              >
                <div className={`w-16 h-16 bg-gradient-to-br ${pilar.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  {pilar.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed">
                  {pilar.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 border border-gray-200">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Transforme sua escola com a iEdux
            </h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Junte-se às escolas que já descobriram como a tecnologia pode potencializar 
              a educação e criar experiências de aprendizado extraordinárias.
            </p>
            <a
              href="/contato"
              className="inline-flex items-center bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              Agendar Apresentação
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
