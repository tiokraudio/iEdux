
DROP INDEX idx_leads_created_at;
DROP INDEX idx_leads_email;
DROP TABLE leads;
