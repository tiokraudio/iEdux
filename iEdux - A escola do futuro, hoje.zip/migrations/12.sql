
-- Inserir utilizador Super Admin de teste para validar as regras de segurança
INSERT INTO usuarios (email, nome, perfil, is_ativo) 
VALUES ('admin@iedux.com', 'Admin Teste', 'Super Admin', 1)
ON CONFLICT(email) DO UPDATE SET
  nome = excluded.nome,
  perfil = excluded.perfil,
  is_ativo = excluded.is_ativo;

-- Inserir uma instituição de teste
INSERT INTO instituicoes (nome, status, modo_dados) 
VALUES ('Escola Teste', 'ativa', 'manual')
ON CONFLICT DO NOTHING;

-- Inserir Admin da Instituição de teste
INSERT INTO usuarios (email, nome, perfil, instituicao_id, is_ativo) 
VALUES ('escola@iedux.com', 'Admin Escola Teste', 'Admin Instituição', 1, 1)
ON CONFLICT(email) DO UPDATE SET
  nome = excluded.nome,
  perfil = excluded.perfil,
  instituicao_id = excluded.instituicao_id,
  is_ativo = excluded.is_ativo;

-- Inserir uma solução de teste
INSERT INTO solucoes (nome, status, descricao_breve, url_aplicacao) 
VALUES ('Quest - Teste', 'ativa', 'Plataforma de criação de provas (versão teste)', 'https://quest.exemplo.com')
ON CONFLICT DO NOTHING;

-- Inserir perfil de solução de teste
INSERT INTO perfis_solucoes (solucao_id, nome_perfil, descricao_perfil) 
VALUES (1, 'Quest_Professor', 'Professor pode criar e editar provas')
ON CONFLICT DO NOTHING;

-- Inserir licença da instituição de teste
INSERT INTO licencas_instituicoes (instituicao_id, solucao_id, is_ativa) 
VALUES (1, 1, 1)
ON CONFLICT(instituicao_id, solucao_id) DO UPDATE SET is_ativa = excluded.is_ativa;

-- Inserir utilizador da escola de teste
INSERT INTO usuarios_escola (instituicao_id, nome, email, tipo_usuario, is_ativo) 
VALUES (1, 'Professor Teste', 'professor@iedux.com', 'professor', 1)
ON CONFLICT DO NOTHING;

-- Inserir atribuição de perfil de teste
INSERT INTO atribuicoes_perfis (usuario_id, solucao_id, perfil_solucao_id, instituicao_id) 
VALUES (1, 1, 1, 1)
ON CONFLICT(usuario_id, solucao_id) DO UPDATE SET 
  perfil_solucao_id = excluded.perfil_solucao_id,
  instituicao_id = excluded.instituicao_id;
