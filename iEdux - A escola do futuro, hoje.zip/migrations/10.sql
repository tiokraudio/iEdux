
CREATE TABLE atribuicoes_perfis (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  solucao_id INTEGER NOT NULL,
  perfil_solucao_id INTEGER NOT NULL,
  instituicao_id INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(usuario_id, solucao_id)
);

CREATE INDEX idx_atribuicoes_perfis_instituicao ON atribuicoes_perfis(instituicao_id);
CREATE INDEX idx_atribuicoes_perfis_solucao ON atribuicoes_perfis(solucao_id);
