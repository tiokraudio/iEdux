
DROP INDEX idx_instituicoes_status;
DROP TABLE instituicoes;
