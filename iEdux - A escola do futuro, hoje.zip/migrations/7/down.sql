
DROP INDEX idx_leads_status;
ALTER TABLE leads DROP COLUMN status;
