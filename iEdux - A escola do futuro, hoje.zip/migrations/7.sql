
ALTER TABLE leads ADD COLUMN status TEXT DEFAULT 'novo';
CREATE INDEX idx_leads_status ON leads(status);
