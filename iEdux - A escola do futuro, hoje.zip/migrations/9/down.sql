
-- Remover índices
DROP INDEX IF EXISTS idx_disciplinas_instituicao;
DROP INDEX IF EXISTS idx_turmas_instituicao;
DROP INDEX IF EXISTS idx_alunos_responsaveis_responsavel;
DROP INDEX IF EXISTS idx_alunos_responsaveis_aluno;
DROP INDEX IF EXISTS idx_responsaveis_instituicao;
DROP INDEX IF EXISTS idx_alunos_instituicao;
DROP INDEX IF EXISTS idx_usuarios_escola_instituicao;

-- Remover tabelas na ordem inversa
DROP TABLE IF EXISTS log_sincronizacoes;
DROP TABLE IF EXISTS credenciais_erp;
DROP TABLE IF EXISTS disciplinas;
DROP TABLE IF EXISTS turmas;
DROP TABLE IF EXISTS alunos_responsaveis;
DROP TABLE IF EXISTS responsaveis;
DROP TABLE IF EXISTS alunos;
DROP TABLE IF EXISTS usuarios_escola;
