
-- Tabela para armazenar usuários da escola (professores, coordenadores, etc.)
CREATE TABLE usuarios_escola (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  instituicao_id INTEGER NOT NULL,
  nome TEXT NOT NULL,
  email TEXT NOT NULL,
  tipo_usuario TEXT NOT NULL, -- professor, coordenador, porteiro, etc.
  is_ativo BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para alunos
CREATE TABLE alunos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  instituicao_id INTEGER NOT NULL,
  nome TEXT NOT NULL,
  data_nascimento DATE,
  cpf TEXT,
  email TEXT,
  telefone TEXT,
  endereco TEXT,
  turma_id INTEGER,
  is_ativo BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para responsáveis
CREATE TABLE responsaveis (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  instituicao_id INTEGER NOT NULL,
  nome TEXT NOT NULL,
  email TEXT,
  telefone TEXT,
  cpf TEXT,
  parentesco TEXT, -- pai, mae, avo, tio, etc.
  is_ativo BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para vincular alunos aos responsáveis
CREATE TABLE alunos_responsaveis (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  aluno_id INTEGER NOT NULL,
  responsavel_id INTEGER NOT NULL,
  is_principal BOOLEAN DEFAULT 0, -- responsável principal
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(aluno_id, responsavel_id)
);

-- Tabela para turmas
CREATE TABLE turmas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  instituicao_id INTEGER NOT NULL,
  nome TEXT NOT NULL,
  ano_letivo TEXT NOT NULL,
  serie TEXT,
  periodo TEXT, -- matutino, vespertino, noturno
  capacidade_maxima INTEGER,
  is_ativa BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para disciplinas
CREATE TABLE disciplinas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  instituicao_id INTEGER NOT NULL,
  nome TEXT NOT NULL,
  codigo TEXT,
  carga_horaria INTEGER,
  is_ativa BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para credenciais ERP das instituições
CREATE TABLE credenciais_erp (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  instituicao_id INTEGER NOT NULL UNIQUE,
  conector_erp_id INTEGER NOT NULL,
  credenciais_json TEXT, -- JSON com as credenciais específicas do conector
  status_conexao TEXT DEFAULT 'nao_configurado', -- nao_configurado, conectado, erro
  ultima_sincronizacao DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para log de sincronizações
CREATE TABLE log_sincronizacoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  instituicao_id INTEGER NOT NULL,
  tipo_operacao TEXT NOT NULL, -- sincronizacao_completa, sincronizacao_incremental
  status TEXT NOT NULL, -- sucesso, erro, em_andamento
  detalhes TEXT, -- JSON com detalhes da operação
  registros_processados INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Índices para melhor performance
CREATE INDEX idx_usuarios_escola_instituicao ON usuarios_escola(instituicao_id);
CREATE INDEX idx_alunos_instituicao ON alunos(instituicao_id);
CREATE INDEX idx_responsaveis_instituicao ON responsaveis(instituicao_id);
CREATE INDEX idx_turmas_instituicao ON turmas(instituicao_id);
CREATE INDEX idx_disciplinas_instituicao ON disciplinas(instituicao_id);
CREATE INDEX idx_alunos_responsaveis_aluno ON alunos_responsaveis(aluno_id);
CREATE INDEX idx_alunos_responsaveis_responsavel ON alunos_responsaveis(responsavel_id);
