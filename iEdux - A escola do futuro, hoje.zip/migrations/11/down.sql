
-- Remover dados de teste
DELETE FROM atribuicoes_perfis WHERE instituicao_id = 1;
DELETE FROM usuarios_escola WHERE instituicao_id = 1;
DELETE FROM usuarios WHERE instituicao_id = 1;
DELETE FROM licencas_instituicoes WHERE instituicao_id = 1;
DELETE FROM perfis_solucoes WHERE solucao_id IN (1, 2);
DELETE FROM solucoes WHERE nome LIKE 'iEDUX%';
DELETE FROM instituicoes WHERE nome = 'Escola Demo';
DELETE FROM conectores_erp WHERE nome = 'Totvs Protheus';
