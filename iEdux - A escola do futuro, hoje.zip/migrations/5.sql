
CREATE TABLE solucoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ativa',
  descricao_breve TEXT,
  url_aplicacao TEXT,
  url_icone TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE perfis_solucoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  solucao_id INTEGER NOT NULL,
  nome_perfil TEXT NOT NULL,
  descricao_perfil TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_perfis_solucoes_solucao_id ON perfis_solucoes(solucao_id);
