
-- Remover dados de teste
DELETE FROM atribuicoes_perfis WHERE usuario_id = 1 AND solucao_id = 1;
DELETE FROM usuarios_escola WHERE email = 'professor@iedux.com';
DELETE FROM licencas_instituicoes WHERE instituicao_id = 1 AND solucao_id = 1;
DELETE FROM perfis_solucoes WHERE solucao_id = 1;
DELETE FROM solucoes WHERE nome = 'Quest - Teste';
DELETE FROM usuarios WHERE email IN ('admin@iedux.com', 'escola@iedux.com');
DELETE FROM instituicoes WHERE nome = 'Escola Teste';
