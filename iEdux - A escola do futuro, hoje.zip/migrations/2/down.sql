
DROP INDEX idx_usuarios_email;
DROP TABLE usuarios;
