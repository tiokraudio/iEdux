
CREATE TABLE licencas_instituicoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  instituicao_id INTEGER NOT NULL,
  solucao_id INTEGER NOT NULL,
  is_ativa BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(instituicao_id, solucao_id)
);

CREATE INDEX idx_licencas_instituicao ON licencas_instituicoes(instituicao_id);
CREATE INDEX idx_licencas_solucao ON licencas_instituicoes(solucao_id);
