
DROP INDEX idx_atribuicoes_perfis_solucao;
DROP INDEX idx_atribuicoes_perfis_instituicao;
DROP TABLE atribuicoes_perfis;
