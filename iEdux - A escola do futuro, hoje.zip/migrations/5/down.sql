
DROP INDEX idx_perfis_solucoes_solucao_id;
DROP TABLE perfis_solucoes;
DROP TABLE solucoes;
