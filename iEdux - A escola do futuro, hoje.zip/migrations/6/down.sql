
DROP INDEX idx_licencas_solucao;
DROP INDEX idx_licencas_instituicao;
DROP TABLE licencas_instituicoes;
