
CREATE TABLE conectores_erp (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ativo',
  descricao_breve TEXT,
  campos_credenciais TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE instituicoes ADD COLUMN conector_erp_id INTEGER;
