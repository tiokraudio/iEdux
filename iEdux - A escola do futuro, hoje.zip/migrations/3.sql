
CREATE TABLE instituicoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ativa',
  modo_dados TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_instituicoes_status ON instituicoes(status);
