
ALTER TABLE instituicoes DROP COLUMN conector_erp_id;
DROP TABLE conectores_erp;
