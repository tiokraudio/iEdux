
CREATE TABLE usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  nome TEXT NOT NULL,
  perfil TEXT NOT NULL,
  is_ativo BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_usuarios_email ON usuarios(email);

INSERT INTO usuarios (email, nome, perfil, created_at, updated_at) 
VALUES ('tiokraudio@gmail.com', 'Super Admin', 'Super Admin', datetime('now'), datetime('now'));
