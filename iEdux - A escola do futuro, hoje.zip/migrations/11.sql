
-- Inserir dados de teste para demonstrar o sistema completo

-- 1. Inserir um conector ERP de exemplo
INSERT INTO conectores_erp (nome, status, descricao_breve, campos_credenciais) 
VALUES (
  'Totvs Protheus',
  'ativo',
  'Conector para integração com sistema Totvs Protheus',
  '[{"name":"servidor","label":"Servidor","type":"text","placeholder":"192.168.1.100","required":true},{"name":"porta","label":"Porta","type":"number","placeholder":"8080","required":true},{"name":"usuario","label":"Usuário","type":"text","placeholder":"admin","required":true},{"name":"senha","label":"Senha","type":"password","placeholder":"******","required":true}]'
);

-- 2. Inserir uma instituição de exemplo
INSERT INTO instituicoes (nome, status, modo_dados, conector_erp_id)
VALUES ('Escola Demo', 'ativa', 'manual', NULL);

-- 3. Inserir soluções de exemplo
INSERT INTO solucoes (nome, status, descricao_breve, url_aplicacao, url_icone)
VALUES 
  ('iEDUX - Quest', 'ativa', 'Plataforma colaborativa para criação de provas', 'https://quest.sua-vps.com', 'https://mocha-cdn.com/019a593b-ef35-795c-9777-c39c5e44a28a/quest-interface.png'),
  ('iEDUX - SOE', 'ativa', 'Sistema de Orientação Educacional', 'https://soe.sua-vps.com', 'https://mocha-cdn.com/019a593b-ef35-795c-9777-c39c5e44a28a/soe-interface.png');

-- 4. Inserir perfis para as soluções
INSERT INTO perfis_solucoes (solucao_id, nome_perfil, descricao_perfil)
VALUES 
  (1, 'Quest_Criador', 'Pode criar e editar provas'),
  (1, 'Quest_Aplicador', 'Pode aplicar provas já criadas'),
  (2, 'SOE_Orientador', 'Acesso completo ao sistema de orientação'),
  (2, 'SOE_Consultor', 'Apenas visualização de relatórios');

-- 5. Inserir licenças para a instituição demo
INSERT INTO licencas_instituicoes (instituicao_id, solucao_id, is_ativa)
VALUES 
  (1, 1, 1),
  (1, 2, 1);

-- 6. Inserir admin da instituição demo (use seu email do Google)
INSERT INTO usuarios (nome, email, perfil, instituicao_id, is_ativo)
VALUES ('Admin Demo', 'seu-email@gmail.com', 'Admin Instituição', 1, 1);

-- 7. Inserir utilizadores da escola demo
INSERT INTO usuarios_escola (instituicao_id, nome, email, tipo_usuario, is_ativo)
VALUES 
  (1, 'Professor João', 'joao.professor@gmail.com', 'professor', 1),
  (1, 'Coordenadora Maria', 'maria.coordenadora@gmail.com', 'coordenador', 1),
  (1, 'Porteiro José', 'jose.porteiro@gmail.com', 'porteiro', 1);

-- 8. Inserir atribuições de perfis (João tem acesso às duas soluções)
INSERT INTO atribuicoes_perfis (usuario_id, solucao_id, perfil_solucao_id, instituicao_id)
VALUES 
  (1, 1, 1, 1), -- João como Quest_Criador
  (1, 2, 3, 1), -- João como SOE_Orientador
  (2, 1, 2, 1), -- Maria como Quest_Aplicador
  (3, 2, 4, 1); -- José como SOE_Consultor
